# HEALTH — C20 · Founder Presence Layer

**Status:** complete, awaiting Hermes audit.

| Check | Result |
|---|---|
| `npm test` | **183 pass / 0 fail**, 40 suites, run twice |
| `node tests/purity-guard.mjs` | **CONTAINED** — 0 findings |
| External dependencies | **zero** |
| Files touched outside `presence/` | **none** |

Tests execute for real on Node 24's native TypeScript support. Nothing was
installed to run them.

---

## 1 · Grounding — read first

The brief grounds this in: **Kernel Specification, ADR-0022, ADR-0023, VEDA,
Roadmap, C1–C19.**

**None of those six were provided to me. I have not inspected any of them.**

This matters more here than it did in C19A, because ADR-0022 and ADR-0023 may
already define a presence or snapshot contract. **If they do, this
implementation is superseded, not merged** — do not reconcile two competing
snapshot shapes.

Every identifier is provisional, derived from the eight fields the brief itself
enumerates plus vocabulary already present in the repository. `types.ts`
exports `TERMINOLOGY_RECONCILIATION` — **12 named assumptions, each with the
question to put to the specification.** A test asserts it stays non-empty so
the disclosure cannot be quietly deleted.

The four I would ask first:

1. **Does an ADR already define `PresenceSnapshot`?** If yes, stop here.
2. **Does the Kernel report per-domain coverage and freshness?** If not, calm
   cannot be honestly derived and this layer will report `coverage-incomplete`
   permanently — which is the correct behaviour, but you should decide that
   knowingly.
3. **Is the layer fed, or does it pull?** This implementation can only be fed.
   It holds no reference to anything and cannot pull by construction.
4. **Does the runtime emit a reasoning summary?** If not, `reasoning.text` is
   permanently null by design. The layer will not fill that silence.

---

## 2 · What was built

`presence/` — a standalone package with **zero dependencies**.

| File | Lines | Role |
|---|---|---|
| `src/types.ts` | 268 | Snapshot contract. Types + frozen constants only. |
| `src/observations.ts` | 210 | The complete input vocabulary + structural validation. |
| `src/state.ts` | 233 | Pure fold: `(state, observation) => state`. |
| `src/derive.ts` | 302 | Pure projections. No clock, no randomness, no I/O. |
| `src/presenceLayer.ts` | 196 | Assembly: `observe` · `snapshot` · `subscribe`. |
| `src/index.ts` | 74 | Public surface. |
| `tests/` (6 files) | 2,038 | 183 assertions. |
| `tests/purity-guard.mjs` | 96 | Mechanical containment enforcement. |

All eight brief-mandated fields are present on every snapshot: `activeMission`,
`execution`, `calm`, `vigilance`, `activity`, `pendingApprovals`, `lastAction`,
`reasoning` — asserted with `Object.hasOwn`, including when the value is null.

---

## 3 · Prohibitions — enforced, not promised

The brief lists five things this layer must never do. Each is a **checked
property**, not a comment.

| Prohibition | How it is made impossible |
|---|---|
| Never execute tools | No reference to any executor exists. `purity-guard` fails the build on `execute(` / `invoke(`. |
| Never call plugins | Zero external imports — the guard rejects any import specifier that leaves `src/`. |
| Never authorize | No verdict, permission or policy surface anywhere. Guard rejects `authorize(` / `authorise(`. |
| Never mutate Kernel state | It holds nothing to mutate. The fold copies; inputs are never touched (tested). |
| No rendering / UI / HTML / React / Electron | Zero dependencies. No JSX, no DOM reference, no framework. |

The guard additionally rejects **network I/O, filesystem I/O, `process`,
dynamic import/require, `setTimeout`/`setInterval`, `Date.now()`, `new Date()`,
`Math.random()` and `globalThis`.**

Two of those deserve a note:

- **No clock.** Every instant is a parameter. `snapshot(now)` describes the
  moment you name. This is why every snapshot is reproducible and every test
  is exact — and it means the layer has no notion of "later" it could act on.
- **No timers.** Subscribers are notified synchronously inside `observe`,
  using the observation's own timestamp. The layer has no background
  behaviour of any kind. It is inert between observations.

---

## 4 · The two design decisions worth auditing

### Calm is a union, not a boolean

`CalmState` has no boolean field. It is:

```
{ calm: true;  since; statement }
{ calm: false; reasons: CalmBlocker[]; statement }
```

A boolean can be set from anywhere. A union member must be *constructed*, and
the `calm: true` member is constructible at exactly one place in the codebase —
inside `deriveCalm`, reachable only when the blocker list is empty. A future
contributor cannot claim calm from elsewhere without deleting that function.

Five independent blockers, all of which must clear: coverage incomplete ·
approval pending · execution active · mission held · failure unacknowledged.
Each is tested in isolation.

### A running mission does NOT block calm — deliberately

Calm means *nothing needs **you***, not *nothing is happening*. A mission
running unattended is the product working, not a reason to alarm the founder.
So the calm snapshot reads:

> "Nothing needs you." — with three missions running.

Held missions **do** block, because held means blocked on a human. If the
specification intends calm to mean quiescence rather than absence-of-demand,
this is the line to change (`deriveCalm`, the `mission-held` branch) and it is
a one-line change. **Flagging it because it is a semantic judgement I made
without a grounding document, and it is the kind of thing that looks like a bug
if you disagree with it.**

### Reasoning is carried, never generated

`ReasoningSummary.text` is a passthrough of what the runtime supplied. When
nothing has been supplied it is `null` and the field says so. The layer has no
model and performs no inference — filling that silence with a plausible
sentence would be exactly the AI logic the brief forbids.

A test named after the rule folds a long observation sequence containing no
`reasoning.supplied` and asserts `text` is null in every resulting snapshot.

### Activity lines are templates, not prose generation

`activity.line` is composed from structured facts by fixed template, with
stated precedence: **degraded ▸ waiting-on-founder ▸ blocked ▸ working ▸
idle**. Every branch could be written as a lookup table and effectively is.
No inference, no generation.

---

## 5 · Test coverage

183 assertions, 40 suites, all deterministic — no real clock, no timers, no I/O.

| File | Covers |
|---|---|
| `observations.test.ts` | All 12 valid shapes accepted; null/undefined/primitives/arrays/`{}`/unknown-type/empty-`at` rejected; per-type wrong-field-type rejection |
| `state.test.ts` | Fold purity (input never mutated, new identity every time), count/timestamp tracking, every observation branch, and the subtle **`since` semantics** — repeating a phase must not move it, changing it must |
| `derive.test.ts` | `secondsBetween` incl. **negative clamp** and invalid dates; active-mission precedence proven **order-independent** via two insertion orders; all three vigilance gap kinds; all five calm blockers in isolation; reasoning staleness at the exact boundary; activity precedence with several conditions satisfied at once |
| `presenceLayer.test.ts` | Determinism (`deepStrictEqual` + JSON round-trip), sequence advancing only on accepted observations, held snapshots immutable across later folds, subscription fan-out and idempotent unsubscribe, `possiblyStale` boundary, `calmSince` set/preserved/cleared/re-set, custom thresholds, and a realistic end-to-end sequence |
| `contract.test.ts` | All 8 mandated fields present incl. when null; terminology disclosure intact; `CALM_BLOCKER_KINDS` exactly 5; **"never invents reasoning"**; **public surface exports nothing matching `/execute|invoke|authorize|mutate|write|commit|dispatch/i`** |

**Run:**
```
cd presence
npm test          # 183 pass
npm run verify    # purity guard + tests
```

> Invocation trap: `node --test tests/` fails — Node resolves `tests` as a
> module specifier. Use `node --test 'tests/**/*.test.ts'`, which is what
> `npm test` runs.

---

## 6 · Known issues and residual risk

**High**
1. **12 unreconciled terminology assumptions.** Listed in
   `TERMINOLOGY_RECONCILIATION`. The riskiest is whether ADR-0022/0023 already
   own this contract.
2. **No typecheck has run.** The npm registry is unreachable here, so `tsc` is
   unavailable. Node's type-stripping *executes* the code but does **not**
   type-check it. 183 passing tests prove runtime behaviour, not type
   correctness. Run `tsc --noEmit` in an environment with the toolchain.

**Medium**
3. **Package location assumed.** The brief gave no path. I created a sibling
   package `presence/` rather than placing files inside any protected
   directory. Move it if the repository layout expects otherwise — it has no
   dependencies, so moving it is a `mv`.
4. **`ExecutionPhase` is carried forward from C19A**, which was itself
   unverified against the Kernel Specification. If C19A's phases are wrong,
   these are wrong identically.
5. **Single active mission assumed.** If the Coordinator can run several
   concurrently and the founder should see all of them, `activeMission`
   becomes a list and `deriveActiveMission`'s precedence rules change meaning.

**Low / by design**
6. Nothing consumes this layer yet. It is inert until something feeds it —
   which is the intent of C20.
7. `calmSince` is the only self-derived state. It exists so calm can report how
   long it has held, which is not recoverable from any single observation.
8. Thresholds default in-package. If ADR-0023 owns staleness policy, import
   rather than default.

---

## 7 · Position in the stack

```
Founder-facing surface     ← not part of C20. Consumes snapshots. Renders nothing here.
        ▲
        │  PresenceSnapshot  (pull via snapshot(now), or push via subscribe)
        │
   PRESENCE LAYER           ← C20 ✅ pure projection, zero dependencies
        ▲
        │  Observation      (the only way in — the layer cannot reach out)
        │
Coordinator · Runtime Bridge · Kernel   ← untouched, and unreachable from here
```

The arrow into the layer points one way only. That is the whole architecture of
C20: **it can be told, and it can be read. It cannot reach.**

---

**Stopping here as instructed. Awaiting Hermes audit.**
