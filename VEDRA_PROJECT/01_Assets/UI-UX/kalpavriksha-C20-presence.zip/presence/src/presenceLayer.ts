/**
 * C20 · PresenceLayer — the assembled layer.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHAT IT DOES
 * Accepts observations. Produces `PresenceSnapshot`. Notifies subscribers.
 *
 * WHAT IT CANNOT DO — structurally, not by convention
 * · It holds no reference to the Kernel, Coordinator, Runtime Bridge, any
 *   plugin or any tool, and imports nothing outside this package.
 * · It performs no I/O. There is no fetch, no fs, no process, no network.
 * · It reads no clock of its own. Every instant is passed in by the caller,
 *   which is what makes every snapshot reproducible and every test exact.
 * · It never authorises anything. There is no verdict, permission or policy
 *   surface anywhere in this package.
 * · It never mutates Kernel state. It has nothing to mutate it with.
 *
 * `tests/purity-guard.mjs` enforces the import rule mechanically, so this is
 * a checked property rather than a promise in a comment.
 * ═══════════════════════════════════════════════════════════════════════════
 */

import {
  DEFAULT_THRESHOLDS,
  LAYER_VERSION,
  type PresenceSnapshot,
  type PresenceThresholds,
  type Timestamp,
  type LastAction,
} from './types.ts';
import { isValidObservation, type Observation } from './observations.ts';
import { applyObservation, createObservedState, type ObservedState } from './state.ts';
import {
  deriveActiveMission,
  deriveActivity,
  deriveCalm,
  deriveExecution,
  derivePendingApprovals,
  deriveReasoning,
  deriveVigilance,
  secondsBetween,
} from './derive.ts';

export interface PresenceLayerOptions {
  readonly thresholds?: Partial<PresenceThresholds>;
}

export interface ObserveResult {
  /** False when the observation was structurally malformed and was ignored. */
  readonly accepted: boolean;
  /** Total observations folded in so far. */
  readonly observationCount: number;
}

export interface PresenceLayer {
  /**
   * Folds one observation into the layer.
   *
   * Never throws. A malformed observation is rejected and reported in the
   * result — presence must not become a failure mode for whatever is feeding
   * it. Accepting an observation is not an endorsement of it: the layer does
   * not judge whether the observation *should* have happened.
   */
  observe(obs: unknown): ObserveResult;

  /** Folds several observations in order. Returns the result of the last. */
  observeAll(observations: readonly unknown[]): ObserveResult;

  /**
   * Produces a snapshot as of `now`.
   *
   * Pure with respect to the layer: calling it twice with the same `now` and
   * no intervening observation returns deep-equal snapshots, and it does not
   * advance the sequence on its own — `sequence` reflects observation history,
   * not read count.
   *
   * @param now the instant to describe. Caller-supplied so the layer holds no
   *            clock and results are reproducible.
   */
  snapshot(now: Timestamp): PresenceSnapshot;

  /**
   * Subscribes to snapshots produced after each accepted observation.
   * Returns an idempotent unsubscribe.
   *
   * The layer does not schedule anything: subscribers are notified
   * synchronously during `observe`, using the observation's own timestamp as
   * `now`. There is no timer here, and therefore no background behaviour.
   */
  subscribe(listener: (snapshot: PresenceSnapshot) => void): () => void;

  listenerCount(): number;

  /** The raw fold, for diagnostics and tests. Read-only by type. */
  observedState(): ObservedState;

  /** Discards all observations and listeners. */
  reset(): void;
}

export function createPresenceLayer(opts: PresenceLayerOptions = {}): PresenceLayer {
  const thresholds: PresenceThresholds = { ...DEFAULT_THRESHOLDS, ...opts.thresholds };

  let state: ObservedState = createObservedState();
  let sequence = 0;
  const listeners = new Set<(s: PresenceSnapshot) => void>();

  function build(now: Timestamp): PresenceSnapshot {
    const activeMission = deriveActiveMission(state);
    const execution = deriveExecution(state, now);
    const vigilance = deriveVigilance(state, now, thresholds);
    const pendingApprovals = derivePendingApprovals(state, now);
    const calm = deriveCalm(state, vigilance, pendingApprovals, execution, activeMission, now);
    const activity = deriveActivity(vigilance, pendingApprovals, execution, activeMission, state);
    const reasoning = deriveReasoning(state, now, thresholds);

    const lastAction: LastAction | null =
      state.lastAction === null
        ? null
        : {
            at: state.lastAction.at,
            actor: state.lastAction.actor,
            description: state.lastAction.description,
            domain: state.lastAction.domain,
            succeeded: state.lastAction.succeeded,
            agoSeconds: secondsBetween(state.lastAction.at, now),
          };

    const possiblyStale =
      state.lastObservedAt !== null &&
      secondsBetween(state.lastObservedAt, now) > thresholds.silenceSeconds;

    return {
      sequence,
      at: now,
      activeMission,
      execution,
      calm,
      vigilance,
      activity,
      pendingApprovals,
      lastAction,
      reasoning,
      meta: {
        observationCount: state.observationCount,
        lastObservedAt: state.lastObservedAt,
        possiblyStale,
        layerVersion: LAYER_VERSION,
      },
    };
  }

  /**
   * Maintains `calmSince` — the only piece of state the layer derives about
   * itself. It exists so calm can report how long it has held, which cannot be
   * recovered from a single observation.
   */
  function updateCalmSince(now: Timestamp): void {
    const probe = build(now);
    if (probe.calm.calm) {
      if (state.calmSince === null) state = { ...state, calmSince: now };
    } else if (state.calmSince !== null) {
      state = { ...state, calmSince: null };
    }
  }

  return {
    observe(obs: unknown): ObserveResult {
      if (!isValidObservation(obs)) {
        return { accepted: false, observationCount: state.observationCount };
      }
      const observation = obs satisfies Observation;
      state = applyObservation(state, observation);
      sequence += 1;
      updateCalmSince(observation.at);

      if (listeners.size > 0) {
        const snap = build(observation.at);
        for (const l of listeners) l(snap);
      }
      return { accepted: true, observationCount: state.observationCount };
    },

    observeAll(observations: readonly unknown[]): ObserveResult {
      let result: ObserveResult = { accepted: false, observationCount: state.observationCount };
      for (const o of observations) result = this.observe(o);
      return result;
    },

    snapshot(now: Timestamp): PresenceSnapshot {
      return build(now);
    },

    subscribe(listener) {
      listeners.add(listener);
      let removed = false;
      return () => {
        if (removed) return;
        removed = true;
        listeners.delete(listener);
      };
    },

    listenerCount: () => listeners.size,

    observedState: () => state,

    reset() {
      state = createObservedState();
      sequence = 0;
      listeners.clear();
    },
  };
}
