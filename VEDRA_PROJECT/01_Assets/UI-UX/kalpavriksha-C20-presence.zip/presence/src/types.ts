/**
 * C20 · Founder Presence Layer — types.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * GROUNDING DISCLOSURE
 *
 * The brief grounds this work in: Kernel Specification, ADR-0022, ADR-0023,
 * VEDA, Roadmap, C1–C19.
 *
 * None of those six were provided to me and I have not inspected any of them.
 * ADR-0022 and ADR-0023 in particular may already define a presence or
 * snapshot contract — if they do, THAT contract wins and this file should be
 * replaced rather than reconciled.
 *
 * Every identifier here is therefore PROVISIONAL, derived from the eight
 * fields the brief itself enumerates plus vocabulary already established in
 * this repository (C19A `types/execution.ts`). It is not transcribed from any
 * grounding document.
 *
 * `TERMINOLOGY_RECONCILIATION` at the foot of this file lists every assumption
 * with the question to put to the specification. A test asserts it stays
 * non-empty.
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * SCOPE. This file declares types. It contains no executable logic beyond
 * frozen constant arrays.
 */

export type Timestamp = string;
export type MissionRef = string;
export type ExecutionId = string;
export type ApprovalId = string;
export type DomainKey = string;

/* ───────────────────────── 1 · active mission ─────────────────────────── */

export type MissionPhase = 'queued' | 'running' | 'held' | 'completed' | 'failed';

export interface ActiveMission {
  readonly ref: MissionRef;
  readonly title: string;
  readonly phase: MissionPhase;
  /** 0–1, or null when the runtime does not report progress. Never estimated here. */
  readonly progress: number | null;
  readonly startedAt: Timestamp;
  readonly domain: DomainKey;
}

/* ──────────────────────── 2 · execution status ────────────────────────── */

export type ExecutionPhase =
  | 'idle'
  | 'dispatching'
  | 'running'
  | 'streaming'
  | 'awaiting-approval'
  | 'cancelling'
  | 'cancelled'
  | 'succeeded'
  | 'failed';

export interface ExecutionStatus {
  readonly executionId: ExecutionId | null;
  readonly phase: ExecutionPhase;
  readonly since: Timestamp | null;
  /** Whole seconds in the current phase at snapshot time. Null when idle. */
  readonly inPhaseSeconds: number | null;
  readonly failureCode: string | null;
}

/* ───────────────────────── 3 · calm state ─────────────────────────────── */

/**
 * Calm is the claim "nothing needs you". It is the highest-value statement the
 * product makes and the easiest to make dishonestly.
 *
 * It is therefore a discriminated union: the calm member cannot be constructed
 * without complete vigilance coverage, and the not-calm member is required to
 * carry its reasons. There is no boolean anywhere in this type, deliberately —
 * a boolean can be set; a union member must be justified.
 */
export type CalmState =
  | { readonly calm: true; readonly since: Timestamp; readonly statement: string }
  | { readonly calm: false; readonly reasons: readonly CalmBlocker[]; readonly statement: string };

export type CalmBlockerKind =
  | 'coverage-incomplete'
  | 'approval-pending'
  | 'execution-active'
  | 'mission-held'
  | 'failure-unacknowledged';

export interface CalmBlocker {
  readonly kind: CalmBlockerKind;
  /** Plain sentence naming what specifically blocks calm. */
  readonly detail: string;
}

export const CALM_BLOCKER_KINDS = [
  'coverage-incomplete',
  'approval-pending',
  'execution-active',
  'mission-held',
  'failure-unacknowledged',
] as const;

/* ──────────────────────── 4 · vigilance state ─────────────────────────── */

export interface DomainCoverage {
  readonly domain: DomainKey;
  readonly lastCheckedAt: Timestamp;
  readonly healthy: boolean;
  /** Age in whole seconds beyond which this domain counts as stale. */
  readonly freshnessSeconds: number;
}

/**
 * Whether the system can account for every domain it claims to watch.
 *
 * `complete: false` carries the gaps. Calm is derivable only from
 * `complete: true` — see `deriveCalm`.
 */
export type VigilanceState =
  | { readonly complete: true; readonly domains: readonly DomainCoverage[]; readonly checkedAt: Timestamp }
  | {
      readonly complete: false;
      readonly domains: readonly DomainCoverage[];
      readonly gaps: readonly VigilanceGap[];
      readonly checkedAt: Timestamp;
    };

export type VigilanceGapReason = 'stale' | 'unhealthy' | 'never-reported';

export interface VigilanceGap {
  readonly domain: DomainKey;
  readonly reason: VigilanceGapReason;
  readonly detail: string;
}

/* ──────────────────────── 5 · current activity ────────────────────────── */

/**
 * What the system is doing right now, in one deterministic line.
 *
 * `line` is composed from structured facts by template. It is never inferred,
 * never generated, and never AI-authored — see `narration.ts`.
 */
export type ActivityKind = 'idle' | 'working' | 'waiting-on-founder' | 'blocked' | 'degraded';

export interface CurrentActivity {
  readonly kind: ActivityKind;
  readonly line: string;
  readonly since: Timestamp | null;
  /** Domains with observed work in progress. Empty when idle. */
  readonly domains: readonly DomainKey[];
}

/* ─────────────────────── 6 · pending approvals ────────────────────────── */

export interface PendingApproval {
  readonly approvalId: ApprovalId;
  readonly executionId: ExecutionId | null;
  /** Runtime-supplied prompt, carried verbatim. Never composed here. */
  readonly prompt: string;
  readonly requestedAt: Timestamp;
  readonly expiresAt: Timestamp | null;
  readonly domain: DomainKey;
  /** Whole seconds since requested, at snapshot time. */
  readonly waitingSeconds: number;
}

/* ─────────────────────────── 7 · last action ──────────────────────────── */

export type ActorKind = 'kernel' | 'rule' | 'founder' | 'delegate';

export interface LastAction {
  readonly at: Timestamp;
  readonly actor: ActorKind;
  /** Runtime-supplied description, carried verbatim. */
  readonly description: string;
  readonly domain: DomainKey;
  readonly succeeded: boolean;
  /** Whole seconds since it occurred, at snapshot time. */
  readonly agoSeconds: number;
}

/* ─────────────────── 8 · current reasoning summary ────────────────────── */

/**
 * The runtime's own account of what it is currently reasoning about.
 *
 * CARRIED, NEVER GENERATED. This layer has no model, performs no inference and
 * writes no prose about intent. If the runtime has supplied nothing, `text` is
 * null and the field says so — it does not fill the silence.
 */
export interface ReasoningSummary {
  readonly text: string | null;
  readonly suppliedAt: Timestamp | null;
  /** Whole seconds since supplied. Null when absent. */
  readonly ageSeconds: number | null;
  /** True when older than the staleness threshold; consumers should downgrade it. */
  readonly stale: boolean;
}

/* ─────────────────────────── the snapshot ─────────────────────────────── */

/**
 * A complete, self-contained description of how Kalpavriksha is right now.
 *
 * Immutable and serialisable. Two snapshots of identical observed state at the
 * same instant are deep-equal — there is no randomness, no hidden clock and no
 * accumulated internal mood.
 */
export interface PresenceSnapshot {
  /** Monotonic within a single layer instance. Starts at 1. */
  readonly sequence: number;
  readonly at: Timestamp;

  readonly activeMission: ActiveMission | null;
  readonly execution: ExecutionStatus;
  readonly calm: CalmState;
  readonly vigilance: VigilanceState;
  readonly activity: CurrentActivity;
  readonly pendingApprovals: readonly PendingApproval[];
  readonly lastAction: LastAction | null;
  readonly reasoning: ReasoningSummary;

  /** Provenance of this snapshot. Diagnostics; never founder-facing prose. */
  readonly meta: SnapshotMeta;
}

export interface SnapshotMeta {
  /** Observations folded in since the layer was created. */
  readonly observationCount: number;
  /** When the layer last received any observation. Null if never. */
  readonly lastObservedAt: Timestamp | null;
  /**
   * True when no observation has arrived within the silence threshold. The
   * layer cannot distinguish a quiet system from a disconnected one, and says
   * so rather than presenting stale state as current.
   */
  readonly possiblyStale: boolean;
  readonly layerVersion: string;
}

export const LAYER_VERSION = 'c20.0';

/* ────────────────────────── thresholds ────────────────────────────────── */

/**
 * All time-based judgements in one place, injectable for tests.
 * These are presentation thresholds, not policy — they change how state is
 * described, never what the system is permitted to do.
 */
export interface PresenceThresholds {
  /** Reasoning older than this is marked stale. */
  readonly reasoningStaleSeconds: number;
  /** No observation for this long ⇒ `meta.possiblyStale`. */
  readonly silenceSeconds: number;
  /** Default per-domain freshness when a coverage report omits one. */
  readonly defaultFreshnessSeconds: number;
}

export const DEFAULT_THRESHOLDS: PresenceThresholds = {
  reasoningStaleSeconds: 300,
  silenceSeconds: 120,
  defaultFreshnessSeconds: 900,
};

/* ══════════════════════════════════════════════════════════════════════════
 * TERMINOLOGY RECONCILIATION — every assumption, with its question.
 * ══════════════════════════════════════════════════════════════════════════ */

export const TERMINOLOGY_RECONCILIATION = [
  { assumed: 'PresenceSnapshot', question: 'Do ADR-0022/0023 already define a snapshot contract? If so this file is superseded, not merged.' },
  { assumed: 'CalmState as a union, not a boolean', question: 'Does the specification model calm as a derived claim or as a stored flag? A flag cannot carry its justification.' },
  { assumed: 'VigilanceState / DomainCoverage', question: 'Does the Kernel report per-domain coverage and freshness? If not, calm cannot be honestly derived and this layer must report `coverage-incomplete` permanently.' },
  { assumed: 'ExecutionPhase (9 values)', question: 'Confirm against the Kernel Specification. Carried forward from C19A, itself unverified.' },
  { assumed: 'A single activeMission', question: 'Can more than one mission be active at once? If so this becomes a list and `activity.domains` changes meaning.' },
  { assumed: 'ActivityKind (5 values)', question: 'Is "how the system is" an existing concept in VEDA, with its own vocabulary?' },
  { assumed: 'ReasoningSummary is supplied, never generated', question: 'Does the runtime emit a reasoning summary? If not, this field is permanently null by design — confirm that is acceptable.' },
  { assumed: 'ActorKind (4 values)', question: 'Confirm against the Ledger actor taxonomy.' },
  { assumed: 'sequence starts at 1 and is per-instance', question: 'Is there a global snapshot sequence or version vector the layer should adopt instead?' },
  { assumed: 'Thresholds are presentation-only', question: 'Are staleness thresholds policy owned elsewhere (ADR-0023)? If so, import rather than default.' },
  { assumed: 'Push-based observation intake', question: 'Is the Presence Layer fed by the Coordinator, or expected to pull? This implementation only accepts being fed — it cannot call anything.' },
  { assumed: 'Snapshot is serialisable JSON', question: 'Is presence transported over the Runtime Bridge as JSON, or shared in-process?' },
] as const;
