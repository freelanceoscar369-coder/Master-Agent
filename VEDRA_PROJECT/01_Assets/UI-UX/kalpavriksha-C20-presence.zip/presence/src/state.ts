/**
 * C20 · Observed state — the fold of observations, and nothing more.
 *
 * This module holds what the layer has been told. It performs no derivation
 * (that is `derive.ts`) and no I/O of any kind.
 *
 * The fold is a pure function: `(state, observation) => state`. It never
 * mutates its input, which is what makes snapshots safe to hand out — a
 * consumer holding an old snapshot cannot see it change underneath them.
 */

import type {
  ActiveMission,
  ApprovalId,
  DomainKey,
  ExecutionPhase,
  MissionRef,
  Timestamp,
} from './types.ts';
import type { Observation } from './observations.ts';

/* ───────────────────────────── shapes ─────────────────────────────────── */

export interface ObservedExecution {
  readonly executionId: string | null;
  readonly phase: ExecutionPhase;
  readonly since: Timestamp | null;
  readonly failureCode: string | null;
}

export interface ObservedApproval {
  readonly approvalId: ApprovalId;
  readonly executionId: string | null;
  readonly prompt: string;
  readonly requestedAt: Timestamp;
  readonly expiresAt: Timestamp | null;
  readonly domain: DomainKey;
}

export interface ObservedCoverage {
  readonly domain: DomainKey;
  readonly lastCheckedAt: Timestamp;
  readonly healthy: boolean;
  readonly freshnessSeconds: number | null;
}

export interface ObservedFailure {
  readonly code: string;
  readonly detail: string;
  readonly domain: DomainKey;
  readonly at: Timestamp;
  readonly acknowledged: boolean;
}

export interface ObservedAction {
  readonly at: Timestamp;
  readonly actor: 'kernel' | 'rule' | 'founder' | 'delegate';
  readonly description: string;
  readonly domain: DomainKey;
  readonly succeeded: boolean;
}

export interface ObservedState {
  readonly missions: ReadonlyMap<MissionRef, ActiveMission>;
  readonly execution: ObservedExecution;
  readonly approvals: ReadonlyMap<ApprovalId, ObservedApproval>;
  readonly coverage: ReadonlyMap<DomainKey, ObservedCoverage>;
  readonly expectedDomains: readonly DomainKey[];
  readonly failures: ReadonlyMap<string, ObservedFailure>;
  readonly lastAction: ObservedAction | null;
  readonly reasoning: { readonly text: string | null; readonly at: Timestamp } | null;
  /** When the system last entered a state with no blockers. Set by the layer. */
  readonly calmSince: Timestamp | null;
  readonly observationCount: number;
  readonly lastObservedAt: Timestamp | null;
}

export const EMPTY_EXECUTION: ObservedExecution = {
  executionId: null,
  phase: 'idle',
  since: null,
  failureCode: null,
};

export function createObservedState(): ObservedState {
  return {
    missions: new Map(),
    execution: EMPTY_EXECUTION,
    approvals: new Map(),
    coverage: new Map(),
    expectedDomains: [],
    failures: new Map(),
    lastAction: null,
    reasoning: null,
    calmSince: null,
    observationCount: 0,
    lastObservedAt: null,
  };
}

/* ─────────────────────────────── fold ─────────────────────────────────── */

function withMap<K, V>(map: ReadonlyMap<K, V>, mutate: (m: Map<K, V>) => void): ReadonlyMap<K, V> {
  const next = new Map(map);
  mutate(next);
  return next;
}

/**
 * Folds one observation into state. Pure — returns a new object and never
 * touches the one passed in.
 *
 * Unknown observation types are impossible here (the union is exhaustive) and
 * malformed ones are rejected upstream by `isValidObservation`. The fold
 * therefore has no error path, which is why it cannot throw into whatever is
 * feeding the layer.
 */
export function applyObservation(state: ObservedState, obs: Observation): ObservedState {
  const base = {
    ...state,
    observationCount: state.observationCount + 1,
    lastObservedAt: obs.at,
  };

  switch (obs.type) {
    case 'mission.observed': {
      const mission: ActiveMission = {
        ref: obs.ref,
        title: obs.title,
        phase: obs.phase,
        progress: obs.progress,
        startedAt: obs.startedAt,
        domain: obs.domain,
      };
      return { ...base, missions: withMap(state.missions, (m) => void m.set(obs.ref, mission)) };
    }

    case 'mission.cleared':
      return { ...base, missions: withMap(state.missions, (m) => void m.delete(obs.ref)) };

    case 'execution.observed': {
      // `since` only moves when the phase genuinely changes, so "how long in
      // this phase" stays truthful across repeated identical reports.
      const phaseChanged = state.execution.phase !== obs.phase;
      return {
        ...base,
        execution: {
          executionId: obs.executionId,
          phase: obs.phase,
          since: phaseChanged ? obs.at : state.execution.since ?? obs.at,
          failureCode: obs.failureCode,
        },
      };
    }

    case 'approval.opened': {
      const approval: ObservedApproval = {
        approvalId: obs.approvalId,
        executionId: obs.executionId,
        prompt: obs.prompt,
        requestedAt: obs.at,
        expiresAt: obs.expiresAt,
        domain: obs.domain,
      };
      return { ...base, approvals: withMap(state.approvals, (m) => void m.set(obs.approvalId, approval)) };
    }

    case 'approval.closed':
      return { ...base, approvals: withMap(state.approvals, (m) => void m.delete(obs.approvalId)) };

    case 'action.recorded':
      return {
        ...base,
        lastAction: {
          at: obs.at,
          actor: obs.actor,
          description: obs.description,
          domain: obs.domain,
          succeeded: obs.succeeded,
        },
      };

    case 'reasoning.supplied':
      return { ...base, reasoning: { text: obs.text, at: obs.at } };

    case 'coverage.reported': {
      const record: ObservedCoverage = {
        domain: obs.domain,
        lastCheckedAt: obs.at,
        healthy: obs.healthy,
        freshnessSeconds: obs.freshnessSeconds,
      };
      return { ...base, coverage: withMap(state.coverage, (m) => void m.set(obs.domain, record)) };
    }

    case 'coverage.withdrawn':
      return {
        ...base,
        coverage: withMap(state.coverage, (m) => void m.delete(obs.domain)),
        expectedDomains: state.expectedDomains.filter((d) => d !== obs.domain),
      };

    case 'coverage.expected':
      return { ...base, expectedDomains: [...obs.domains] };

    case 'failure.raised':
      return {
        ...base,
        failures: withMap(state.failures, (m) =>
          void m.set(obs.code, {
            code: obs.code,
            detail: obs.detail,
            domain: obs.domain,
            at: obs.at,
            acknowledged: false,
          }),
        ),
      };

    case 'failure.acknowledged': {
      const existing = state.failures.get(obs.code);
      if (existing === undefined) return base;
      return {
        ...base,
        failures: withMap(state.failures, (m) => void m.set(obs.code, { ...existing, acknowledged: true })),
      };
    }
  }
}
