/**
 * C20 · Founder Presence Layer — public surface.
 *
 * "How Kalpavriksha feels right now", as structured state.
 *
 * This package produces state and nothing else. It renders nothing, executes
 * nothing, authorises nothing and mutates nothing outside itself. It has no
 * dependencies — not one — and imports nothing beyond its own directory.
 */

export { createPresenceLayer } from './presenceLayer.ts';
export type { PresenceLayer, PresenceLayerOptions, ObserveResult } from './presenceLayer.ts';

export { isValidObservation, OBSERVATION_TYPES } from './observations.ts';
export type { Observation, ObservationType } from './observations.ts';

export {
  applyObservation,
  createObservedState,
  EMPTY_EXECUTION,
} from './state.ts';
export type {
  ObservedState,
  ObservedAction,
  ObservedApproval,
  ObservedCoverage,
  ObservedExecution,
  ObservedFailure,
} from './state.ts';

export {
  deriveActiveMission,
  deriveActivity,
  deriveCalm,
  deriveExecution,
  derivePendingApprovals,
  deriveReasoning,
  deriveVigilance,
  secondsBetween,
} from './derive.ts';

export {
  CALM_BLOCKER_KINDS,
  DEFAULT_THRESHOLDS,
  LAYER_VERSION,
  TERMINOLOGY_RECONCILIATION,
} from './types.ts';
export type {
  ActiveMission,
  ActivityKind,
  ActorKind,
  CalmBlocker,
  CalmBlockerKind,
  CalmState,
  CurrentActivity,
  DomainCoverage,
  DomainKey,
  ExecutionPhase,
  ExecutionStatus,
  LastAction,
  MissionPhase,
  MissionRef,
  PendingApproval,
  PresenceSnapshot,
  PresenceThresholds,
  ReasoningSummary,
  SnapshotMeta,
  Timestamp,
  VigilanceGap,
  VigilanceGapReason,
  VigilanceState,
} from './types.ts';
