/**
 * C20 · Observations — the only way information enters the Presence Layer.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * THE CONTAINMENT RULE
 *
 * This layer has no reach. It cannot call the Kernel, the Coordinator, the
 * Runtime Bridge, a plugin or a tool, because it holds no reference to any of
 * them and imports nothing outside this package.
 *
 * Everything it knows, it was told. `Observation` is the complete vocabulary
 * of what it can be told. If a fact is not expressible as an Observation, the
 * Presence Layer cannot know it — and that is the design, not a limitation to
 * be worked around later.
 *
 * `tests/purity-guard.mjs` enforces the no-external-imports rule mechanically.
 * ═══════════════════════════════════════════════════════════════════════════
 */

import type {
  ActorKind,
  ApprovalId,
  DomainKey,
  ExecutionId,
  ExecutionPhase,
  MissionPhase,
  MissionRef,
  Timestamp,
} from './types.ts';

/* ─────────────────────────── observations ─────────────────────────────── */

export type Observation =
  /** A mission's phase or progress changed. */
  | {
      readonly type: 'mission.observed';
      readonly at: Timestamp;
      readonly ref: MissionRef;
      readonly title: string;
      readonly phase: MissionPhase;
      readonly progress: number | null;
      readonly domain: DomainKey;
      readonly startedAt: Timestamp;
    }
  /** A mission is no longer tracked (completed and cleared, or withdrawn). */
  | { readonly type: 'mission.cleared'; readonly at: Timestamp; readonly ref: MissionRef }

  /** The runtime declared an execution phase. */
  | {
      readonly type: 'execution.observed';
      readonly at: Timestamp;
      readonly executionId: ExecutionId | null;
      readonly phase: ExecutionPhase;
      readonly failureCode: string | null;
    }

  /** An approval is waiting on the founder. */
  | {
      readonly type: 'approval.opened';
      readonly at: Timestamp;
      readonly approvalId: ApprovalId;
      readonly executionId: ExecutionId | null;
      readonly prompt: string;
      readonly domain: DomainKey;
      readonly expiresAt: Timestamp | null;
    }
  /** An approval left the pending set, however it left. */
  | { readonly type: 'approval.closed'; readonly at: Timestamp; readonly approvalId: ApprovalId }

  /** Something happened and was recorded. Description is carried verbatim. */
  | {
      readonly type: 'action.recorded';
      readonly at: Timestamp;
      readonly actor: ActorKind;
      readonly description: string;
      readonly domain: DomainKey;
      readonly succeeded: boolean;
    }

  /**
   * The runtime supplied its own account of what it is reasoning about.
   * Carried verbatim. Passing null explicitly clears it.
   */
  | { readonly type: 'reasoning.supplied'; readonly at: Timestamp; readonly text: string | null }

  /** Per-domain vigilance coverage. Replaces the record for that domain. */
  | {
      readonly type: 'coverage.reported';
      readonly at: Timestamp;
      readonly domain: DomainKey;
      readonly healthy: boolean;
      readonly freshnessSeconds: number | null;
    }
  /** A domain is no longer watched and should leave the coverage set. */
  | { readonly type: 'coverage.withdrawn'; readonly at: Timestamp; readonly domain: DomainKey }

  /**
   * The set of domains the system claims to watch. Domains named here but
   * never reported become `never-reported` gaps — this is what makes a silent
   * connector failure visible instead of invisible.
   */
  | { readonly type: 'coverage.expected'; readonly at: Timestamp; readonly domains: readonly DomainKey[] }

  /** A failure the founder has not yet seen acknowledged. */
  | { readonly type: 'failure.raised'; readonly at: Timestamp; readonly code: string; readonly detail: string; readonly domain: DomainKey }
  | { readonly type: 'failure.acknowledged'; readonly at: Timestamp; readonly code: string };

export type ObservationType = Observation['type'];

export const OBSERVATION_TYPES = [
  'mission.observed',
  'mission.cleared',
  'execution.observed',
  'approval.opened',
  'approval.closed',
  'action.recorded',
  'reasoning.supplied',
  'coverage.reported',
  'coverage.withdrawn',
  'coverage.expected',
  'failure.raised',
  'failure.acknowledged',
] as const;

/**
 * Structural validity of an observation.
 *
 * This is a shape check, not authorisation and not policy. The layer rejects
 * malformed input rather than folding it in and producing state that cannot be
 * explained. Rejection is silent to the caller by design: presence must not
 * throw into whatever is feeding it.
 */
export function isValidObservation(value: unknown): value is Observation {
  if (typeof value !== 'object' || value === null) return false;
  const o = value as Record<string, unknown>;
  if (typeof o['type'] !== 'string') return false;
  if (!(OBSERVATION_TYPES as readonly string[]).includes(o['type'])) return false;
  if (typeof o['at'] !== 'string' || o['at'].length === 0) return false;

  switch (o['type']) {
    case 'mission.observed':
      return (
        typeof o['ref'] === 'string' &&
        typeof o['title'] === 'string' &&
        typeof o['phase'] === 'string' &&
        typeof o['domain'] === 'string' &&
        typeof o['startedAt'] === 'string' &&
        (o['progress'] === null || typeof o['progress'] === 'number')
      );
    case 'mission.cleared':
      return typeof o['ref'] === 'string';
    case 'execution.observed':
      return (
        typeof o['phase'] === 'string' &&
        (o['executionId'] === null || typeof o['executionId'] === 'string') &&
        (o['failureCode'] === null || typeof o['failureCode'] === 'string')
      );
    case 'approval.opened':
      return (
        typeof o['approvalId'] === 'string' &&
        typeof o['prompt'] === 'string' &&
        typeof o['domain'] === 'string' &&
        (o['executionId'] === null || typeof o['executionId'] === 'string') &&
        (o['expiresAt'] === null || typeof o['expiresAt'] === 'string')
      );
    case 'approval.closed':
      return typeof o['approvalId'] === 'string';
    case 'action.recorded':
      return (
        typeof o['actor'] === 'string' &&
        typeof o['description'] === 'string' &&
        typeof o['domain'] === 'string' &&
        typeof o['succeeded'] === 'boolean'
      );
    case 'reasoning.supplied':
      return o['text'] === null || typeof o['text'] === 'string';
    case 'coverage.reported':
      return (
        typeof o['domain'] === 'string' &&
        typeof o['healthy'] === 'boolean' &&
        (o['freshnessSeconds'] === null || typeof o['freshnessSeconds'] === 'number')
      );
    case 'coverage.withdrawn':
      return typeof o['domain'] === 'string';
    case 'coverage.expected':
      return Array.isArray(o['domains']) && o['domains'].every((d) => typeof d === 'string');
    case 'failure.raised':
      return typeof o['code'] === 'string' && typeof o['detail'] === 'string' && typeof o['domain'] === 'string';
    case 'failure.acknowledged':
      return typeof o['code'] === 'string';
    default:
      return false;
  }
}
