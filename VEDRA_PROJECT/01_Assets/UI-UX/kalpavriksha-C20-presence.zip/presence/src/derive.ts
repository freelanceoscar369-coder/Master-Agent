/**
 * C20 · Derivation — pure projections from observed state to presence.
 *
 * Every function here is a pure function of its arguments. No clock is read
 * (the instant is always passed in), no randomness, no I/O, no mutation of
 * inputs. Given the same arguments twice, each returns deep-equal output.
 *
 * This is where "how Kalpavriksha feels right now" is computed — and it is
 * computed, never decided. Nothing here authorises, executes, or changes what
 * the system is permitted to do.
 */

import type {
  ActiveMission,
  CalmBlocker,
  CalmState,
  CurrentActivity,
  DomainCoverage,
  DomainKey,
  ExecutionStatus,
  PendingApproval,
  PresenceThresholds,
  ReasoningSummary,
  Timestamp,
  VigilanceGap,
  VigilanceState,
} from './types.ts';
import type { ObservedState, ObservedApproval, ObservedFailure } from './state.ts';

/* ───────────────────────────── time helpers ───────────────────────────── */

/** Whole seconds between two instants. Negative clamps to 0 — clock skew must not produce negative ages. */
export function secondsBetween(from: Timestamp, to: Timestamp): number {
  const a = Date.parse(from);
  const b = Date.parse(to);
  if (Number.isNaN(a) || Number.isNaN(b)) return 0;
  const d = Math.floor((b - a) / 1000);
  return d < 0 ? 0 : d;
}

/* ─────────────────────────── active mission ───────────────────────────── */

/**
 * The mission the founder should understand as current.
 *
 * Selection is deterministic and stated rather than clever:
 *   1. a `held` mission (it is the one most likely to need a human)
 *   2. otherwise a `running` mission
 *   3. otherwise the most recently started tracked mission
 * Ties break on the most recent `startedAt`, then lexically on `ref`, so the
 * result never depends on insertion order.
 */
export function deriveActiveMission(state: ObservedState): ActiveMission | null {
  const all = [...state.missions.values()];
  if (all.length === 0) return null;

  const rank = (phase: ActiveMission['phase']): number =>
    phase === 'held' ? 0 : phase === 'running' ? 1 : phase === 'queued' ? 2 : 3;

  const sorted = all.slice().sort((x, y) => {
    const r = rank(x.phase) - rank(y.phase);
    if (r !== 0) return r;
    const t = Date.parse(y.startedAt) - Date.parse(x.startedAt);
    if (t !== 0) return t;
    return x.ref < y.ref ? -1 : x.ref > y.ref ? 1 : 0;
  });

  return sorted[0] ?? null;
}

/* ────────────────────────── execution status ──────────────────────────── */

export function deriveExecution(state: ObservedState, now: Timestamp): ExecutionStatus {
  const e = state.execution;
  return {
    executionId: e.executionId,
    phase: e.phase,
    since: e.since,
    inPhaseSeconds: e.since === null ? null : secondsBetween(e.since, now),
    failureCode: e.failureCode,
  };
}

/* ────────────────────────── vigilance state ───────────────────────────── */

/**
 * Whether every domain the system claims to watch can be accounted for.
 *
 * Three ways a domain becomes a gap:
 *   · never-reported — it is expected but has never checked in. This is the
 *     silent-connector-failure case, and it is the reason `coverage.expected`
 *     exists at all.
 *   · stale — its last check is older than its freshness window.
 *   · unhealthy — it reported itself unhealthy.
 */
export function deriveVigilance(
  state: ObservedState,
  now: Timestamp,
  thresholds: PresenceThresholds,
): VigilanceState {
  const domains: DomainCoverage[] = [];
  const gaps: VigilanceGap[] = [];

  const expected = new Set<DomainKey>(state.expectedDomains);
  for (const d of state.coverage.keys()) expected.add(d);

  for (const domain of [...expected].sort()) {
    const record = state.coverage.get(domain);

    if (record === undefined) {
      gaps.push({
        domain,
        reason: 'never-reported',
        detail: `${domain} is watched but has never reported. I cannot account for it.`,
      });
      continue;
    }

    const freshness = record.freshnessSeconds ?? thresholds.defaultFreshnessSeconds;
    const age = secondsBetween(record.lastCheckedAt, now);

    domains.push({
      domain,
      lastCheckedAt: record.lastCheckedAt,
      healthy: record.healthy,
      freshnessSeconds: freshness,
    });

    if (!record.healthy) {
      gaps.push({ domain, reason: 'unhealthy', detail: `${domain} reported itself unhealthy.` });
    } else if (age > freshness) {
      gaps.push({
        domain,
        reason: 'stale',
        detail: `${domain} was last checked ${age}s ago, past its ${freshness}s window.`,
      });
    }
  }

  if (gaps.length === 0) {
    return { complete: true, domains, checkedAt: now };
  }
  return { complete: false, domains, gaps, checkedAt: now };
}

/* ───────────────────────── pending approvals ──────────────────────────── */

/** Oldest first — the thing waiting longest is the thing most owed an answer. */
export function derivePendingApprovals(state: ObservedState, now: Timestamp): readonly PendingApproval[] {
  return [...state.approvals.values()]
    .slice()
    .sort((a: ObservedApproval, b: ObservedApproval) => {
      const t = Date.parse(a.requestedAt) - Date.parse(b.requestedAt);
      if (t !== 0) return t;
      return a.approvalId < b.approvalId ? -1 : a.approvalId > b.approvalId ? 1 : 0;
    })
    .map((a) => ({
      approvalId: a.approvalId,
      executionId: a.executionId,
      prompt: a.prompt,
      requestedAt: a.requestedAt,
      expiresAt: a.expiresAt,
      domain: a.domain,
      waitingSeconds: secondsBetween(a.requestedAt, now),
    }));
}

/* ─────────────────────────── calm state ───────────────────────────────── */

/**
 * Calm is a claim, and this is where it is earned.
 *
 * Five independent blockers. Calm requires all five clear:
 *   · vigilance coverage complete
 *   · no pending approvals
 *   · no active execution
 *   · no held mission
 *   · no unacknowledged failure
 *
 * The union's calm member is unconstructable except at the single point below,
 * which is reachable only when the blocker list is empty. That is deliberate:
 * a future contributor cannot set `calm: true` from somewhere else without
 * deleting this function.
 */
export function deriveCalm(
  state: ObservedState,
  vigilance: VigilanceState,
  approvals: readonly PendingApproval[],
  execution: ExecutionStatus,
  activeMission: ActiveMission | null,
  now: Timestamp,
): CalmState {
  const blockers: CalmBlocker[] = [];

  if (!vigilance.complete) {
    const names = vigilance.gaps.map((g) => g.domain).join(', ');
    blockers.push({
      kind: 'coverage-incomplete',
      detail: `I cannot account for ${vigilance.gaps.length} domain(s): ${names}.`,
    });
  }

  if (approvals.length > 0) {
    blockers.push({
      kind: 'approval-pending',
      detail:
        approvals.length === 1
          ? 'One decision is waiting on you.'
          : `${approvals.length} decisions are waiting on you.`,
    });
  }

  const activePhases = ['dispatching', 'running', 'streaming', 'awaiting-approval', 'cancelling'];
  if (activePhases.includes(execution.phase)) {
    blockers.push({ kind: 'execution-active', detail: `An execution is ${execution.phase}.` });
  }

  if (activeMission !== null && activeMission.phase === 'held') {
    blockers.push({
      kind: 'mission-held',
      detail: `Mission ${activeMission.ref} is held and cannot proceed.`,
    });
  }

  const unacked = [...state.failures.values()].filter((f: ObservedFailure) => !f.acknowledged);
  if (unacked.length > 0) {
    blockers.push({
      kind: 'failure-unacknowledged',
      detail:
        unacked.length === 1
          ? `One failure is unacknowledged: ${unacked[0]?.code ?? 'unknown'}.`
          : `${unacked.length} failures are unacknowledged.`,
    });
  }

  if (blockers.length === 0) {
    return {
      calm: true,
      since: state.calmSince ?? now,
      statement: 'Nothing needs you.',
    };
  }

  return {
    calm: false,
    reasons: blockers,
    statement: blockers[0]?.detail ?? 'Something needs you.',
  };
}

/* ──────────────────────── reasoning summary ───────────────────────────── */

/**
 * Carried, never generated.
 *
 * When the runtime has supplied nothing, `text` is null and the layer says so.
 * It does not fill the silence with a plausible sentence — that would be the
 * AI logic this layer is forbidden from having.
 */
export function deriveReasoning(
  state: ObservedState,
  now: Timestamp,
  thresholds: PresenceThresholds,
): ReasoningSummary {
  if (state.reasoning === null || state.reasoning.text === null) {
    return { text: null, suppliedAt: state.reasoning?.at ?? null, ageSeconds: null, stale: false };
  }
  const age = secondsBetween(state.reasoning.at, now);
  return {
    text: state.reasoning.text,
    suppliedAt: state.reasoning.at,
    ageSeconds: age,
    stale: age > thresholds.reasoningStaleSeconds,
  };
}

/* ────────────────────────── current activity ──────────────────────────── */

/**
 * One deterministic line describing what is happening.
 *
 * Composed from structured facts by fixed template. Precedence is stated, not
 * emergent: degraded ▸ waiting ▸ blocked ▸ working ▸ idle. There is no
 * inference and no generation — every branch below could be written out as a
 * lookup table, and effectively is.
 */
export function deriveActivity(
  vigilance: VigilanceState,
  approvals: readonly PendingApproval[],
  execution: ExecutionStatus,
  activeMission: ActiveMission | null,
  state: ObservedState,
): CurrentActivity {
  const domains = new Set<DomainKey>();
  for (const m of state.missions.values()) {
    if (m.phase === 'running' || m.phase === 'held') domains.add(m.domain);
  }
  const domainList = [...domains].sort();

  if (!vigilance.complete) {
    const n = vigilance.gaps.length;
    return {
      kind: 'degraded',
      line: `Working, but I cannot account for ${n} domain${n === 1 ? '' : 's'}.`,
      since: execution.since,
      domains: domainList,
    };
  }

  if (approvals.length > 0) {
    const n = approvals.length;
    return {
      kind: 'waiting-on-founder',
      line: n === 1 ? 'Waiting on your decision.' : `Waiting on ${n} decisions.`,
      since: approvals[0]?.requestedAt ?? null,
      domains: domainList,
    };
  }

  if (activeMission !== null && activeMission.phase === 'held') {
    return {
      kind: 'blocked',
      line: `Held on ${activeMission.title}.`,
      since: activeMission.startedAt,
      domains: domainList,
    };
  }

  const working = ['dispatching', 'running', 'streaming', 'cancelling'];
  if (working.includes(execution.phase) || (activeMission !== null && activeMission.phase === 'running')) {
    const line =
      activeMission !== null && activeMission.phase === 'running'
        ? `Working on ${activeMission.title}.`
        : 'Working.';
    return { kind: 'working', line, since: execution.since, domains: domainList };
  }

  return { kind: 'idle', line: 'Idle.', since: execution.since, domains: domainList };
}
