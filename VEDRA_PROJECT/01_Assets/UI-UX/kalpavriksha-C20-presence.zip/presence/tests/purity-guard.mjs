#!/usr/bin/env node
/**
 * C20 purity guard.
 *
 * Mechanically enforces the containment rule: the Presence Layer must import
 * nothing outside its own src/ directory, and must not reference any I/O,
 * timing or global-state capability.
 *
 * This is the difference between "the layer cannot execute tools" as a claim
 * and as a checked property. Run it in CI.
 */
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join, dirname, resolve, extname } from 'node:path';
import { fileURLToPath } from 'node:url';

const SRC = resolve(dirname(fileURLToPath(import.meta.url)), '..', 'src');

const files = [];
(function walk(d) {
  for (const n of readdirSync(d)) {
    const p = join(d, n);
    if (statSync(p).isDirectory()) walk(p);
    else if (extname(p) === '.ts') files.push(p);
  }
})(SRC);

// Capabilities the layer must not have. Each maps to a brief prohibition.
const FORBIDDEN = [
  [/\bfetch\s*\(/, 'network I/O — the layer must never call out'],
  [/\bXMLHttpRequest\b/, 'network I/O'],
  [/\bWebSocket\b/, 'network I/O'],
  [/\bEventSource\b/, 'network I/O'],
  [/from\s+['"]node:(fs|net|http|https|child_process|worker_threads|dgram|tls)['"]/, 'system I/O'],
  [/\brequire\s*\(/, 'dynamic require'],
  [/\bimport\s*\(/, 'dynamic import'],
  [/\bprocess\.(env|exit|argv)/, 'process access'],
  [/\bsetTimeout\s*\(|\bsetInterval\s*\(/, 'scheduling — the layer must have no background behaviour'],
  [/\bDate\.now\s*\(/, 'hidden clock — every instant must be passed in'],
  [/\bnew\s+Date\s*\(\s*\)/, 'hidden clock'],
  [/\bMath\.random\s*\(/, 'non-determinism'],
  [/\bglobalThis\b/, 'global state access'],
  [/\bexecute\s*\(|\binvoke\s*\(|\bauthorize\s*\(|\bauthorise\s*\(/, 'execution or authorisation surface'],
];

let findings = 0;
let importCount = 0;

for (const f of files) {
  const src = readFileSync(f, 'utf8');
  const rel = f.slice(SRC.length + 1);

  for (const m of src.matchAll(/(?:from|import)\s*['"]([^'"]+)['"]/g)) {
    const spec = m[1];
    importCount++;
    if (spec.startsWith('.')) {
      const target = resolve(dirname(f), spec);
      if (!target.startsWith(SRC)) {
        console.log(`  ESCAPES PACKAGE  ${rel} → ${spec}`);
        findings++;
      }
      continue;
    }
    console.log(`  EXTERNAL IMPORT  ${rel} → ${spec}`);
    findings++;
  }

  for (const [re, why] of FORBIDDEN) {
    // Skip matches that occur inside a comment line.
    for (const m of src.matchAll(new RegExp(re.source, 'g'))) {
      const lineStart = src.lastIndexOf('\n', m.index) + 1;
      const line = src.slice(lineStart, src.indexOf('\n', m.index));
      const trimmed = line.trimStart();
      if (trimmed.startsWith('*') || trimmed.startsWith('//') || trimmed.startsWith('/*')) continue;
      const lineNo = src.slice(0, m.index).split('\n').length;
      console.log(`  FORBIDDEN  ${rel}:${lineNo}  ${why}  (${m[0].trim()})`);
      findings++;
    }
  }
}

console.log('C20 PURITY GUARD');
console.log('─'.repeat(52));
console.log(`modules          ${files.length}`);
console.log(`imports          ${importCount} (all must be package-internal)`);
console.log(`external deps    ${JSON.stringify(Object.keys(JSON.parse(readFileSync(resolve(SRC,'..','package.json'),'utf8')).dependencies ?? {}))}`);
console.log(`findings         ${findings}`);
console.log(findings === 0 ? '\nRESULT: CONTAINED' : '\nRESULT: CONTAINMENT BREACH');
process.exit(findings === 0 ? 0 : 1);
