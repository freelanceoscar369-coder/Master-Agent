/**
 * Tests for createPresenceLayer.
 */

import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { createPresenceLayer } from '../src/presenceLayer.ts';
import {
  at,
  healthyLayer,
  missionObserved,
  missionCleared,
  executionObserved,
  approvalOpened,
  approvalClosed,
  coverageReported,
  coverageExpected,
  failureRaised,
  failureAcknowledged,
  reasoningSupplied,
  actionRecorded,
} from './helpers.ts';

/* ─────────────────────────── observe ──────────────────────────────────── */

describe('observe — rejects malformed input', () => {
  test('returns {accepted:false} for null', () => {
    const layer = createPresenceLayer();
    const result = layer.observe(null);
    assert.strictEqual(result.accepted, false);
  });

  test('returns {accepted:false} for undefined', () => {
    const layer = createPresenceLayer();
    const result = layer.observe(undefined);
    assert.strictEqual(result.accepted, false);
  });

  test('returns {accepted:false} for empty object', () => {
    const layer = createPresenceLayer();
    const result = layer.observe({});
    assert.strictEqual(result.accepted, false);
  });

  test('does NOT increment observationCount on reject', () => {
    const layer = createPresenceLayer();
    layer.observe(null);
    layer.observe(undefined);
    layer.observe({});
    assert.strictEqual(layer.observedState().observationCount, 0);
  });

  test('does NOT notify subscribers on reject', () => {
    const layer = createPresenceLayer();
    let callCount = 0;
    layer.subscribe(() => { callCount++; });
    layer.observe(null);
    layer.observe({});
    assert.strictEqual(callCount, 0);
  });

  test('observationCount is preserved in rejected result', () => {
    const layer = createPresenceLayer();
    layer.observe(missionObserved({ at: at(0) }));
    const result = layer.observe(null);
    assert.strictEqual(result.observationCount, 1);
  });
});

describe('observe — accepts valid input', () => {
  test('returns {accepted:true} for valid observation', () => {
    const layer = createPresenceLayer();
    const result = layer.observe(missionObserved({ at: at(0) }));
    assert.strictEqual(result.accepted, true);
  });

  test('increments observationCount', () => {
    const layer = createPresenceLayer();
    layer.observe(missionObserved({ at: at(0) }));
    assert.strictEqual(layer.observedState().observationCount, 1);
  });

  test('notifies subscribers synchronously exactly once per observe', () => {
    const layer = createPresenceLayer();
    let callCount = 0;
    layer.subscribe(() => { callCount++; });
    layer.observe(missionObserved({ at: at(0) }));
    assert.strictEqual(callCount, 1);
  });

  test('notifies all subscribers synchronously during observe', () => {
    const layer = createPresenceLayer();
    const calls: number[] = [];
    layer.subscribe(() => { calls.push(1); });
    layer.subscribe(() => { calls.push(2); });
    layer.observe(missionObserved({ at: at(0) }));
    assert.strictEqual(calls.length, 2);
    assert.ok(calls.includes(1));
    assert.ok(calls.includes(2));
  });
});

/* ─────────────────────────── snapshot ─────────────────────────────────── */

describe('snapshot', () => {
  test('deterministic: two calls with same now and no intervening obs are deep-equal', () => {
    const layer = healthyLayer();
    const s1 = layer.snapshot(at(100));
    const s2 = layer.snapshot(at(100));
    assert.deepStrictEqual(s1, s2);
  });

  test('JSON round-trips identically (serialisable)', () => {
    const layer = healthyLayer();
    const snap = layer.snapshot(at(100));
    const json = JSON.stringify(snap);
    const parsed = JSON.parse(json);
    assert.deepStrictEqual(parsed, snap);
  });

  test('sequence does NOT advance on snapshot calls', () => {
    const layer = healthyLayer();
    const seqBefore = layer.snapshot(at(100)).sequence;
    layer.snapshot(at(100));
    layer.snapshot(at(101));
    layer.snapshot(at(102));
    assert.strictEqual(layer.snapshot(at(103)).sequence, seqBefore);
  });
});

/* ─────────────────────────── sequence ──────────────────────────────────── */

describe('sequence', () => {
  test('reflects accepted observations only', () => {
    const layer = createPresenceLayer();
    assert.strictEqual(layer.snapshot(at(0)).sequence, 0);
    layer.observe(missionObserved({ at: at(1) }));
    assert.strictEqual(layer.snapshot(at(1)).sequence, 1);
    layer.observe(missionObserved({ at: at(2) }));
    assert.strictEqual(layer.snapshot(at(2)).sequence, 2);
  });

  test('does NOT advance on rejected observations', () => {
    const layer = createPresenceLayer();
    layer.observe(missionObserved({ at: at(1) }));
    layer.observe(null);
    layer.observe({});
    assert.strictEqual(layer.snapshot(at(1)).sequence, 1);
  });
});

/* ──────────────────────── snapshot immutability ───────────────────────── */

describe('snapshot immutability across time', () => {
  test('held snapshot is unchanged after more observations are folded', () => {
    const layer = healthyLayer();
    const held = layer.snapshot(at(10));
    layer.observe(missionObserved({ at: at(11), ref: 'M1', phase: 'running' }));
    layer.observe(missionObserved({ at: at(12), ref: 'M2', phase: 'held' }));
    // held snapshot should still reflect state at at(10), not the new missions
    assert.strictEqual(held.activeMission, null);
  });
});

/* ──────────────────────── subscribe / unsubscribe ──────────────────────── */

describe('subscribe/unsubscribe', () => {
  test('multi-listener fan-out: both listeners receive the snapshot', () => {
    const layer = createPresenceLayer();
    const received: number[] = [];
    layer.subscribe(() => received.push(1));
    layer.subscribe(() => received.push(2));
    layer.observe(missionObserved({ at: at(0) }));
    assert.ok(received.includes(1));
    assert.ok(received.includes(2));
  });

  test('unsubscribe stops receiving notifications', () => {
    const layer = createPresenceLayer();
    let count = 0;
    const unsub = layer.subscribe(() => count++);
    layer.observe(missionObserved({ at: at(0) }));
    unsub();
    layer.observe(missionObserved({ at: at(1) }));
    assert.strictEqual(count, 1);
  });

  test('idempotent double-unsubscribe does not throw', () => {
    const layer = createPresenceLayer();
    const unsub = layer.subscribe(() => {});
    unsub();
    assert.doesNotThrow(() => unsub());
  });

  test('listenerCount() is accurate', () => {
    const layer = createPresenceLayer();
    assert.strictEqual(layer.listenerCount(), 0);
    const u1 = layer.subscribe(() => {});
    assert.strictEqual(layer.listenerCount(), 1);
    const u2 = layer.subscribe(() => {});
    assert.strictEqual(layer.listenerCount(), 2);
    u1();
    assert.strictEqual(layer.listenerCount(), 1);
    u2();
    assert.strictEqual(layer.listenerCount(), 0);
  });

  test('reset() clears listeners and state and resets sequence', () => {
    const layer = createPresenceLayer();
    layer.subscribe(() => {});
    layer.subscribe(() => {});
    layer.observe(missionObserved({ at: at(0) }));
    layer.observe(missionObserved({ at: at(1) }));
    layer.reset();
    assert.strictEqual(layer.listenerCount(), 0);
    assert.strictEqual(layer.observedState().observationCount, 0);
    assert.strictEqual(layer.snapshot(at(5)).sequence, 0);
  });
});

/* ─────────────────────────── observeAll ───────────────────────────────── */

describe('observeAll', () => {
  test('folds in order and returns the last result', () => {
    const layer = createPresenceLayer();
    const result = layer.observeAll([
      missionObserved({ at: at(0), ref: 'M1' }),
      missionObserved({ at: at(1), ref: 'M2' }),
      missionObserved({ at: at(2), ref: 'M3' }),
    ]);
    assert.strictEqual(result.accepted, true);
    assert.strictEqual(result.observationCount, 3);
  });

  test('skips invalid observations in the list', () => {
    const layer = createPresenceLayer();
    const result = layer.observeAll([
      missionObserved({ at: at(0) }),
      null,
      missionObserved({ at: at(2) }),
    ]);
    // Last one was valid
    assert.strictEqual(result.accepted, true);
    assert.strictEqual(layer.observedState().observationCount, 2);
  });
});

/* ──────────────────────── meta.possiblyStale ───────────────────────────── */

describe('meta.possiblyStale', () => {
  test('false immediately after an observation', () => {
    const layer = createPresenceLayer();
    layer.observe(missionObserved({ at: at(0) }));
    const snap = layer.snapshot(at(0));
    assert.strictEqual(snap.meta.possiblyStale, false);
  });

  test('false just within silenceSeconds boundary', () => {
    const layer = createPresenceLayer({ thresholds: { silenceSeconds: 120 } });
    layer.observe(missionObserved({ at: at(0) }));
    // 120 seconds later — exactly at boundary (not > 120)
    const snap = layer.snapshot(at(120));
    assert.strictEqual(snap.meta.possiblyStale, false);
  });

  test('true once now exceeds silenceSeconds past lastObservedAt', () => {
    const layer = createPresenceLayer({ thresholds: { silenceSeconds: 120 } });
    layer.observe(missionObserved({ at: at(0) }));
    // 121 seconds later — just over boundary
    const snap = layer.snapshot(at(121));
    assert.strictEqual(snap.meta.possiblyStale, true);
  });
});

/* ─────────────────────────── calmSince ────────────────────────────────── */

describe('calmSince', () => {
  test('set when layer first becomes calm', () => {
    const layer = createPresenceLayer();
    layer.observe(coverageReported({ domain: 'D1', healthy: true, freshnessSeconds: 300, at: at(10) }));
    const snap = layer.snapshot(at(10));
    assert.ok(snap.calm.calm);
    assert.ok(typeof snap.calm.since === 'string');
  });

  test('preserved across further observations while calm holds (not a moving value)', () => {
    const layer = createPresenceLayer();
    layer.observe(coverageReported({ domain: 'D1', healthy: true, freshnessSeconds: 300, at: at(10) }));
    const snap1 = layer.snapshot(at(10));
    assert.ok(snap1.calm.calm);
    const calmSince1 = snap1.calm.since;

    layer.observe(coverageReported({ domain: 'D1', healthy: true, freshnessSeconds: 300, at: at(20) }));
    const snap2 = layer.snapshot(at(20));
    assert.ok(snap2.calm.calm);
    assert.strictEqual(snap2.calm.since, calmSince1);
  });

  test('cleared when calm breaks', () => {
    const layer = createPresenceLayer();
    layer.observe(coverageReported({ domain: 'D1', healthy: true, freshnessSeconds: 300, at: at(10) }));
    const snap1 = layer.snapshot(at(10));
    assert.ok(snap1.calm.calm);

    // Add a failure to break calm
    layer.observe(failureRaised({ code: 'ERR_X', domain: 'D1', at: at(20) }));
    const snap2 = layer.snapshot(at(20));
    assert.ok(!snap2.calm.calm);
  });

  test('set afresh on re-entering calm', () => {
    const layer = createPresenceLayer();
    layer.observe(coverageReported({ domain: 'D1', healthy: true, freshnessSeconds: 300, at: at(10) }));
    const snap1 = layer.snapshot(at(10));
    assert.ok(snap1.calm.calm);
    const calmSince1 = snap1.calm.since;

    // Break calm
    layer.observe(failureRaised({ code: 'ERR_X', domain: 'D1', at: at(20) }));

    // Restore calm
    layer.observe(failureAcknowledged({ code: 'ERR_X', at: at(30) }));
    const snap3 = layer.snapshot(at(30));
    assert.ok(snap3.calm.calm);
    // calmSince should be afresh (different from the first calm period)
    assert.notStrictEqual(snap3.calm.since, calmSince1);
  });
});

/* ──────────────────────── custom thresholds ────────────────────────────── */

describe('custom thresholds', () => {
  test('tiny reasoningStaleSeconds causes stale to flip', () => {
    const layer = createPresenceLayer({ thresholds: { reasoningStaleSeconds: 5 } });
    layer.observe(reasoningSupplied({ at: at(0), text: 'Thinking.' }));

    const snapFresh = layer.snapshot(at(5));
    assert.strictEqual(snapFresh.reasoning.stale, false);

    const snapStale = layer.snapshot(at(6));
    assert.strictEqual(snapStale.reasoning.stale, true);
  });
});

/* ─────────────────────────── end-to-end ───────────────────────────────── */

describe('end-to-end sequence', () => {
  test('realistic sequence tells a coherent story', () => {
    const layer = createPresenceLayer();

    // Step 1: declare expected coverage
    layer.observe(coverageExpected({ at: at(0), domains: ['domain-a', 'domain-b'] }));
    const snap1 = layer.snapshot(at(0));
    assert.ok(!snap1.calm.calm, 'not calm: coverage not yet reported');

    // Step 2: report coverage for both domains
    layer.observe(coverageReported({ at: at(1), domain: 'domain-a', healthy: true, freshnessSeconds: 300 }));
    layer.observe(coverageReported({ at: at(2), domain: 'domain-b', healthy: true, freshnessSeconds: 300 }));
    const snap2 = layer.snapshot(at(2));
    assert.ok(snap2.calm.calm, 'calm after both domains reported healthy');
    assert.strictEqual(snap2.activity.kind, 'idle');

    // Step 3: start a mission
    layer.observe(missionObserved({ at: at(3), ref: 'M1', phase: 'running', domain: 'domain-a', title: 'Deploy feature' }));
    const snap3 = layer.snapshot(at(3));
    assert.strictEqual(snap3.activity.kind, 'working');
    assert.strictEqual(snap3.activeMission?.ref, 'M1');
    // A running mission does NOT block calm — only held missions and active execution phases do.
    assert.ok(snap3.calm.calm, 'calm can coexist with a running mission (only held/execution-active block it)');

    // Step 4: open an approval
    layer.observe(approvalOpened({ at: at(4), approvalId: 'AP-1', prompt: 'Approve deployment?' }));
    const snap4 = layer.snapshot(at(4));
    assert.ok(!snap4.calm.calm, 'not calm: approval pending');
    assert.strictEqual(snap4.activity.kind, 'waiting-on-founder');
    assert.strictEqual(snap4.pendingApprovals.length, 1);

    // Step 5: close the approval
    layer.observe(approvalClosed({ at: at(5), approvalId: 'AP-1' }));
    const snap5 = layer.snapshot(at(5));
    assert.strictEqual(snap5.pendingApprovals.length, 0);

    // Step 6: complete the mission
    layer.observe(missionObserved({ at: at(6), ref: 'M1', phase: 'completed', domain: 'domain-a', title: 'Deploy feature' }));
    layer.observe(missionCleared({ at: at(7), ref: 'M1' }));
    const snap6 = layer.snapshot(at(7));
    assert.strictEqual(snap6.activeMission, null);
    assert.ok(snap6.calm.calm, 'calm restored after mission cleared');

    // Observation counts increase monotonically
    assert.ok(snap6.meta.observationCount > snap5.meta.observationCount);
  });
});
