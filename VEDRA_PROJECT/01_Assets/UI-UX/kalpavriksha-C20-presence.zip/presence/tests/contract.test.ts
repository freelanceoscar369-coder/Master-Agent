/**
 * Tests for the layer's public contract — structural guarantees.
 */

import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import * as api from '../src/index.ts';
import { createPresenceLayer } from '../src/presenceLayer.ts';
import { TERMINOLOGY_RECONCILIATION, CALM_BLOCKER_KINDS } from '../src/types.ts';
import type { PresenceSnapshot } from '../src/types.ts';
import {
  at,
  healthyLayer,
  missionObserved,
  missionCleared,
  executionObserved,
  approvalOpened,
  approvalClosed,
  coverageReported,
  coverageExpected,
  failureRaised,
  failureAcknowledged,
  actionRecorded,
} from './helpers.ts';

/* ──────────── every PresenceSnapshot has all 8 mandated fields ──────────── */

describe('PresenceSnapshot — all 8 brief-mandated fields present', () => {
  function assertMandatoryFields(snap: PresenceSnapshot): void {
    assert.ok(Object.hasOwn(snap, 'activeMission'), 'activeMission');
    assert.ok(Object.hasOwn(snap, 'execution'), 'execution');
    assert.ok(Object.hasOwn(snap, 'calm'), 'calm');
    assert.ok(Object.hasOwn(snap, 'vigilance'), 'vigilance');
    assert.ok(Object.hasOwn(snap, 'activity'), 'activity');
    assert.ok(Object.hasOwn(snap, 'pendingApprovals'), 'pendingApprovals');
    assert.ok(Object.hasOwn(snap, 'lastAction'), 'lastAction');
    assert.ok(Object.hasOwn(snap, 'reasoning'), 'reasoning');
  }

  test('empty state snapshot has all 8 fields', () => {
    const layer = createPresenceLayer();
    assertMandatoryFields(layer.snapshot(at(0)));
  });

  test('healthy baseline snapshot has all 8 fields', () => {
    assertMandatoryFields(healthyLayer().snapshot(at(10)));
  });

  test('snapshot with active mission has all 8 fields', () => {
    const layer = healthyLayer();
    layer.observe(missionObserved({ at: at(5), ref: 'M1' }));
    assertMandatoryFields(layer.snapshot(at(10)));
  });

  test('snapshot with approval pending has all 8 fields', () => {
    const layer = healthyLayer();
    layer.observe(approvalOpened({ at: at(5) }));
    assertMandatoryFields(layer.snapshot(at(10)));
  });

  test('snapshot with execution active has all 8 fields', () => {
    const layer = healthyLayer();
    layer.observe(executionObserved({ at: at(5), phase: 'running' }));
    assertMandatoryFields(layer.snapshot(at(10)));
  });

  test('snapshot with failure raised has all 8 fields', () => {
    const layer = healthyLayer();
    layer.observe(failureRaised({ at: at(5), code: 'ERR_X' }));
    assertMandatoryFields(layer.snapshot(at(10)));
  });

  test('snapshot with lastAction has all 8 fields (including non-null lastAction)', () => {
    const layer = healthyLayer();
    layer.observe(actionRecorded({ at: at(5) }));
    const snap = layer.snapshot(at(10));
    assertMandatoryFields(snap);
    assert.ok(Object.hasOwn(snap, 'lastAction'));
    assert.notStrictEqual(snap.lastAction, null);
  });

  test('activeMission is null-valued but field is still present', () => {
    const layer = createPresenceLayer();
    const snap = layer.snapshot(at(0));
    assert.ok(Object.hasOwn(snap, 'activeMission'));
    assert.strictEqual(snap.activeMission, null);
  });

  test('lastAction is null-valued but field is still present', () => {
    const layer = createPresenceLayer();
    const snap = layer.snapshot(at(0));
    assert.ok(Object.hasOwn(snap, 'lastAction'));
    assert.strictEqual(snap.lastAction, null);
  });

  test('reasoning.text can be null but reasoning field is present', () => {
    const layer = createPresenceLayer();
    const snap = layer.snapshot(at(0));
    assert.ok(Object.hasOwn(snap, 'reasoning'));
    assert.strictEqual(snap.reasoning.text, null);
  });
});

/* ─────────────── TERMINOLOGY_RECONCILIATION structure ───────────────────── */

describe('TERMINOLOGY_RECONCILIATION', () => {
  test('is non-empty', () => {
    assert.ok(TERMINOLOGY_RECONCILIATION.length > 0);
  });

  test('every entry has non-empty assumed and question', () => {
    for (const entry of TERMINOLOGY_RECONCILIATION) {
      assert.ok(typeof entry.assumed === 'string' && entry.assumed.length > 0,
        `assumed must be non-empty string`);
      assert.ok(typeof entry.question === 'string' && entry.question.length > 0,
        `question must be non-empty string`);
    }
  });
});

/* ──────────────────── CALM_BLOCKER_KINDS has exactly 5 ─────────────────── */

describe('CALM_BLOCKER_KINDS', () => {
  test('has exactly 5 entries', () => {
    assert.strictEqual(CALM_BLOCKER_KINDS.length, 5);
  });

  test('contains expected values', () => {
    const kinds = [...CALM_BLOCKER_KINDS];
    assert.ok(kinds.includes('coverage-incomplete'));
    assert.ok(kinds.includes('approval-pending'));
    assert.ok(kinds.includes('execution-active'));
    assert.ok(kinds.includes('mission-held'));
    assert.ok(kinds.includes('failure-unacknowledged'));
  });
});

/* ─────────────────── the layer never invents reasoning ─────────────────── */

describe('The layer never invents reasoning', () => {
  test('reasoning.text is null in every snapshot when reasoning.supplied was never called', () => {
    const layer = createPresenceLayer();

    // Long sequence of observations that never includes reasoning.supplied
    layer.observe(coverageExpected({ at: at(0), domains: ['D1'] }));
    layer.observe(coverageReported({ at: at(1), domain: 'D1', healthy: true, freshnessSeconds: 300 }));
    layer.observe(missionObserved({ at: at(2), ref: 'M1', phase: 'running', domain: 'D1' }));
    layer.observe(executionObserved({ at: at(3), phase: 'running' }));
    layer.observe(approvalOpened({ at: at(4), approvalId: 'A1' }));
    layer.observe(approvalClosed({ at: at(5), approvalId: 'A1' }));
    layer.observe(failureRaised({ at: at(6), code: 'ERR_X', domain: 'D1' }));
    layer.observe(failureAcknowledged({ at: at(7), code: 'ERR_X' }));
    layer.observe(actionRecorded({ at: at(8) }));
    layer.observe(missionMadeCompleted(at(9)));
    layer.observe(missionCleared({ at: at(10), ref: 'M1' }));

    // Every snapshot should have reasoning.text === null
    for (let i = 0; i <= 15; i++) {
      const snap = layer.snapshot(at(i));
      assert.strictEqual(snap.reasoning.text, null,
        `reasoning.text must be null at t=${i}`);
    }
  });
});

function missionMadeCompleted(timestamp: string) {
  return {
    type: 'mission.observed' as const,
    at: timestamp,
    ref: 'M1',
    title: 'Test Mission',
    phase: 'completed' as const,
    progress: null,
    domain: 'D1',
    startedAt: at(2),
  };
}

/* ─────────────── public surface exposes no execution capability ─────────── */

describe('Public surface exposes no execution capability', () => {
  test('no exported key matching /execute|invoke|authorize|authorise|mutate|write|commit|dispatch/i', () => {
    const forbidden = /execute|invoke|authorize|authorise|mutate|write|commit|dispatch/i;
    const keys = Object.keys(api);
    for (const key of keys) {
      assert.ok(!forbidden.test(key),
        `Exported key "${key}" matches forbidden pattern — the layer must not expose execution capability`);
    }
  });
});
