/**
 * Test helpers — deterministic timestamps and typed observation factories.
 * No real clock. No `any`.
 */

import type { Observation } from '../src/observations.ts';
import type {
  ActorKind,
  ApprovalId,
  DomainKey,
  ExecutionId,
  ExecutionPhase,
  MissionPhase,
  MissionRef,
  Timestamp,
} from '../src/types.ts';
import { createPresenceLayer } from '../src/presenceLayer.ts';
import type { PresenceLayer } from '../src/presenceLayer.ts';

/* ─────────────────────────── timestamps ───────────────────────────────── */

/** Fixed base: 2026-08-06T10:00:00Z */
const BASE_MS = Date.parse('2026-08-06T10:00:00Z');

/** Returns a deterministic ISO timestamp at BASE + n seconds. */
export function at(seconds: number): Timestamp {
  return new Date(BASE_MS + seconds * 1000).toISOString();
}

/* ──────────────────────── observation factories ────────────────────────── */

export function missionObserved(
  overrides: Partial<{
    at: Timestamp;
    ref: MissionRef;
    title: string;
    phase: MissionPhase;
    progress: number | null;
    domain: DomainKey;
    startedAt: Timestamp;
  }> = {},
): Observation {
  return {
    type: 'mission.observed',
    at: overrides.at ?? at(0),
    ref: overrides.ref ?? 'mission-1',
    title: overrides.title ?? 'Test Mission',
    phase: overrides.phase ?? 'running',
    progress: overrides.progress !== undefined ? overrides.progress : null,
    domain: overrides.domain ?? 'domain-a',
    startedAt: overrides.startedAt ?? at(0),
  };
}

export function missionCleared(
  overrides: Partial<{ at: Timestamp; ref: MissionRef }> = {},
): Observation {
  return {
    type: 'mission.cleared',
    at: overrides.at ?? at(1),
    ref: overrides.ref ?? 'mission-1',
  };
}

export function executionObserved(
  overrides: Partial<{
    at: Timestamp;
    executionId: ExecutionId | null;
    phase: ExecutionPhase;
    failureCode: string | null;
  }> = {},
): Observation {
  return {
    type: 'execution.observed',
    at: overrides.at ?? at(0),
    executionId: overrides.executionId !== undefined ? overrides.executionId : 'exec-1',
    phase: overrides.phase ?? 'running',
    failureCode: overrides.failureCode !== undefined ? overrides.failureCode : null,
  };
}

export function approvalOpened(
  overrides: Partial<{
    at: Timestamp;
    approvalId: ApprovalId;
    executionId: ExecutionId | null;
    prompt: string;
    domain: DomainKey;
    expiresAt: Timestamp | null;
  }> = {},
): Observation {
  return {
    type: 'approval.opened',
    at: overrides.at ?? at(0),
    approvalId: overrides.approvalId ?? 'approval-1',
    executionId: overrides.executionId !== undefined ? overrides.executionId : null,
    prompt: overrides.prompt ?? 'Please approve this action.',
    domain: overrides.domain ?? 'domain-a',
    expiresAt: overrides.expiresAt !== undefined ? overrides.expiresAt : null,
  };
}

export function approvalClosed(
  overrides: Partial<{ at: Timestamp; approvalId: ApprovalId }> = {},
): Observation {
  return {
    type: 'approval.closed',
    at: overrides.at ?? at(1),
    approvalId: overrides.approvalId ?? 'approval-1',
  };
}

export function actionRecorded(
  overrides: Partial<{
    at: Timestamp;
    actor: ActorKind;
    description: string;
    domain: DomainKey;
    succeeded: boolean;
  }> = {},
): Observation {
  return {
    type: 'action.recorded',
    at: overrides.at ?? at(0),
    actor: overrides.actor ?? 'kernel',
    description: overrides.description ?? 'Performed an action.',
    domain: overrides.domain ?? 'domain-a',
    succeeded: overrides.succeeded !== undefined ? overrides.succeeded : true,
  };
}

export function reasoningSupplied(
  overrides: Partial<{ at: Timestamp; text: string | null }> = {},
): Observation {
  return {
    type: 'reasoning.supplied',
    at: overrides.at ?? at(0),
    text: overrides.text !== undefined ? overrides.text : 'Evaluating current mission state.',
  };
}

export function coverageReported(
  overrides: Partial<{
    at: Timestamp;
    domain: DomainKey;
    healthy: boolean;
    freshnessSeconds: number | null;
  }> = {},
): Observation {
  return {
    type: 'coverage.reported',
    at: overrides.at ?? at(0),
    domain: overrides.domain ?? 'domain-a',
    healthy: overrides.healthy !== undefined ? overrides.healthy : true,
    freshnessSeconds: overrides.freshnessSeconds !== undefined ? overrides.freshnessSeconds : 300,
  };
}

export function coverageWithdrawn(
  overrides: Partial<{ at: Timestamp; domain: DomainKey }> = {},
): Observation {
  return {
    type: 'coverage.withdrawn',
    at: overrides.at ?? at(1),
    domain: overrides.domain ?? 'domain-a',
  };
}

export function coverageExpected(
  overrides: Partial<{ at: Timestamp; domains: readonly DomainKey[] }> = {},
): Observation {
  return {
    type: 'coverage.expected',
    at: overrides.at ?? at(0),
    domains: overrides.domains ?? ['domain-a', 'domain-b'],
  };
}

export function failureRaised(
  overrides: Partial<{
    at: Timestamp;
    code: string;
    detail: string;
    domain: DomainKey;
  }> = {},
): Observation {
  return {
    type: 'failure.raised',
    at: overrides.at ?? at(0),
    code: overrides.code ?? 'ERR_TEST',
    detail: overrides.detail ?? 'A test failure occurred.',
    domain: overrides.domain ?? 'domain-a',
  };
}

export function failureAcknowledged(
  overrides: Partial<{ at: Timestamp; code: string }> = {},
): Observation {
  return {
    type: 'failure.acknowledged',
    at: overrides.at ?? at(1),
    code: overrides.code ?? 'ERR_TEST',
  };
}

/* ─────────────────────────── healthy layer ────────────────────────────── */

/**
 * Returns a layer with two covered, healthy domains so tests that need a
 * calm baseline don't repeat setup.
 */
export function healthyLayer(): PresenceLayer {
  const layer = createPresenceLayer();
  layer.observe(coverageExpected({ at: at(0), domains: ['domain-a', 'domain-b'] }));
  layer.observe(coverageReported({ at: at(1), domain: 'domain-a', healthy: true, freshnessSeconds: 300 }));
  layer.observe(coverageReported({ at: at(2), domain: 'domain-b', healthy: true, freshnessSeconds: 300 }));
  return layer;
}
