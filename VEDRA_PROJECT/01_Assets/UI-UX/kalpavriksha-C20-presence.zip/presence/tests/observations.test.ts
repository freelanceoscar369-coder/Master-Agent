/**
 * Tests for isValidObservation and OBSERVATION_TYPES.
 */

import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { isValidObservation, OBSERVATION_TYPES } from '../src/observations.ts';
import { at } from './helpers.ts';

describe('OBSERVATION_TYPES', () => {
  test('has exactly 12 entries', () => {
    assert.strictEqual(OBSERVATION_TYPES.length, 12);
  });

  test('matches the 12 expected type strings', () => {
    const expected = [
      'mission.observed',
      'mission.cleared',
      'execution.observed',
      'approval.opened',
      'approval.closed',
      'action.recorded',
      'reasoning.supplied',
      'coverage.reported',
      'coverage.withdrawn',
      'coverage.expected',
      'failure.raised',
      'failure.acknowledged',
    ];
    assert.deepStrictEqual([...OBSERVATION_TYPES].sort(), expected.sort());
  });
});

describe('isValidObservation — accepts all 12 valid shapes', () => {
  test('mission.observed', () => {
    assert.ok(isValidObservation({
      type: 'mission.observed',
      at: at(0),
      ref: 'M1',
      title: 'Test',
      phase: 'running',
      progress: null,
      domain: 'D1',
      startedAt: at(0),
    }));
  });

  test('mission.observed with numeric progress', () => {
    assert.ok(isValidObservation({
      type: 'mission.observed',
      at: at(0),
      ref: 'M1',
      title: 'Test',
      phase: 'queued',
      progress: 0.5,
      domain: 'D1',
      startedAt: at(0),
    }));
  });

  test('mission.cleared', () => {
    assert.ok(isValidObservation({ type: 'mission.cleared', at: at(0), ref: 'M1' }));
  });

  test('execution.observed', () => {
    assert.ok(isValidObservation({
      type: 'execution.observed',
      at: at(0),
      executionId: 'exec-1',
      phase: 'running',
      failureCode: null,
    }));
  });

  test('execution.observed with null executionId', () => {
    assert.ok(isValidObservation({
      type: 'execution.observed',
      at: at(0),
      executionId: null,
      phase: 'idle',
      failureCode: null,
    }));
  });

  test('approval.opened', () => {
    assert.ok(isValidObservation({
      type: 'approval.opened',
      at: at(0),
      approvalId: 'A1',
      executionId: null,
      prompt: 'Please approve.',
      domain: 'D1',
      expiresAt: null,
    }));
  });

  test('approval.opened with all non-null fields', () => {
    assert.ok(isValidObservation({
      type: 'approval.opened',
      at: at(0),
      approvalId: 'A1',
      executionId: 'exec-1',
      prompt: 'Please approve.',
      domain: 'D1',
      expiresAt: at(60),
    }));
  });

  test('approval.closed', () => {
    assert.ok(isValidObservation({ type: 'approval.closed', at: at(0), approvalId: 'A1' }));
  });

  test('action.recorded', () => {
    assert.ok(isValidObservation({
      type: 'action.recorded',
      at: at(0),
      actor: 'kernel',
      description: 'Did something.',
      domain: 'D1',
      succeeded: true,
    }));
  });

  test('reasoning.supplied with text', () => {
    assert.ok(isValidObservation({ type: 'reasoning.supplied', at: at(0), text: 'Thinking...' }));
  });

  test('reasoning.supplied with null text', () => {
    assert.ok(isValidObservation({ type: 'reasoning.supplied', at: at(0), text: null }));
  });

  test('coverage.reported', () => {
    assert.ok(isValidObservation({
      type: 'coverage.reported',
      at: at(0),
      domain: 'D1',
      healthy: true,
      freshnessSeconds: 300,
    }));
  });

  test('coverage.reported with null freshnessSeconds', () => {
    assert.ok(isValidObservation({
      type: 'coverage.reported',
      at: at(0),
      domain: 'D1',
      healthy: false,
      freshnessSeconds: null,
    }));
  });

  test('coverage.withdrawn', () => {
    assert.ok(isValidObservation({ type: 'coverage.withdrawn', at: at(0), domain: 'D1' }));
  });

  test('coverage.expected', () => {
    assert.ok(isValidObservation({ type: 'coverage.expected', at: at(0), domains: ['D1', 'D2'] }));
  });

  test('coverage.expected with empty domains array', () => {
    assert.ok(isValidObservation({ type: 'coverage.expected', at: at(0), domains: [] }));
  });

  test('failure.raised', () => {
    assert.ok(isValidObservation({
      type: 'failure.raised',
      at: at(0),
      code: 'ERR_X',
      detail: 'Something failed.',
      domain: 'D1',
    }));
  });

  test('failure.acknowledged', () => {
    assert.ok(isValidObservation({ type: 'failure.acknowledged', at: at(0), code: 'ERR_X' }));
  });
});

describe('isValidObservation — rejects invalid inputs', () => {
  test('null', () => {
    assert.strictEqual(isValidObservation(null), false);
  });

  test('undefined', () => {
    assert.strictEqual(isValidObservation(undefined), false);
  });

  test('string primitive', () => {
    assert.strictEqual(isValidObservation('mission.observed'), false);
  });

  test('number primitive', () => {
    assert.strictEqual(isValidObservation(42), false);
  });

  test('boolean primitive', () => {
    assert.strictEqual(isValidObservation(true), false);
  });

  test('array', () => {
    assert.strictEqual(isValidObservation([{ type: 'mission.cleared', at: at(0), ref: 'M1' }]), false);
  });

  test('empty object', () => {
    assert.strictEqual(isValidObservation({}), false);
  });

  test('unknown type string', () => {
    assert.strictEqual(isValidObservation({ type: 'unknown.event', at: at(0) }), false);
  });

  test('missing at field', () => {
    assert.strictEqual(isValidObservation({ type: 'mission.cleared', ref: 'M1' }), false);
  });

  test('empty at string', () => {
    assert.strictEqual(isValidObservation({ type: 'mission.cleared', at: '', ref: 'M1' }), false);
  });

  test('non-string at field', () => {
    assert.strictEqual(isValidObservation({ type: 'mission.cleared', at: 12345, ref: 'M1' }), false);
  });

  // Wrong-field-type cases per observation type
  test('mission.observed: ref not a string', () => {
    assert.strictEqual(isValidObservation({
      type: 'mission.observed',
      at: at(0),
      ref: 123,
      title: 'Test',
      phase: 'running',
      progress: null,
      domain: 'D1',
      startedAt: at(0),
    }), false);
  });

  test('mission.observed: progress is a string (not number or null)', () => {
    assert.strictEqual(isValidObservation({
      type: 'mission.observed',
      at: at(0),
      ref: 'M1',
      title: 'Test',
      phase: 'running',
      progress: 'half',
      domain: 'D1',
      startedAt: at(0),
    }), false);
  });

  test('mission.cleared: ref not a string', () => {
    assert.strictEqual(isValidObservation({ type: 'mission.cleared', at: at(0), ref: 99 }), false);
  });

  test('execution.observed: phase not a string', () => {
    assert.strictEqual(isValidObservation({
      type: 'execution.observed',
      at: at(0),
      executionId: null,
      phase: 42,
      failureCode: null,
    }), false);
  });

  test('execution.observed: executionId wrong type (number)', () => {
    assert.strictEqual(isValidObservation({
      type: 'execution.observed',
      at: at(0),
      executionId: 99,
      phase: 'running',
      failureCode: null,
    }), false);
  });

  test('approval.opened: approvalId not a string', () => {
    assert.strictEqual(isValidObservation({
      type: 'approval.opened',
      at: at(0),
      approvalId: 123,
      executionId: null,
      prompt: 'ok',
      domain: 'D1',
      expiresAt: null,
    }), false);
  });

  test('approval.opened: prompt not a string', () => {
    assert.strictEqual(isValidObservation({
      type: 'approval.opened',
      at: at(0),
      approvalId: 'A1',
      executionId: null,
      prompt: null,
      domain: 'D1',
      expiresAt: null,
    }), false);
  });

  test('approval.closed: approvalId not a string', () => {
    assert.strictEqual(isValidObservation({ type: 'approval.closed', at: at(0), approvalId: true }), false);
  });

  test('action.recorded: succeeded not a boolean', () => {
    assert.strictEqual(isValidObservation({
      type: 'action.recorded',
      at: at(0),
      actor: 'kernel',
      description: 'Did something.',
      domain: 'D1',
      succeeded: 'yes',
    }), false);
  });

  test('action.recorded: actor not a string', () => {
    assert.strictEqual(isValidObservation({
      type: 'action.recorded',
      at: at(0),
      actor: 42,
      description: 'Did something.',
      domain: 'D1',
      succeeded: true,
    }), false);
  });

  test('reasoning.supplied: text is a number (not string or null)', () => {
    assert.strictEqual(isValidObservation({ type: 'reasoning.supplied', at: at(0), text: 42 }), false);
  });

  test('coverage.reported: healthy not a boolean', () => {
    assert.strictEqual(isValidObservation({
      type: 'coverage.reported',
      at: at(0),
      domain: 'D1',
      healthy: 'yes',
      freshnessSeconds: null,
    }), false);
  });

  test('coverage.reported: domain not a string', () => {
    assert.strictEqual(isValidObservation({
      type: 'coverage.reported',
      at: at(0),
      domain: 42,
      healthy: true,
      freshnessSeconds: null,
    }), false);
  });

  test('coverage.withdrawn: domain not a string', () => {
    assert.strictEqual(isValidObservation({ type: 'coverage.withdrawn', at: at(0), domain: 99 }), false);
  });

  test('coverage.expected: domains not an array', () => {
    assert.strictEqual(isValidObservation({ type: 'coverage.expected', at: at(0), domains: 'D1' }), false);
  });

  test('coverage.expected: domains contains non-string', () => {
    assert.strictEqual(isValidObservation({ type: 'coverage.expected', at: at(0), domains: ['D1', 42] }), false);
  });

  test('failure.raised: code not a string', () => {
    assert.strictEqual(isValidObservation({
      type: 'failure.raised',
      at: at(0),
      code: 99,
      detail: 'detail',
      domain: 'D1',
    }), false);
  });

  test('failure.raised: detail not a string', () => {
    assert.strictEqual(isValidObservation({
      type: 'failure.raised',
      at: at(0),
      code: 'ERR_X',
      detail: null,
      domain: 'D1',
    }), false);
  });

  test('failure.acknowledged: code not a string', () => {
    assert.strictEqual(isValidObservation({ type: 'failure.acknowledged', at: at(0), code: true }), false);
  });
});
