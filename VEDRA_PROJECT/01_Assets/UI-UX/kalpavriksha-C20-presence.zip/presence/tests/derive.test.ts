/**
 * Tests for the pure derivation functions in derive.ts.
 */

import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import {
  secondsBetween,
  deriveActiveMission,
  deriveExecution,
  deriveVigilance,
  derivePendingApprovals,
  deriveCalm,
  deriveReasoning,
  deriveActivity,
} from '../src/derive.ts';
import { createObservedState, applyObservation } from '../src/state.ts';
import type { ObservedState } from '../src/state.ts';
import type { PresenceThresholds } from '../src/types.ts';
import { DEFAULT_THRESHOLDS } from '../src/types.ts';
import {
  at,
  missionObserved,
  executionObserved,
  approvalOpened,
  coverageReported,
  coverageExpected,
  failureRaised,
  failureAcknowledged,
  reasoningSupplied,
} from './helpers.ts';

const thresholds: PresenceThresholds = DEFAULT_THRESHOLDS;

/* ─────────────────────────── secondsBetween ───────────────────────────── */

describe('secondsBetween', () => {
  test('normal case', () => {
    assert.strictEqual(secondsBetween(at(0), at(30)), 30);
  });

  test('zero when same timestamp', () => {
    assert.strictEqual(secondsBetween(at(5), at(5)), 0);
  });

  test('negative clamps to 0 (clock skew)', () => {
    assert.strictEqual(secondsBetween(at(50), at(20)), 0);
  });

  test('invalid date string from returns 0', () => {
    assert.strictEqual(secondsBetween('not-a-date', at(10)), 0);
  });

  test('invalid date string to returns 0', () => {
    assert.strictEqual(secondsBetween(at(10), 'not-a-date'), 0);
  });

  test('both invalid returns 0', () => {
    assert.strictEqual(secondsBetween('bad', 'also-bad'), 0);
  });
});

/* ──────────────────────── deriveActiveMission ──────────────────────────── */

describe('deriveActiveMission', () => {
  test('returns null when no missions', () => {
    const state = createObservedState();
    assert.strictEqual(deriveActiveMission(state), null);
  });

  test('held takes precedence over running', () => {
    let state = createObservedState();
    state = applyObservation(state, missionObserved({ ref: 'M-running', phase: 'running', startedAt: at(0) }));
    state = applyObservation(state, missionObserved({ ref: 'M-held', phase: 'held', startedAt: at(5) }));
    const result = deriveActiveMission(state);
    assert.strictEqual(result?.ref, 'M-held');
  });

  test('running takes precedence over queued', () => {
    let state = createObservedState();
    state = applyObservation(state, missionObserved({ ref: 'M-queued', phase: 'queued', startedAt: at(0) }));
    state = applyObservation(state, missionObserved({ ref: 'M-running', phase: 'running', startedAt: at(5) }));
    const result = deriveActiveMission(state);
    assert.strictEqual(result?.ref, 'M-running');
  });

  test('queued takes precedence over terminal (completed)', () => {
    let state = createObservedState();
    state = applyObservation(state, missionObserved({ ref: 'M-completed', phase: 'completed', startedAt: at(0) }));
    state = applyObservation(state, missionObserved({ ref: 'M-queued', phase: 'queued', startedAt: at(1) }));
    const result = deriveActiveMission(state);
    assert.strictEqual(result?.ref, 'M-queued');
  });

  test('queued takes precedence over terminal (failed)', () => {
    let state = createObservedState();
    state = applyObservation(state, missionObserved({ ref: 'M-failed', phase: 'failed', startedAt: at(0) }));
    state = applyObservation(state, missionObserved({ ref: 'M-queued', phase: 'queued', startedAt: at(1) }));
    const result = deriveActiveMission(state);
    assert.strictEqual(result?.ref, 'M-queued');
  });

  test('precedence: held > running > queued > terminal', () => {
    let state = createObservedState();
    state = applyObservation(state, missionObserved({ ref: 'M-completed', phase: 'completed', startedAt: at(0) }));
    state = applyObservation(state, missionObserved({ ref: 'M-queued', phase: 'queued', startedAt: at(1) }));
    state = applyObservation(state, missionObserved({ ref: 'M-running', phase: 'running', startedAt: at(2) }));
    state = applyObservation(state, missionObserved({ ref: 'M-held', phase: 'held', startedAt: at(3) }));
    const result = deriveActiveMission(state);
    assert.strictEqual(result?.ref, 'M-held');
  });

  test('ties break on most recent startedAt', () => {
    let state = createObservedState();
    state = applyObservation(state, missionObserved({ ref: 'M-old', phase: 'running', startedAt: at(0) }));
    state = applyObservation(state, missionObserved({ ref: 'M-new', phase: 'running', startedAt: at(100) }));
    const result = deriveActiveMission(state);
    assert.strictEqual(result?.ref, 'M-new');
  });

  test('ties break lexically on ref when startedAt equal', () => {
    let state = createObservedState();
    state = applyObservation(state, missionObserved({ ref: 'M-b', phase: 'running', startedAt: at(5) }));
    state = applyObservation(state, missionObserved({ ref: 'M-a', phase: 'running', startedAt: at(5) }));
    const result = deriveActiveMission(state);
    assert.strictEqual(result?.ref, 'M-a');
  });

  test('order-independence: same missions inserted in different order yield same result', () => {
    let stateA = createObservedState();
    stateA = applyObservation(stateA, missionObserved({ ref: 'M1', phase: 'running', startedAt: at(10) }));
    stateA = applyObservation(stateA, missionObserved({ ref: 'M2', phase: 'held', startedAt: at(5) }));
    stateA = applyObservation(stateA, missionObserved({ ref: 'M3', phase: 'queued', startedAt: at(20) }));

    let stateB = createObservedState();
    stateB = applyObservation(stateB, missionObserved({ ref: 'M3', phase: 'queued', startedAt: at(20) }));
    stateB = applyObservation(stateB, missionObserved({ ref: 'M2', phase: 'held', startedAt: at(5) }));
    stateB = applyObservation(stateB, missionObserved({ ref: 'M1', phase: 'running', startedAt: at(10) }));

    assert.strictEqual(deriveActiveMission(stateA)?.ref, deriveActiveMission(stateB)?.ref);
  });
});

/* ──────────────────────── deriveExecution ──────────────────────────────── */

describe('deriveExecution', () => {
  test('inPhaseSeconds is null when since is null', () => {
    const state = createObservedState();
    const result = deriveExecution(state, at(100));
    assert.strictEqual(result.inPhaseSeconds, null);
  });

  test('inPhaseSeconds is computed when since is set', () => {
    let state = createObservedState();
    state = applyObservation(state, executionObserved({ at: at(10), phase: 'running' }));
    const result = deriveExecution(state, at(45));
    assert.strictEqual(result.inPhaseSeconds, 35);
  });

  test('passes through executionId and failureCode', () => {
    let state = createObservedState();
    state = applyObservation(state, executionObserved({ at: at(0), executionId: 'exec-42', phase: 'failed', failureCode: 'ERR_CRASH' }));
    const result = deriveExecution(state, at(10));
    assert.strictEqual(result.executionId, 'exec-42');
    assert.strictEqual(result.failureCode, 'ERR_CRASH');
  });
});

/* ──────────────────────── deriveVigilance ──────────────────────────────── */

describe('deriveVigilance', () => {
  test('complete when all expected domains reported healthy and fresh', () => {
    let state = createObservedState();
    state = applyObservation(state, coverageExpected({ domains: ['D1', 'D2'] }));
    state = applyObservation(state, coverageReported({ domain: 'D1', healthy: true, freshnessSeconds: 300, at: at(0) }));
    state = applyObservation(state, coverageReported({ domain: 'D2', healthy: true, freshnessSeconds: 300, at: at(0) }));
    const result = deriveVigilance(state, at(100), thresholds);
    assert.ok(result.complete);
  });

  test('never-reported gap for an expected domain that never reported', () => {
    let state = createObservedState();
    state = applyObservation(state, coverageExpected({ domains: ['D1', 'D2'] }));
    state = applyObservation(state, coverageReported({ domain: 'D1', healthy: true, freshnessSeconds: 300, at: at(0) }));
    // D2 expected but never reported
    const result = deriveVigilance(state, at(100), thresholds);
    assert.ok(!result.complete);
    if (!result.complete) {
      const gap = result.gaps.find((g) => g.domain === 'D2');
      assert.ok(gap, 'expected a gap for D2');
      assert.strictEqual(gap?.reason, 'never-reported');
    }
  });

  test('stale gap when age exceeds freshnessSeconds', () => {
    let state = createObservedState();
    state = applyObservation(state, coverageReported({ domain: 'D1', healthy: true, freshnessSeconds: 60, at: at(0) }));
    // 61 seconds later — just over boundary
    const result = deriveVigilance(state, at(61), thresholds);
    assert.ok(!result.complete);
    if (!result.complete) {
      const gap = result.gaps.find((g) => g.domain === 'D1');
      assert.ok(gap, 'expected a stale gap for D1');
      assert.strictEqual(gap?.reason, 'stale');
    }
  });

  test('NOT stale when age exactly equals freshnessSeconds (boundary: not yet over)', () => {
    let state = createObservedState();
    state = applyObservation(state, coverageReported({ domain: 'D1', healthy: true, freshnessSeconds: 60, at: at(0) }));
    // exactly 60 seconds — not yet over
    const result = deriveVigilance(state, at(60), thresholds);
    assert.ok(result.complete);
  });

  test('unhealthy gap when healthy=false', () => {
    let state = createObservedState();
    state = applyObservation(state, coverageReported({ domain: 'D1', healthy: false, freshnessSeconds: 300, at: at(0) }));
    const result = deriveVigilance(state, at(10), thresholds);
    assert.ok(!result.complete);
    if (!result.complete) {
      const gap = result.gaps.find((g) => g.domain === 'D1');
      assert.ok(gap);
      assert.strictEqual(gap?.reason, 'unhealthy');
    }
  });

  test('uses defaultFreshnessSeconds when freshnessSeconds is null', () => {
    const customThresholds: PresenceThresholds = { ...thresholds, defaultFreshnessSeconds: 50 };
    let state = createObservedState();
    state = applyObservation(state, coverageReported({ domain: 'D1', healthy: true, freshnessSeconds: null, at: at(0) }));
    // 51 seconds — just past the default 50s threshold
    const result = deriveVigilance(state, at(51), customThresholds);
    assert.ok(!result.complete);
    if (!result.complete) {
      const gap = result.gaps.find((g) => g.domain === 'D1');
      assert.strictEqual(gap?.reason, 'stale');
    }
  });

  test('domains output is sorted', () => {
    let state = createObservedState();
    state = applyObservation(state, coverageReported({ domain: 'Z', healthy: true, freshnessSeconds: 300, at: at(0) }));
    state = applyObservation(state, coverageReported({ domain: 'A', healthy: true, freshnessSeconds: 300, at: at(0) }));
    state = applyObservation(state, coverageReported({ domain: 'M', healthy: true, freshnessSeconds: 300, at: at(0) }));
    const result = deriveVigilance(state, at(10), thresholds);
    const names = result.domains.map((d) => d.domain);
    assert.deepStrictEqual(names, [...names].sort());
  });
});

/* ──────────────────────── derivePendingApprovals ───────────────────────── */

describe('derivePendingApprovals', () => {
  test('returns empty when no approvals', () => {
    const state = createObservedState();
    const result = derivePendingApprovals(state, at(0));
    assert.strictEqual(result.length, 0);
  });

  test('sorted oldest-first', () => {
    let state = createObservedState();
    state = applyObservation(state, approvalOpened({ approvalId: 'A-new', at: at(50) }));
    state = applyObservation(state, approvalOpened({ approvalId: 'A-old', at: at(10) }));
    const result = derivePendingApprovals(state, at(100));
    assert.strictEqual(result[0]?.approvalId, 'A-old');
    assert.strictEqual(result[1]?.approvalId, 'A-new');
  });

  test('tie-break lexical on approvalId when same requestedAt', () => {
    let state = createObservedState();
    state = applyObservation(state, approvalOpened({ approvalId: 'B-ap', at: at(10) }));
    state = applyObservation(state, approvalOpened({ approvalId: 'A-ap', at: at(10) }));
    const result = derivePendingApprovals(state, at(100));
    assert.strictEqual(result[0]?.approvalId, 'A-ap');
    assert.strictEqual(result[1]?.approvalId, 'B-ap');
  });

  test('waitingSeconds is correct', () => {
    let state = createObservedState();
    state = applyObservation(state, approvalOpened({ approvalId: 'A1', at: at(10) }));
    const result = derivePendingApprovals(state, at(70));
    assert.strictEqual(result[0]?.waitingSeconds, 60);
  });
});

/* ─────────────────────────── deriveCalm ───────────────────────────────── */

describe('deriveCalm', () => {
  function buildCalm(state: ObservedState, now: string) {
    const vigilance = deriveVigilance(state, now, thresholds);
    const approvals = derivePendingApprovals(state, now);
    const execution = deriveExecution(state, now);
    const activeMission = deriveActiveMission(state);
    return deriveCalm(state, vigilance, approvals, execution, activeMission, now);
  }

  test('calm:true only when all five blockers are clear', () => {
    let state = createObservedState();
    // No failures, no approvals, execution idle, no held mission
    // Need complete vigilance — report one domain
    state = applyObservation(state, coverageReported({ domain: 'D1', healthy: true, freshnessSeconds: 300, at: at(0) }));
    const result = buildCalm(state, at(10));
    assert.ok(result.calm);
  });

  test('coverage-incomplete produces calm:false with correct kind', () => {
    let state = createObservedState();
    state = applyObservation(state, coverageExpected({ domains: ['D1'] }));
    // D1 expected but never reported
    const result = buildCalm(state, at(10));
    assert.ok(!result.calm);
    if (!result.calm) {
      assert.ok(result.reasons.some((r) => r.kind === 'coverage-incomplete'));
    }
  });

  test('approval-pending produces calm:false with correct kind', () => {
    let state = createObservedState();
    state = applyObservation(state, coverageReported({ domain: 'D1', healthy: true, freshnessSeconds: 300, at: at(0) }));
    state = applyObservation(state, approvalOpened({ approvalId: 'A1', at: at(5) }));
    const result = buildCalm(state, at(10));
    assert.ok(!result.calm);
    if (!result.calm) {
      assert.ok(result.reasons.some((r) => r.kind === 'approval-pending'));
    }
  });

  test('execution-active (dispatching) produces calm:false', () => {
    let state = createObservedState();
    state = applyObservation(state, coverageReported({ domain: 'D1', healthy: true, freshnessSeconds: 300, at: at(0) }));
    state = applyObservation(state, executionObserved({ at: at(5), phase: 'dispatching' }));
    const result = buildCalm(state, at(10));
    assert.ok(!result.calm);
    if (!result.calm) {
      assert.ok(result.reasons.some((r) => r.kind === 'execution-active'));
    }
  });

  test('execution-active (running) produces calm:false', () => {
    let state = createObservedState();
    state = applyObservation(state, coverageReported({ domain: 'D1', healthy: true, freshnessSeconds: 300, at: at(0) }));
    state = applyObservation(state, executionObserved({ at: at(5), phase: 'running' }));
    const result = buildCalm(state, at(10));
    assert.ok(!result.calm);
    if (!result.calm) {
      assert.ok(result.reasons.some((r) => r.kind === 'execution-active'));
    }
  });

  test('execution-active (streaming) produces calm:false', () => {
    let state = createObservedState();
    state = applyObservation(state, coverageReported({ domain: 'D1', healthy: true, freshnessSeconds: 300, at: at(0) }));
    state = applyObservation(state, executionObserved({ at: at(5), phase: 'streaming' }));
    const result = buildCalm(state, at(10));
    assert.ok(!result.calm);
    if (!result.calm) {
      assert.ok(result.reasons.some((r) => r.kind === 'execution-active'));
    }
  });

  test('execution-active (awaiting-approval) produces calm:false', () => {
    let state = createObservedState();
    state = applyObservation(state, coverageReported({ domain: 'D1', healthy: true, freshnessSeconds: 300, at: at(0) }));
    state = applyObservation(state, executionObserved({ at: at(5), phase: 'awaiting-approval' }));
    const result = buildCalm(state, at(10));
    assert.ok(!result.calm);
    if (!result.calm) {
      assert.ok(result.reasons.some((r) => r.kind === 'execution-active'));
    }
  });

  test('execution-active (cancelling) produces calm:false', () => {
    let state = createObservedState();
    state = applyObservation(state, coverageReported({ domain: 'D1', healthy: true, freshnessSeconds: 300, at: at(0) }));
    state = applyObservation(state, executionObserved({ at: at(5), phase: 'cancelling' }));
    const result = buildCalm(state, at(10));
    assert.ok(!result.calm);
    if (!result.calm) {
      assert.ok(result.reasons.some((r) => r.kind === 'execution-active'));
    }
  });

  test('mission-held produces calm:false with correct kind', () => {
    let state = createObservedState();
    state = applyObservation(state, coverageReported({ domain: 'D1', healthy: true, freshnessSeconds: 300, at: at(0) }));
    state = applyObservation(state, missionObserved({ ref: 'M1', phase: 'held', domain: 'D1', at: at(5) }));
    const result = buildCalm(state, at(10));
    assert.ok(!result.calm);
    if (!result.calm) {
      assert.ok(result.reasons.some((r) => r.kind === 'mission-held'));
    }
  });

  test('failure-unacknowledged produces calm:false with correct kind', () => {
    let state = createObservedState();
    state = applyObservation(state, coverageReported({ domain: 'D1', healthy: true, freshnessSeconds: 300, at: at(0) }));
    state = applyObservation(state, failureRaised({ code: 'ERR_X', domain: 'D1', at: at(5) }));
    const result = buildCalm(state, at(10));
    assert.ok(!result.calm);
    if (!result.calm) {
      assert.ok(result.reasons.some((r) => r.kind === 'failure-unacknowledged'));
    }
  });

  test('when calm is false, reasons is non-empty', () => {
    let state = createObservedState();
    // No coverage at all — incomplete
    const result = buildCalm(state, at(0));
    // empty state: no expected, no reported — vigilance is complete (no gaps)
    // Actually with no expected/reported domains, vigilance IS complete
    // Let's add a missing domain
    state = applyObservation(state, coverageExpected({ domains: ['D1'] }));
    const result2 = buildCalm(state, at(0));
    assert.ok(!result2.calm);
    if (!result2.calm) {
      assert.ok(result2.reasons.length > 0);
    }
  });

  test('statement is a non-empty sentence when calm', () => {
    let state = createObservedState();
    state = applyObservation(state, coverageReported({ domain: 'D1', healthy: true, freshnessSeconds: 300, at: at(0) }));
    const result = buildCalm(state, at(10));
    assert.ok(result.calm);
    assert.ok(result.statement.length > 0);
  });

  test('statement is a non-empty sentence when not calm', () => {
    let state = createObservedState();
    state = applyObservation(state, coverageExpected({ domains: ['D1'] }));
    const result = buildCalm(state, at(10));
    assert.ok(!result.calm);
    assert.ok(result.statement.length > 0);
  });
});

/* ──────────────────────── deriveReasoning ──────────────────────────────── */

describe('deriveReasoning', () => {
  test('null passthrough when no reasoning supplied', () => {
    const state = createObservedState();
    const result = deriveReasoning(state, at(100), thresholds);
    assert.strictEqual(result.text, null);
    assert.strictEqual(result.suppliedAt, null);
    assert.strictEqual(result.ageSeconds, null);
    assert.strictEqual(result.stale, false);
  });

  test('null text after explicit null clear — returns null text with suppliedAt set', () => {
    let state = createObservedState();
    state = applyObservation(state, { type: 'reasoning.supplied', at: at(5), text: null });
    const result = deriveReasoning(state, at(100), thresholds);
    assert.strictEqual(result.text, null);
    assert.strictEqual(result.suppliedAt, at(5));
    assert.strictEqual(result.ageSeconds, null);
  });

  test('age is computed correctly', () => {
    let state = createObservedState();
    state = applyObservation(state, reasoningSupplied({ at: at(0), text: 'Thinking.' }));
    const result = deriveReasoning(state, at(100), thresholds);
    assert.strictEqual(result.ageSeconds, 100);
  });

  test('stale flips just past the threshold boundary', () => {
    const customThresholds: PresenceThresholds = { ...thresholds, reasoningStaleSeconds: 60 };
    let state = createObservedState();
    state = applyObservation(state, reasoningSupplied({ at: at(0), text: 'Thinking.' }));

    // Just under: 60s — should NOT be stale (age 60 is not > 60)
    const justUnder = deriveReasoning(state, at(60), customThresholds);
    assert.strictEqual(justUnder.stale, false);

    // Just over: 61s — should be stale
    const justOver = deriveReasoning(state, at(61), customThresholds);
    assert.strictEqual(justOver.stale, true);
  });
});

/* ──────────────────────── deriveActivity ───────────────────────────────── */

describe('deriveActivity', () => {
  function buildActivity(state: ObservedState, now: string) {
    const vigilance = deriveVigilance(state, now, thresholds);
    const approvals = derivePendingApprovals(state, now);
    const execution = deriveExecution(state, now);
    const activeMission = deriveActiveMission(state);
    return deriveActivity(vigilance, approvals, execution, activeMission, state);
  }

  test('idle when nothing is happening', () => {
    let state = createObservedState();
    state = applyObservation(state, coverageReported({ domain: 'D1', healthy: true, freshnessSeconds: 300, at: at(0) }));
    const result = buildActivity(state, at(10));
    assert.strictEqual(result.kind, 'idle');
  });

  test('degraded takes highest precedence', () => {
    let state = createObservedState();
    // No coverage -> vigilance incomplete -> degraded
    state = applyObservation(state, coverageExpected({ domains: ['MISSING'] }));
    state = applyObservation(state, approvalOpened({ approvalId: 'A1', at: at(5) }));
    state = applyObservation(state, executionObserved({ at: at(5), phase: 'running' }));
    const result = buildActivity(state, at(10));
    assert.strictEqual(result.kind, 'degraded');
  });

  test('waiting-on-founder when vigilance complete but approval pending', () => {
    let state = createObservedState();
    state = applyObservation(state, coverageReported({ domain: 'D1', healthy: true, freshnessSeconds: 300, at: at(0) }));
    state = applyObservation(state, approvalOpened({ approvalId: 'A1', at: at(5) }));
    const result = buildActivity(state, at(10));
    assert.strictEqual(result.kind, 'waiting-on-founder');
  });

  test('blocked when mission is held (vigilance complete, no approvals)', () => {
    let state = createObservedState();
    state = applyObservation(state, coverageReported({ domain: 'D1', healthy: true, freshnessSeconds: 300, at: at(0) }));
    state = applyObservation(state, missionObserved({ ref: 'M1', phase: 'held', domain: 'D1', at: at(5) }));
    const result = buildActivity(state, at(10));
    assert.strictEqual(result.kind, 'blocked');
  });

  test('working when mission is running', () => {
    let state = createObservedState();
    state = applyObservation(state, coverageReported({ domain: 'D1', healthy: true, freshnessSeconds: 300, at: at(0) }));
    state = applyObservation(state, missionObserved({ ref: 'M1', phase: 'running', domain: 'D1', at: at(5) }));
    const result = buildActivity(state, at(10));
    assert.strictEqual(result.kind, 'working');
  });

  test('working when execution is running (no running mission)', () => {
    let state = createObservedState();
    state = applyObservation(state, coverageReported({ domain: 'D1', healthy: true, freshnessSeconds: 300, at: at(0) }));
    state = applyObservation(state, executionObserved({ at: at(5), phase: 'running' }));
    const result = buildActivity(state, at(10));
    assert.strictEqual(result.kind, 'working');
  });

  test('degraded > waiting-on-founder > blocked > working > idle (precedence)', () => {
    // When degraded + approval pending + held mission + running execution
    // should yield degraded
    let state = createObservedState();
    state = applyObservation(state, coverageExpected({ domains: ['MISSING'] }));
    state = applyObservation(state, approvalOpened({ approvalId: 'A1', at: at(5) }));
    state = applyObservation(state, missionObserved({ ref: 'M1', phase: 'held', domain: 'D1', at: at(5) }));
    state = applyObservation(state, executionObserved({ at: at(5), phase: 'running' }));
    const result = buildActivity(state, at(10));
    assert.strictEqual(result.kind, 'degraded');
  });

  test('waiting-on-founder wins over blocked and working', () => {
    let state = createObservedState();
    state = applyObservation(state, coverageReported({ domain: 'D1', healthy: true, freshnessSeconds: 300, at: at(0) }));
    state = applyObservation(state, approvalOpened({ approvalId: 'A1', at: at(5) }));
    state = applyObservation(state, missionObserved({ ref: 'M1', phase: 'held', domain: 'D1', at: at(5) }));
    state = applyObservation(state, executionObserved({ at: at(5), phase: 'running' }));
    const result = buildActivity(state, at(10));
    assert.strictEqual(result.kind, 'waiting-on-founder');
  });

  test('domains sorted and contains only running/held mission domains', () => {
    let state = createObservedState();
    state = applyObservation(state, coverageReported({ domain: 'D-run', healthy: true, freshnessSeconds: 300, at: at(0) }));
    state = applyObservation(state, coverageReported({ domain: 'D-held', healthy: true, freshnessSeconds: 300, at: at(0) }));
    state = applyObservation(state, missionObserved({ ref: 'M1', phase: 'running', domain: 'D-run', at: at(5) }));
    state = applyObservation(state, missionObserved({ ref: 'M2', phase: 'held', domain: 'D-held', at: at(5) }));
    state = applyObservation(state, missionObserved({ ref: 'M3', phase: 'completed', domain: 'D-completed', at: at(5) }));
    const result = buildActivity(state, at(10));
    assert.ok(result.domains.includes('D-run'));
    assert.ok(result.domains.includes('D-held'));
    assert.ok(!result.domains.includes('D-completed'));
    assert.deepStrictEqual([...result.domains], [...result.domains].sort());
  });
});
