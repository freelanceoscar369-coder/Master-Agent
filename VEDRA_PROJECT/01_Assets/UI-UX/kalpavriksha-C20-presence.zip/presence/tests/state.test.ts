/**
 * Tests for applyObservation — the state fold.
 */

import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { applyObservation, createObservedState } from '../src/state.ts';
import {
  at,
  missionObserved,
  missionCleared,
  executionObserved,
  approvalOpened,
  approvalClosed,
  actionRecorded,
  reasoningSupplied,
  coverageReported,
  coverageWithdrawn,
  coverageExpected,
  failureRaised,
  failureAcknowledged,
} from './helpers.ts';

describe('applyObservation — purity', () => {
  test('returns a new object identity every time', () => {
    const s0 = createObservedState();
    const s1 = applyObservation(s0, missionObserved());
    assert.notStrictEqual(s0, s1);
  });

  test('never mutates the input state object', () => {
    const s0 = createObservedState();
    const countBefore = s0.observationCount;
    const mapSizeBefore = s0.missions.size;
    applyObservation(s0, missionObserved());
    assert.strictEqual(s0.observationCount, countBefore);
    assert.strictEqual(s0.missions.size, mapSizeBefore);
  });

  test('never mutates the input missions map', () => {
    const s0 = createObservedState();
    const origMap = s0.missions;
    applyObservation(s0, missionObserved({ ref: 'M1' }));
    assert.strictEqual(origMap.size, 0);
  });

  test('never mutates the input approvals map', () => {
    const s0 = createObservedState();
    const origMap = s0.approvals;
    applyObservation(s0, approvalOpened({ approvalId: 'A1' }));
    assert.strictEqual(origMap.size, 0);
  });

  test('never mutates the input coverage map', () => {
    const s0 = createObservedState();
    const origMap = s0.coverage;
    applyObservation(s0, coverageReported({ domain: 'D1' }));
    assert.strictEqual(origMap.size, 0);
  });
});

describe('applyObservation — observationCount and lastObservedAt', () => {
  test('increments observationCount by exactly 1', () => {
    const s0 = createObservedState();
    const s1 = applyObservation(s0, missionObserved());
    assert.strictEqual(s1.observationCount, 1);
    const s2 = applyObservation(s1, missionObserved());
    assert.strictEqual(s2.observationCount, 2);
  });

  test('tracks lastObservedAt from the observation at', () => {
    const s0 = createObservedState();
    const obs = missionObserved({ at: at(42) });
    const s1 = applyObservation(s0, obs);
    assert.strictEqual(s1.lastObservedAt, at(42));
  });
});

describe('applyObservation — mission.observed', () => {
  test('inserts a new mission', () => {
    const s0 = createObservedState();
    const s1 = applyObservation(s0, missionObserved({ ref: 'M1', title: 'Mission One', phase: 'running' }));
    assert.strictEqual(s1.missions.size, 1);
    assert.ok(s1.missions.has('M1'));
    assert.strictEqual(s1.missions.get('M1')?.title, 'Mission One');
  });

  test('updates an existing mission in place by ref', () => {
    const s0 = createObservedState();
    const s1 = applyObservation(s0, missionObserved({ ref: 'M1', phase: 'queued' }));
    const s2 = applyObservation(s1, missionObserved({ ref: 'M1', phase: 'running' }));
    assert.strictEqual(s2.missions.size, 1);
    assert.strictEqual(s2.missions.get('M1')?.phase, 'running');
  });
});

describe('applyObservation — mission.cleared', () => {
  test('removes a mission that exists', () => {
    const s0 = createObservedState();
    const s1 = applyObservation(s0, missionObserved({ ref: 'M1' }));
    const s2 = applyObservation(s1, missionCleared({ ref: 'M1' }));
    assert.strictEqual(s2.missions.size, 0);
    assert.ok(!s2.missions.has('M1'));
  });

  test('clearing an unknown ref is safe (no throw, count still increments)', () => {
    const s0 = createObservedState();
    const s1 = applyObservation(s0, missionCleared({ ref: 'nonexistent' }));
    assert.strictEqual(s1.missions.size, 0);
    assert.strictEqual(s1.observationCount, 1);
  });
});

describe('applyObservation — execution.observed since semantics', () => {
  test('sets since on first observation', () => {
    const s0 = createObservedState();
    const s1 = applyObservation(s0, executionObserved({ at: at(10), phase: 'running' }));
    assert.strictEqual(s1.execution.since, at(10));
    assert.strictEqual(s1.execution.phase, 'running');
  });

  test('repeating the SAME phase does NOT move since', () => {
    const s0 = createObservedState();
    const s1 = applyObservation(s0, executionObserved({ at: at(10), phase: 'running' }));
    const s2 = applyObservation(s1, executionObserved({ at: at(20), phase: 'running' }));
    assert.strictEqual(s2.execution.since, at(10));
    assert.strictEqual(s2.execution.phase, 'running');
  });

  test('a phase CHANGE sets since to the new observation at', () => {
    const s0 = createObservedState();
    const s1 = applyObservation(s0, executionObserved({ at: at(10), phase: 'running' }));
    const s2 = applyObservation(s1, executionObserved({ at: at(25), phase: 'awaiting-approval' }));
    assert.strictEqual(s2.execution.since, at(25));
    assert.strictEqual(s2.execution.phase, 'awaiting-approval');
  });

  test('since transitions: idle → dispatching → running', () => {
    const s0 = createObservedState();
    const s1 = applyObservation(s0, executionObserved({ at: at(5), phase: 'dispatching' }));
    assert.strictEqual(s1.execution.since, at(5));
    const s2 = applyObservation(s1, executionObserved({ at: at(5), phase: 'dispatching' }));
    assert.strictEqual(s2.execution.since, at(5));  // same phase, no move
    const s3 = applyObservation(s2, executionObserved({ at: at(15), phase: 'running' }));
    assert.strictEqual(s3.execution.since, at(15));  // phase changed, moved
  });
});

describe('applyObservation — approval.opened/closed', () => {
  test('opened inserts an approval', () => {
    const s0 = createObservedState();
    const s1 = applyObservation(s0, approvalOpened({ approvalId: 'A1', at: at(5) }));
    assert.strictEqual(s1.approvals.size, 1);
    assert.ok(s1.approvals.has('A1'));
  });

  test('closed removes an approval', () => {
    const s0 = createObservedState();
    const s1 = applyObservation(s0, approvalOpened({ approvalId: 'A1' }));
    const s2 = applyObservation(s1, approvalClosed({ approvalId: 'A1' }));
    assert.strictEqual(s2.approvals.size, 0);
  });

  test('closing an unknown id is safe', () => {
    const s0 = createObservedState();
    const s1 = applyObservation(s0, approvalClosed({ approvalId: 'nonexistent' }));
    assert.strictEqual(s1.approvals.size, 0);
    assert.strictEqual(s1.observationCount, 1);
  });
});

describe('applyObservation — action.recorded', () => {
  test('replaces lastAction', () => {
    const s0 = createObservedState();
    const s1 = applyObservation(s0, actionRecorded({ at: at(5), description: 'First action' }));
    assert.strictEqual(s1.lastAction?.description, 'First action');
    const s2 = applyObservation(s1, actionRecorded({ at: at(10), description: 'Second action' }));
    assert.strictEqual(s2.lastAction?.description, 'Second action');
  });
});

describe('applyObservation — reasoning.supplied', () => {
  test('stores reasoning text', () => {
    const s0 = createObservedState();
    const s1 = applyObservation(s0, reasoningSupplied({ at: at(5), text: 'Thinking about X.' }));
    assert.strictEqual(s1.reasoning?.text, 'Thinking about X.');
    assert.strictEqual(s1.reasoning?.at, at(5));
  });

  test('supplying null explicitly clears the text but records the timestamp', () => {
    const s0 = createObservedState();
    const s1 = applyObservation(s0, reasoningSupplied({ at: at(5), text: 'Thinking.' }));
    const s2 = applyObservation(s1, reasoningSupplied({ at: at(10), text: null }));
    assert.strictEqual(s2.reasoning?.text, null);
    assert.strictEqual(s2.reasoning?.at, at(10));
  });
});

describe('applyObservation — coverage.reported', () => {
  test('inserts a new coverage record', () => {
    const s0 = createObservedState();
    const s1 = applyObservation(s0, coverageReported({ domain: 'D1', healthy: true }));
    assert.strictEqual(s1.coverage.size, 1);
    assert.ok(s1.coverage.has('D1'));
    assert.strictEqual(s1.coverage.get('D1')?.healthy, true);
  });

  test('updates an existing coverage record', () => {
    const s0 = createObservedState();
    const s1 = applyObservation(s0, coverageReported({ domain: 'D1', healthy: true }));
    const s2 = applyObservation(s1, coverageReported({ domain: 'D1', healthy: false }));
    assert.strictEqual(s2.coverage.size, 1);
    assert.strictEqual(s2.coverage.get('D1')?.healthy, false);
  });
});

describe('applyObservation — coverage.withdrawn', () => {
  test('removes from the coverage map', () => {
    const s0 = createObservedState();
    const s1 = applyObservation(s0, coverageReported({ domain: 'D1' }));
    const s2 = applyObservation(s1, coverageWithdrawn({ domain: 'D1' }));
    assert.strictEqual(s2.coverage.size, 0);
  });

  test('removes from expectedDomains', () => {
    const s0 = createObservedState();
    const s1 = applyObservation(s0, coverageExpected({ domains: ['D1', 'D2'] }));
    const s2 = applyObservation(s1, coverageWithdrawn({ domain: 'D1' }));
    assert.ok(!s2.expectedDomains.includes('D1'));
    assert.ok(s2.expectedDomains.includes('D2'));
  });

  test('removes from BOTH coverage map and expectedDomains', () => {
    const s0 = createObservedState();
    const s1 = applyObservation(s0, coverageExpected({ domains: ['D1', 'D2'] }));
    const s2 = applyObservation(s1, coverageReported({ domain: 'D1' }));
    const s3 = applyObservation(s2, coverageWithdrawn({ domain: 'D1' }));
    assert.ok(!s3.coverage.has('D1'));
    assert.ok(!s3.expectedDomains.includes('D1'));
  });
});

describe('applyObservation — coverage.expected', () => {
  test('replaces the expected list wholesale', () => {
    const s0 = createObservedState();
    const s1 = applyObservation(s0, coverageExpected({ domains: ['D1', 'D2'] }));
    assert.deepStrictEqual([...s1.expectedDomains], ['D1', 'D2']);
    const s2 = applyObservation(s1, coverageExpected({ domains: ['D3'] }));
    assert.deepStrictEqual([...s2.expectedDomains], ['D3']);
  });
});

describe('applyObservation — failure.raised', () => {
  test('stores unacknowledged failure', () => {
    const s0 = createObservedState();
    const s1 = applyObservation(s0, failureRaised({ code: 'ERR_X', detail: 'Bad thing.' }));
    assert.ok(s1.failures.has('ERR_X'));
    assert.strictEqual(s1.failures.get('ERR_X')?.acknowledged, false);
    assert.strictEqual(s1.failures.get('ERR_X')?.detail, 'Bad thing.');
  });
});

describe('applyObservation — failure.acknowledged', () => {
  test('flips the acknowledged flag', () => {
    const s0 = createObservedState();
    const s1 = applyObservation(s0, failureRaised({ code: 'ERR_X' }));
    const s2 = applyObservation(s1, failureAcknowledged({ code: 'ERR_X' }));
    assert.strictEqual(s2.failures.get('ERR_X')?.acknowledged, true);
  });

  test('acknowledging an unknown code is a safe no-op but still increments count', () => {
    const s0 = createObservedState();
    const s1 = applyObservation(s0, failureAcknowledged({ code: 'NONEXISTENT' }));
    assert.strictEqual(s1.failures.size, 0);
    assert.strictEqual(s1.observationCount, 1);
  });
});
