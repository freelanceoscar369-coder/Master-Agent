# C24 — Blockers

Concrete missing files preventing completion. Nothing else.

Each entry states the file that does not exist, what depends on it, and what
becomes possible the moment it lands. No speculation about contents.

---

## BLOCKER-01 · C22 Environment Intelligence — package absent

**Missing files**

```
environment/package.json
environment/src/index.ts
environment/src/types.ts
```

**Verified absent by:** recursive scan of `presence/`, `surface/`, `desktop/`,
`kd/` for the identifiers `preferredBrowser`, `preferred_browser`,
`preferredEditor`, `preferredAI`, `capabilityGraph`, `capability_graph`,
`environmentSummary`, `installedBrowsers` — **zero occurrences in any source
file.** No `environment/` directory exists at any level.

**Blocks**

- Environment Panel rendering any field. It currently renders
  `Environment Intelligence / Awaiting runtime`, which is the brief's mandated
  behaviour, not a workaround.
- The six fields named in the brief: browsers · preferred browser · preferred
  editor · preferred AI · capability graph · environment summary.

**Unblocked by:** `environment/src/index.ts` exporting the environment type.
Its name is unknown to this session and has not been assumed.

**Change required once supplied:** three lines in
`founder-edition/src/ports/environmentPort.ts` — import the type, replace
`unknown` with it, replace the absent factory. Then map fields in
`EnvironmentPanel.tsx` at the marked location. No other file changes.

---

## BLOCKER-02 · C23 Founder Runtime — package absent

**Missing files**

```
founder-runtime/package.json
founder-runtime/src/index.ts
founder-runtime/src/types.ts
```

**Verified absent by:** recursive scan for `C23`, `founderRuntime`,
`FounderRuntime` across all `.ts`, `.tsx`, `.json` and `.md` files —
**zero occurrences** outside the C24 documents written in this session. No
`founder-runtime/` directory exists at any level.

**Blocks**

- The brief's instruction *"All data comes from C23."* C24 currently reads
  C20 presence and C19A conversation entries directly from their owning
  packages, because those contracts exist and C23's aggregate does not.
  This is a recorded deviation, not an oversight — see HEALTH_C24.md §3.
- Founder Runtime Panel rendering anything. It renders
  `Founder Runtime / Awaiting runtime`.
- Any push-based live update. C24's subscription seam is wired and its
  lifecycle is tested, but nothing emits.

**Unblocked by:** `founder-runtime/src/index.ts` exporting the aggregate state
type and its access method (pull, push, or both — unknown).

**Change required once supplied:** three lines in
`founder-edition/src/ports/founderRuntimePort.ts`, plus a decision recorded in
the dependency map §7 question 2 — whether the dashboard should switch to
reading presence *through* C23 rather than directly from C20.

---

## Not blockers

Recorded to keep this list honest — these are open items, not things stopping
C24 from being complete as specified.

| Item | Why it is not a blocker |
|---|---|
| React not installable in this environment | Source is written; `.tsx` cannot be rendered or type-checked here. An environment problem, not a missing dependency. |
| No `tsc` run | Same cause. Node's type-stripping executes `.ts` but does not type-check. |
| C22/C23 contract questions unanswered | Listed in the dependency map §7. They shape the wiring diff; they do not block what C24 was asked to deliver. |

---

## Summary

**2 blockers. Both are absent packages, not missing decisions.**

Nothing in C24 waits on a judgement call, a design question, or an
architectural choice. It waits on two directories existing.

Every other part of the integration is complete and verified: C20 presence and
C21 conversation are composed and wired, the ports are in place with tested
lifecycles, and both unavailable states render exactly the words the brief
specified.
