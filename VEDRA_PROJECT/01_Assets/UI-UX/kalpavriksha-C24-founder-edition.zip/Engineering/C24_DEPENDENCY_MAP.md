# C24 — Dependency Map

**Generated:** 6 August 2026, from a programmatic scan of the workspace.
**Method:** every `.ts`/`.tsx` under `presence/`, `surface/`, `desktop/`, `kd/`
parsed for exported symbols. Counts below are measured, not recalled.

| Package | Files | Modules with exports | Exported symbols |
|---|---|---|---|
| `presence/` (C20) | 12 | 7 | 120 |
| `surface/` (C21) | 18 | 13 | 82 |
| `desktop/` (C19A + Desktop v0.1) | 71 | 63 | 389 |
| `kd/` (Desktop v0.1, pre-C19A snapshot) | 61 | 57 | 332 |

---

## 1 · Dependency register

Every dependency C24 requires, and its status.

| # | Dependency | Status | Resolved to |
|---|---|---|---|
| D1 | Presence contract (C20) | ✅ **PRESENT** | `presence/src/index.ts` |
| D2 | Founder Conversation surface (C21) | ✅ **PRESENT** | `surface/src/index.ts` |
| D3 | Conversation entry contract (C19A) | ✅ **PRESENT** | `desktop/src/types/execution.ts` |
| D4 | Conversation state store (C19A) | ✅ **PRESENT** | `desktop/src/state/conversationStore.ts` |
| D5 | Conversation actions / hook (C19A) | ✅ **PRESENT** | `desktop/src/hooks/{conversationActions,useConversation}.ts` |
| D6 | Runtime transport stub (C19A) | ✅ **PRESENT** | `desktop/src/services/runtimeClient.ts` |
| D7 | Founder Dashboard assets / design system | ✅ **PRESENT** | `desktop/src/{design,components}` · `surface/src/styles/surface.css` |
| D8 | UI prototype | ✅ **PRESENT** | `archive/01_Assets/…` |
| D9 | **Environment Intelligence (C22)** | ❌ **MISSING** | — no file in workspace |
| D10 | **Founder Runtime (C23)** | ❌ **MISSING** | — no file in workspace |

**8 of 10 present. 2 missing.** Both missing dependencies were built in another
Claude session and are not reachable from this workspace.

---

## 2 · Present dependencies — exact interfaces consumed

Only the symbols C24 actually imports are listed. Everything else in these
packages is left untouched.

### D1 · C20 Presence — `presence/src/index.ts`

```ts
import type {
  PresenceSnapshot,   // the whole snapshot; the dashboard's live state
  CalmState,          // read via snapshot.calm
  VigilanceState,     // read via snapshot.vigilance
  CurrentActivity,    // read via snapshot.activity
  ActiveMission,      // read via snapshot.activeMission
  PendingApproval,    // read via snapshot.pendingApprovals
  LastAction,         // read via snapshot.lastAction
  ReasoningSummary,   // read via snapshot.reasoning
} from '../../presence/src/index.ts';
```

Runtime values imported: **none.** C24 reads snapshots; it does not create a
presence layer, fold observations, or call any `derive*` function. Those remain
C20's.

### D2 · C21 Founder Conversation — `surface/src/index.ts`

```ts
import {
  ConversationSurface,   // composed whole — NOT re-implemented
  PresenceHeader,
  MissionStrip,
  ConversationArea,
  Composer,
  FounderActions,
  projectPresence,
  absentPresence,
  projectConversation,
  DEFAULT_FOUNDER_MODE,
} from '../../surface/src/index.ts';
import type { PresenceView, ViewField, FounderModeConfig, ConversationRow }
  from '../../surface/src/index.ts';
```

C24 **composes** these. It does not redesign, fork, or re-style them.

### D3 · C19A conversation entries — `desktop/src/types/execution.ts`

```ts
import type { ConversationEntry, ExecutionState, ApprovalState }
  from '../../desktop/src/types/execution.ts';
```

---

## 3 · Missing dependencies — what C24 expects

**Nothing below is implemented, declared or assumed by C24.** This section
records the expectation so the owning session can confirm or correct it. Where
a shape is unknown, it is stated as unknown rather than guessed.

### D9 · C22 Environment Intelligence — MISSING

**Files expected (not found):**

```
environment/src/index.ts
environment/src/types.ts
environment/package.json          → name: @kalpavriksha/environment
```

**Import C24 expects to make:**

```ts
import type { EnvironmentSnapshot } from '../../environment/src/index.ts';
```

**Fields the brief names, whose types are UNKNOWN to this session:**

| Field named in brief | Type | Status |
|---|---|---|
| `browsers` | unknown | not declared anywhere in workspace |
| preferred browser | unknown | not declared |
| preferred editor | unknown | not declared |
| preferred AI | unknown | not declared |
| capability graph | unknown | not declared |
| environment summary | unknown | not declared |

> **C24 has deliberately NOT invented names or shapes for these.** The
> Environment Panel therefore renders `Environment Intelligence / Awaiting
> runtime` and nothing else — it cannot render fields whose contract it does
> not have, and inventing them would be the fabrication the brief forbids.

### D10 · C23 Founder Runtime — MISSING

**Files expected (not found):**

```
founder-runtime/src/index.ts
founder-runtime/src/types.ts
founder-runtime/package.json      → name: @kalpavriksha/founder-runtime
```

**Import C24 expects to make:**

```ts
import type { FounderRuntimeState } from '../../founder-runtime/src/index.ts';
```

**Role stated in the brief:** *"All data comes from C23."* C23 is therefore
expected to be the **aggregator** that supplies presence, conversation,
environment, mission, activity, calm and vigilance to the dashboard as one
state object.

**What is unknown:**

- whether C23 re-exports the C20 `PresenceSnapshot` verbatim or wraps it;
- whether conversation entries arrive as C19A `ConversationEntry[]` or a C23 type;
- whether C23 is pull (`getState()`), push (`subscribe()`), or both;
- whether C23 embeds the C22 environment snapshot or exposes it separately.

C24 assumes **none** of these. See §4.

---

## 4 · How C24 handles the gap

Two adapter ports. Each declares **availability only** — never a payload shape.

```ts
// founder-edition/src/ports/environmentPort.ts
export type PortState<T> =
  | { readonly available: false; readonly reason: string }
  | { readonly available: true;  readonly value: T };

export interface EnvironmentPort {
  readonly contractVersion: null;   // null until C22 supplies one
  // Payload is `unknown` ON PURPOSE. Typing it would recreate C22's contract.
  getEnvironment(): PortState<unknown>;
}
```

**Why the payload is `unknown` and not an interface.**

The brief forbids recreating types and duplicating contracts. Any field list I
wrote here — even a "provisional" one — would become the de-facto C22 contract
the moment a component read it. `unknown` makes that impossible: **the panel
literally cannot render a field, because the type system does not know one
exists.** The gap is enforced by the compiler rather than by discipline.

The consequence is intentional and visible: while C22 is absent, the
Environment Panel can only render the awaiting state. When C22 arrives, its
real type replaces `unknown` in one line, and the panel gains fields.

Identical treatment for `FounderRuntimePort`.

---

## 5 · Import graph C24 introduces

```
founder-edition/
  ├─ imports ──▶ presence/src/index.ts            (C20)  types only
  ├─ imports ──▶ surface/src/index.ts             (C21)  components + projections
  ├─ imports ──▶ desktop/src/types/execution.ts   (C19A) types only
  ├─ port    ──▷ environment/src/index.ts         (C22)  ABSENT — port only
  └─ port    ──▷ founder-runtime/src/index.ts     (C23)  ABSENT — port only

  ──▶ real import, resolves today
  ──▷ declared expectation, no import statement exists
```

**No import statement referencing C22 or C23 exists anywhere in C24.** A
missing module cannot be imported; writing the import and commenting it out
would break the build the moment someone uncommented it against a guessed
shape. The ports stand in their place.

---

## 6 · What is NOT a dependency

Recorded so the audit can confirm nothing crept in.

| Not used | Confirmed by |
|---|---|
| Kernel | No import of `kernel/`; C24 touches no kernel symbol |
| Runtime Bridge | Not imported; C19A's stub is the only transport reference and C24 does not call it |
| Coordinator · Ledger · Foundation | Not imported |
| Scanning logic | None; C24 discovers nothing about the machine |
| Orchestration | None |
| AI routing / model selection | None |
| Backend | None; zero network capability (enforced by guard) |
| Electron | Not imported |

---

## 7 · Reconciliation checklist for the C22/C23 owner

Answer these and C24 wiring becomes a small diff rather than a redesign.

1. What is the package name and entry path for C22? For C23?
2. Does C23 aggregate presence, or does the dashboard read C20 directly?
3. Is C23 pull, push, or both? If push, what is the subscription signature?
4. Does C23 embed the environment snapshot, or is C22 read independently?
5. Are conversation entries C19A `ConversationEntry`, or a C23 type?
6. Does C22 expose a `contractVersion`? C24's ports carry the field, currently `null`.
7. Is the capability graph a list, an adjacency structure, or a tree?
8. Is `browsers` a list of installed browsers, or of running ones?
