/**
 * C24 · No-fabrication tests.
 *
 * Guards the brief's "Never fabricate." rule. These are the most important
 * tests in this suite — they verify that C24 does not invent environment
 * field names, runtime state types, greetings, or fixtures.
 */

import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, extname } from 'node:path';

import {
  createAbsentEnvironmentPort,
  createAbsentFounderRuntimePort,
} from '../src/ports/index.ts';

/* ─────────────────────── helpers ──────────────────────────────────────── */

/** Recursively collect all .ts and .tsx files under a directory. */
function collectSourceFiles(dir: string): string[] {
  const results: string[] = [];
  for (const entry of readdirSync(dir)) {
    const full = join(dir, entry);
    const stat = statSync(full);
    if (stat.isDirectory()) {
      results.push(...collectSourceFiles(full));
    } else {
      const ext = extname(entry);
      if (ext === '.ts' || ext === '.tsx') {
        results.push(full);
      }
    }
  }
  return results;
}

/** Return only non-comment lines from source text. */
function nonCommentLines(source: string): string[] {
  return source.split('\n').filter((line) => {
    const trimmed = line.trim();
    // Skip lines that are entirely a comment token
    return (
      !trimmed.startsWith('//') &&
      !trimmed.startsWith('*') &&
      !trimmed.startsWith('/*')
    );
  });
}

const SRC_DIR = new URL('../src', import.meta.url).pathname;

/* ─────────────────────── No payload in unavailable result ─────────────── */

describe('Never fabricate — no payload in unavailable result', () => {
  test('environment port unavailable result exposes no "value" key', () => {
    const port = createAbsentEnvironmentPort();
    const result = port.getEnvironment();
    assert.equal(result.available, false);
    assert.equal('value' in result, false, '"value" must not exist in unavailable EnvironmentPort result');
  });

  test('founder-runtime port unavailable result exposes no "value" key', () => {
    const port = createAbsentFounderRuntimePort();
    const result = port.getState();
    assert.equal(result.available, false);
    assert.equal('value' in result, false, '"value" must not exist in unavailable FounderRuntimePort result');
  });
});

/* ─────────────────────── No environment field names in source ──────────── */

describe('Never fabricate — no environment field names in source code', () => {
  /**
   * These identifiers name C22 environment fields. The brief forbids declaring
   * them in C24 source. They ARE allowed in comments — the components document
   * what is deliberately absent — so we skip comment lines.
   */
  const FORBIDDEN_IDENTIFIERS = [
    'preferredBrowser',
    'preferred_browser',
    'preferredEditor',
    'preferred_editor',
    'preferredAI',
    'preferred_ai',
    'capabilityGraph',
    'capability_graph',
    'environmentSummary',
    'environment_summary',
    'installedBrowsers',
  ];

  test('no forbidden environment identifiers in non-comment source lines', () => {
    const files = collectSourceFiles(SRC_DIR);
    const violations: string[] = [];

    for (const file of files) {
      const source = readFileSync(file, 'utf8');
      const lines = nonCommentLines(source);
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        for (const id of FORBIDDEN_IDENTIFIERS) {
          if (line.includes(id)) {
            violations.push(`${file}:line — "${id}" found in: ${line.trim()}`);
          }
        }
      }
    }

    assert.equal(
      violations.length,
      0,
      `Environment field names found in non-comment source:\n${violations.join('\n')}`,
    );
  });
});

/* ─────────────────────── No fabricated runtime state type ─────────────── */

describe('Never fabricate — no fabricated runtime state type declarations', () => {
  /**
   * C24 must not declare interfaces or types that recreate the absent C22 or
   * C23 contracts. These patterns match names the brief forbids inventing.
   */
  const FORBIDDEN_TYPE_PATTERN =
    /\b(?:interface|type)\s+(?:Environment(?:Snapshot|State|Data|Info)|FounderRuntime(?:State|Snapshot|Data))\b/;

  test('no forbidden type declarations in src/', () => {
    const files = collectSourceFiles(SRC_DIR);
    const violations: string[] = [];

    for (const file of files) {
      const source = readFileSync(file, 'utf8');
      const lines = nonCommentLines(source);
      for (const line of lines) {
        if (FORBIDDEN_TYPE_PATTERN.test(line)) {
          violations.push(`${file}: ${line.trim()}`);
        }
      }
    }

    assert.equal(
      violations.length,
      0,
      `Fabricated runtime state type declarations found:\n${violations.join('\n')}`,
    );
  });
});

/* ─────────────────────── No greeting ──────────────────────────────────── */

describe('Never fabricate — no time-of-day greeting in source', () => {
  const GREETING_PATTERN = /good\s+(morning|afternoon|evening)/i;

  test('no greeting text in non-comment source lines', () => {
    const files = collectSourceFiles(SRC_DIR);
    const violations: string[] = [];

    for (const file of files) {
      const source = readFileSync(file, 'utf8');
      const lines = nonCommentLines(source);
      for (const line of lines) {
        if (GREETING_PATTERN.test(line)) {
          violations.push(`${file}: ${line.trim()}`);
        }
      }
    }

    assert.equal(
      violations.length,
      0,
      `Time-of-day greeting found in source:\n${violations.join('\n')}`,
    );
  });
});

/* ─────────────────────── No fixtures ──────────────────────────────────── */

describe('Never fabricate — no fixture/mock/sample/seed/demo/fake files', () => {
  const FIXTURE_PATTERN = /fixture|mock|sample|seed|demo|fake/i;

  test('no file under src/ has a fixture-like name', () => {
    const files = collectSourceFiles(SRC_DIR);
    const violations = files.filter((f) => FIXTURE_PATTERN.test(f));

    assert.equal(
      violations.length,
      0,
      `Fixture-like filenames found under src/:\n${violations.join('\n')}`,
    );
  });
});
