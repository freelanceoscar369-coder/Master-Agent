/**
 * C24 · Integration guard — static analysis over src/.
 *
 * Walk src/**\/*.{ts,tsx} and fail (exit 1) on any of the forbidden patterns,
 * skipping comment lines.
 *
 * Allowed:
 *   - relative imports (start with . or ..)
 *   - reaching into ../../presence/, ../../surface/, ../../desktop/
 *
 * Forbidden (and checked here):
 *   - any package import other than "react"
 *   - any import containing "environment/" or "founder-runtime/"
 *   - fetch(, XMLHttpRequest, WebSocket, EventSource, node:fs, node:http, child_process
 *   - electron, ipcRenderer, webContents
 *   - Math.random(
 *   - setInterval(
 *   - any string matching https?://
 */

import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join, extname } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = fileURLToPath(new URL('.', import.meta.url));
const SRC_DIR = join(__dirname, '..', 'src');

/* ─────────────────────── file collection ──────────────────────────────── */

function collectFiles(dir) {
  const results = [];
  for (const entry of readdirSync(dir)) {
    const full = join(dir, entry);
    const stat = statSync(full);
    if (stat.isDirectory()) {
      results.push(...collectFiles(full));
    } else {
      const ext = extname(entry);
      if (ext === '.ts' || ext === '.tsx') {
        results.push(full);
      }
    }
  }
  return results;
}

/* ─────────────────────── comment line detection ───────────────────────── */

function isCommentLine(line) {
  const trimmed = line.trim();
  return (
    trimmed.startsWith('//') ||
    trimmed.startsWith('*') ||
    trimmed.startsWith('/*')
  );
}

/* ─────────────────────── import specifier extraction ──────────────────── */

/**
 * Extract import specifiers from a line.
 * Handles: import ... from 'specifier'  and  import 'specifier'
 */
function extractImportSpecifier(line) {
  const match = line.match(/from\s+['"]([^'"]+)['"]/);
  if (match) return match[1];
  const bare = line.match(/^\s*import\s+['"]([^'"]+)['"]/);
  if (bare) return bare[1];
  return null;
}

/**
 * Returns true if the specifier is an allowed import.
 *
 * Allowed:
 *   - relative imports starting with . or ..
 *   - reaching into ../../presence/, ../../surface/, ../../desktop/
 *     (these will appear as relative paths like ../../../presence/...)
 *   - 'react' itself (peer dep)
 */
function isAllowedSpecifier(spec) {
  // All relative imports are fine (including reach into sibling packages)
  if (spec.startsWith('.')) return true;
  // 'react' peer dependency
  if (spec === 'react') return true;
  return false;
}

/* ─────────────────────── checks ───────────────────────────────────────── */

const CHECKS = [
  {
    id: 'ABSENT_MODULE_IMPORT',
    description: 'import of absent environment/ or founder-runtime/ module',
    test: (line, spec) => {
      if (spec === null) return false;
      return spec.includes('environment/') || spec.includes('founder-runtime/');
    },
  },
  {
    id: 'EXTERNAL_PACKAGE_IMPORT',
    description: 'import from a package other than react',
    test: (line, spec) => {
      if (spec === null) return false;
      if (isAllowedSpecifier(spec)) return false;
      return true;
    },
  },
  {
    id: 'FETCH',
    description: 'fetch( call',
    test: (line) => /\bfetch\s*\(/.test(line),
  },
  {
    id: 'XML_HTTP_REQUEST',
    description: 'XMLHttpRequest usage',
    test: (line) => /\bXMLHttpRequest\b/.test(line),
  },
  {
    id: 'WEBSOCKET',
    description: 'WebSocket usage',
    test: (line) => /\bWebSocket\b/.test(line),
  },
  {
    id: 'EVENT_SOURCE',
    description: 'EventSource usage',
    test: (line) => /\bEventSource\b/.test(line),
  },
  {
    id: 'NODE_FS',
    description: 'node:fs import',
    test: (line) => /['"]node:fs['"]/.test(line),
  },
  {
    id: 'NODE_HTTP',
    description: 'node:http import',
    test: (line) => /['"]node:http['"]/.test(line),
  },
  {
    id: 'CHILD_PROCESS',
    description: 'child_process usage',
    test: (line) => /\bchild_process\b/.test(line),
  },
  {
    id: 'ELECTRON',
    description: 'electron import or usage',
    test: (line) => /\belectron\b/.test(line),
  },
  {
    id: 'IPC_RENDERER',
    description: 'ipcRenderer usage',
    test: (line) => /\bipcRenderer\b/.test(line),
  },
  {
    id: 'WEB_CONTENTS',
    description: 'webContents usage',
    test: (line) => /\bwebContents\b/.test(line),
  },
  {
    id: 'MATH_RANDOM',
    description: 'Math.random( call',
    test: (line) => /\bMath\.random\s*\(/.test(line),
  },
  {
    id: 'SET_INTERVAL',
    description: 'setInterval( call — C24 forbids timer-driven motion',
    test: (line) => /\bsetInterval\s*\(/.test(line),
  },
  {
    id: 'HTTP_URL',
    description: 'hard-coded http(s):// URL',
    test: (line) => /https?:\/\//.test(line),
  },
];

/* ─────────────────────── main scan ────────────────────────────────────── */

const files = collectFiles(SRC_DIR);
let totalImports = 0;
const findings = [];

for (const file of files) {
  const source = readFileSync(file, 'utf8');
  const lines = source.split('\n');

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (isCommentLine(line)) continue;

    const spec = extractImportSpecifier(line);
    if (spec !== null) totalImports += 1;

    for (const check of CHECKS) {
      if (check.test(line, spec)) {
        findings.push({
          file: file.replace(SRC_DIR + '/', ''),
          lineNum: i + 1,
          checkId: check.id,
          description: check.description,
          line: line.trim(),
        });
      }
    }
  }
}

/* ─────────────────────── report ───────────────────────────────────────── */

console.log('');
console.log('C24 Integration Guard');
console.log('═════════════════════════════════════════════════════════════');
console.log(`Modules scanned : ${files.length}`);
console.log(`Imports counted : ${totalImports}`);
console.log('');

if (findings.length === 0) {
  console.log('Findings        : none');
  console.log('');
  console.log('RESULT: COMPOSED');
  process.exit(0);
} else {
  console.log(`Findings        : ${findings.length}`);
  console.log('');
  for (const f of findings) {
    console.log(`  [${f.checkId}] ${f.file}:${f.lineNum}`);
    console.log(`    Rule : ${f.description}`);
    console.log(`    Line : ${f.line}`);
    console.log('');
  }
  console.log('RESULT: INTEGRATION BREACH');
  process.exit(1);
}
