/**
 * C24 · Port tests.
 *
 * Tests PortState primitives, the absent EnvironmentPort, and the absent
 * FounderRuntimePort including full subscription lifecycle.
 */

import { test, describe } from 'node:test';
import assert from 'node:assert/strict';

import {
  unavailable,
  availableWith,
  isAvailable,
  createAbsentEnvironmentPort,
  ENVIRONMENT_ABSENT_REASON,
  createAbsentFounderRuntimePort,
  FOUNDER_RUNTIME_ABSENT_REASON,
} from '../src/ports/index.ts';

/* ─────────────────────── PortState primitives ─────────────────────────── */

describe('unavailable()', () => {
  test('sets available: false', () => {
    const s = unavailable('some reason');
    assert.equal(s.available, false);
  });

  test('carries the supplied reason', () => {
    const s = unavailable('test reason');
    assert.equal((s as { available: false; reason: string }).reason, 'test reason');
  });
});

describe('availableWith()', () => {
  test('sets available: true', () => {
    const s = availableWith(42);
    assert.equal(s.available, true);
  });

  test('carries the supplied value', () => {
    const s = availableWith({ x: 1 });
    assert.deepEqual((s as { available: true; value: { x: number } }).value, { x: 1 });
  });
});

describe('isAvailable()', () => {
  test('returns false for an unavailable state', () => {
    const s = unavailable('nope');
    assert.equal(isAvailable(s), false);
  });

  test('returns true for an available state', () => {
    const s = availableWith('hello');
    assert.equal(isAvailable(s), true);
  });

  test('narrows to available branch — value accessible after guard', () => {
    const s = availableWith('payload');
    if (!isAvailable(s)) throw new Error('Expected available');
    // TypeScript narrowing: s.value is accessible here
    assert.equal(s.value, 'payload');
  });

  test('narrows to unavailable branch — reason accessible', () => {
    const s = unavailable('gone');
    if (isAvailable(s)) throw new Error('Expected unavailable');
    assert.equal(s.reason, 'gone');
  });
});

/* ─────────────────────── EnvironmentPort ──────────────────────────────── */

describe('createAbsentEnvironmentPort()', () => {
  test('id is "environment"', () => {
    const port = createAbsentEnvironmentPort();
    assert.equal(port.id, 'environment');
  });

  test('contractVersion is null', () => {
    const port = createAbsentEnvironmentPort();
    assert.equal(port.contractVersion, null);
  });

  test('getEnvironment() returns available: false', () => {
    const port = createAbsentEnvironmentPort();
    const result = port.getEnvironment();
    assert.equal(result.available, false);
  });

  test('getEnvironment() reason equals ENVIRONMENT_ABSENT_REASON', () => {
    const port = createAbsentEnvironmentPort();
    const result = port.getEnvironment();
    assert.equal(result.available, false);
    const r = result as { available: false; reason: string };
    assert.ok(r.reason.length > 0, 'reason must be non-empty');
    assert.equal(r.reason, ENVIRONMENT_ABSENT_REASON);
  });

  test('getEnvironment() is stable across repeated calls', () => {
    const port = createAbsentEnvironmentPort();
    const r1 = port.getEnvironment();
    const r2 = port.getEnvironment();
    const r3 = port.getEnvironment();
    assert.equal(r1.available, false);
    assert.equal(r2.available, false);
    assert.equal(r3.available, false);
    // All should have same reason
    const reason1 = (r1 as { available: false; reason: string }).reason;
    const reason2 = (r2 as { available: false; reason: string }).reason;
    const reason3 = (r3 as { available: false; reason: string }).reason;
    assert.equal(reason1, reason2);
    assert.equal(reason2, reason3);
  });

  test('getEnvironment() never throws', () => {
    const port = createAbsentEnvironmentPort();
    assert.doesNotThrow(() => {
      for (let i = 0; i < 100; i++) port.getEnvironment();
    });
  });

  test('result JSON contains only "available" and "reason" keys', () => {
    const port = createAbsentEnvironmentPort();
    const result = port.getEnvironment();
    const keys = Object.keys(result);
    assert.deepEqual(keys.sort(), ['available', 'reason'].sort());
  });
});

/* ─────────────────────── FounderRuntimePort ────────────────────────────── */

describe('createAbsentFounderRuntimePort()', () => {
  test('id is "founder-runtime"', () => {
    const port = createAbsentFounderRuntimePort();
    assert.equal(port.id, 'founder-runtime');
  });

  test('contractVersion is null', () => {
    const port = createAbsentFounderRuntimePort();
    assert.equal(port.contractVersion, null);
  });

  test('getState() returns available: false', () => {
    const port = createAbsentFounderRuntimePort();
    const result = port.getState();
    assert.equal(result.available, false);
  });

  test('getState() reason equals FOUNDER_RUNTIME_ABSENT_REASON', () => {
    const port = createAbsentFounderRuntimePort();
    const result = port.getState();
    assert.equal(result.available, false);
    const r = result as { available: false; reason: string };
    assert.ok(r.reason.length > 0, 'reason must be non-empty');
    assert.equal(r.reason, FOUNDER_RUNTIME_ABSENT_REASON);
  });

  test('getState() is stable across repeated calls', () => {
    const port = createAbsentFounderRuntimePort();
    for (let i = 0; i < 10; i++) {
      const result = port.getState();
      assert.equal(result.available, false);
    }
  });

  test('getState() never throws', () => {
    const port = createAbsentFounderRuntimePort();
    assert.doesNotThrow(() => {
      for (let i = 0; i < 100; i++) port.getState();
    });
  });

  test('getState() result JSON contains only "available" and "reason" keys', () => {
    const port = createAbsentFounderRuntimePort();
    const result = port.getState();
    const keys = Object.keys(result);
    assert.deepEqual(keys.sort(), ['available', 'reason'].sort());
  });
});

/* ─────────────────────── Subscription lifecycle ────────────────────────── */

describe('FounderRuntimePort subscription lifecycle', () => {
  test('subscribe returns a function', () => {
    const port = createAbsentFounderRuntimePort();
    const unsub = port.subscribe(() => {});
    assert.equal(typeof unsub, 'function');
    unsub();
  });

  test('listener is NEVER invoked after getState() calls', async () => {
    const port = createAbsentFounderRuntimePort();
    let callCount = 0;
    const unsub = port.subscribe(() => { callCount += 1; });

    port.getState();
    port.getState();
    port.getState();

    // Wait one microtask/macrotask tick
    await new Promise<void>((resolve) => setTimeout(resolve, 0));

    assert.equal(callCount, 0, 'listener must never be called on absent port');
    unsub();
  });

  test('unsubscribe removes listener', async () => {
    const port = createAbsentFounderRuntimePort();
    let callCount = 0;
    const unsub = port.subscribe(() => { callCount += 1; });
    unsub();

    // No way to trigger the absent port, but verify unsub is callable without error
    await new Promise<void>((resolve) => setTimeout(resolve, 0));
    assert.equal(callCount, 0);
  });

  test('double-unsubscribe is safe (no throw)', () => {
    const port = createAbsentFounderRuntimePort();
    const unsub = port.subscribe(() => {});
    assert.doesNotThrow(() => {
      unsub();
      unsub(); // second call must not throw
    });
  });

  test('two independent subscriptions, each unsubscribe removes only its own', () => {
    const port = createAbsentFounderRuntimePort();
    let calls1 = 0;
    let calls2 = 0;
    const unsub1 = port.subscribe(() => { calls1 += 1; });
    const unsub2 = port.subscribe(() => { calls2 += 1; });

    // The absent port never fires, so both remain at 0
    // We verify they can each be unsubscribed independently without error
    assert.doesNotThrow(() => unsub1());
    assert.doesNotThrow(() => unsub2());

    // Both were registered independently — double-unsubscribing either is also safe
    assert.doesNotThrow(() => unsub1());
    assert.doesNotThrow(() => unsub2());

    assert.equal(calls1, 0);
    assert.equal(calls2, 0);
  });

  test('subscribing twice registers independently (listener count visible via Set behaviour)', () => {
    const port = createAbsentFounderRuntimePort();
    let count = 0;
    const listener = () => { count += 1; };

    const unsub1 = port.subscribe(listener);
    const unsub2 = port.subscribe(listener);

    // Both unsubs are separate functions
    assert.notEqual(unsub1, unsub2);

    // Each unsub works without throwing
    assert.doesNotThrow(() => unsub1());
    assert.doesNotThrow(() => unsub2());
  });
});

/* ─────────────────────── Ports hold no data ────────────────────────────── */

describe('Ports hold no data beyond availability', () => {
  test('EnvironmentPort getEnvironment() result has no extra keys', () => {
    const port = createAbsentEnvironmentPort();
    const result = port.getEnvironment();
    const allowed = new Set(['available', 'reason']);
    for (const key of Object.keys(result)) {
      assert.ok(allowed.has(key), `Unexpected key in getEnvironment() result: "${key}"`);
    }
  });

  test('FounderRuntimePort getState() result has no extra keys', () => {
    const port = createAbsentFounderRuntimePort();
    const result = port.getState();
    const allowed = new Set(['available', 'reason']);
    for (const key of Object.keys(result)) {
      assert.ok(allowed.has(key), `Unexpected key in getState() result: "${key}"`);
    }
  });

  test('JSON.stringify of getEnvironment() result contains no extra keys', () => {
    const port = createAbsentEnvironmentPort();
    const json = JSON.stringify(port.getEnvironment());
    const parsed = JSON.parse(json) as Record<string, unknown>;
    const keys = Object.keys(parsed);
    assert.deepEqual(keys.sort(), ['available', 'reason'].sort());
  });

  test('JSON.stringify of getState() result contains no extra keys', () => {
    const port = createAbsentFounderRuntimePort();
    const json = JSON.stringify(port.getState());
    const parsed = JSON.parse(json) as Record<string, unknown>;
    const keys = Object.keys(parsed);
    assert.deepEqual(keys.sort(), ['available', 'reason'].sort());
  });
});
