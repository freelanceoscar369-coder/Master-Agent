/**
 * C24 · Founder Edition — public barrel.
 *
 * Exports the four C24 components and re-exports the ports public API.
 * Does NOT export environment shapes, runtime state types, or anything that
 * would recreate the absent C22/C23 contracts.
 */

// ── Ports ────────────────────────────────────────────────────────────────────

export {
  unavailable,
  availableWith,
  isAvailable,
  createAbsentEnvironmentPort,
  ENVIRONMENT_ABSENT_REASON,
  createAbsentFounderRuntimePort,
  FOUNDER_RUNTIME_ABSENT_REASON,
} from './ports/index.ts';

export type {
  PortState,
  EnvironmentPort,
  FounderRuntimePort,
} from './ports/index.ts';

// ── Components ───────────────────────────────────────────────────────────────

export { AwaitingRuntime } from './components/AwaitingRuntime.tsx';
export type { AwaitingRuntimeProps } from './components/AwaitingRuntime.tsx';

export { EnvironmentPanel } from './components/EnvironmentPanel.tsx';
export type { EnvironmentPanelProps } from './components/EnvironmentPanel.tsx';

export { FounderRuntimePanel } from './components/FounderRuntimePanel.tsx';
export type { FounderRuntimePanelProps } from './components/FounderRuntimePanel.tsx';

export { LiveIndicator } from './components/LiveIndicator.tsx';
export type { LiveIndicatorProps } from './components/LiveIndicator.tsx';

export { FounderDashboard } from './components/FounderDashboard.tsx';
export type { FounderDashboardProps } from './components/FounderDashboard.tsx';
