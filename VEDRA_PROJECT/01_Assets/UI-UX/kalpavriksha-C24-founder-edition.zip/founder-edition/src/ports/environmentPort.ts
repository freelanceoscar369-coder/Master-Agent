/**
 * C24 · Environment port — the seam where C22 will attach.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * C22 (Environment Intelligence) was built in another session and is not
 * present in this workspace. See Engineering/C24_DEPENDENCY_MAP.md §3.
 *
 * This file therefore declares a PORT and nothing else:
 *   · no environment type
 *   · no field names (no browsers, no preferredBrowser, no capabilityGraph)
 *   · no default value, no sample, no fixture
 *   · no scanning, no detection, no discovery of any kind
 *
 * The payload is `unknown` deliberately. Typing it would recreate C22's
 * contract, which the brief forbids twice. As `unknown`, a component cannot
 * read a field from it — the compiler enforces the gap that discipline alone
 * would eventually fail to.
 *
 * WIRING C22 LATER (expected to be a three-line change):
 *   1. `import type { EnvironmentSnapshot } from '@kalpavriksha/environment';`
 *   2. change `EnvironmentPort` to `Port<EnvironmentSnapshot>`
 *   3. replace `createAbsentEnvironmentPort` with the real adapter
 * No component signature changes.
 * ═══════════════════════════════════════════════════════════════════════════
 */

import { unavailable, type PortState } from './portState.ts';

/** Reason shown wherever the environment would otherwise appear. */
export const ENVIRONMENT_ABSENT_REASON =
  'C22 Environment Intelligence is not present in this build.';

export interface EnvironmentPort {
  readonly id: 'environment';
  /** Null until C22 declares one. C24 never invents a version. */
  readonly contractVersion: null;
  /** Payload intentionally `unknown` — see the header. */
  getEnvironment(): PortState<unknown>;
}

/**
 * The only environment port C24 ships.
 *
 * Always reports unavailable. It performs no I/O, holds no state, and has no
 * code path that could return data — there is nothing behind it to return.
 */
export function createAbsentEnvironmentPort(): EnvironmentPort {
  return {
    id: 'environment',
    contractVersion: null,
    getEnvironment: () => unavailable(ENVIRONMENT_ABSENT_REASON),
  };
}
