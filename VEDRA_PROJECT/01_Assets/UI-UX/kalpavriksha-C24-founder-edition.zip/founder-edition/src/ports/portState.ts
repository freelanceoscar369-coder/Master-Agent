/**
 * C24 · Port state — availability without shape.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * The single most important type in C24.
 *
 * A port reports whether a dependency is reachable. It does NOT describe what
 * the dependency contains. That distinction is what keeps C24 from recreating
 * the C22 and C23 contracts it was forbidden to recreate.
 *
 * `available: false` carries a reason a founder can read. `available: true`
 * carries a payload whose type is supplied by the caller — and while C22/C23
 * are absent, that type parameter is `unknown`, which makes reading a field
 * from it a compile error rather than a judgement call.
 * ═══════════════════════════════════════════════════════════════════════════
 */

export type PortState<T> =
  | { readonly available: false; readonly reason: string }
  | { readonly available: true; readonly value: T };

/** Constructs the unavailable state. The only constructor C24 ever calls. */
export function unavailable(reason: string): PortState<never> {
  return { available: false, reason };
}

/** Present so a wired implementation has a constructor. Unused in C24. */
export function availableWith<T>(value: T): PortState<T> {
  return { available: true, value };
}

export function isAvailable<T>(s: PortState<T>): s is { available: true; value: T } {
  return s.available;
}
