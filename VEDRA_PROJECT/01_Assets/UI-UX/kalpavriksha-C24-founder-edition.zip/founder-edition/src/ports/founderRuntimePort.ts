/**
 * C24 · Founder Runtime port — the seam where C23 will attach.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * C23 (Founder Runtime) was built in another session and is not present in
 * this workspace. See Engineering/C24_DEPENDENCY_MAP.md §3.
 *
 * The brief states "All data comes from C23." With C23 absent, C24 does the
 * only honest thing available: it reads the contracts that DO exist (C20
 * presence, C19A conversation entries) directly from their owners, and
 * declares this port for the aggregate C23 is expected to provide.
 *
 * That is a stated deviation, recorded in HEALTH_C24.md §3. The alternative —
 * inventing a C23 aggregate shape so the dashboard could claim to read from it
 * — is precisely the fabrication the brief forbids.
 *
 * As with the environment port: no type, no fields, no defaults, no fixtures.
 * ═══════════════════════════════════════════════════════════════════════════
 */

import { unavailable, type PortState } from './portState.ts';

export const FOUNDER_RUNTIME_ABSENT_REASON =
  'C23 Founder Runtime is not present in this build.';

export interface FounderRuntimePort {
  readonly id: 'founder-runtime';
  readonly contractVersion: null;
  /** Payload intentionally `unknown` — C24 must not describe C23's aggregate. */
  getState(): PortState<unknown>;
  /**
   * Subscription seam. The absent port registers the listener, never calls it,
   * and returns a working unsubscribe — so subscription lifecycle is correct
   * and testable before C23 exists.
   */
  subscribe(listener: (state: unknown) => void): () => void;
}

export function createAbsentFounderRuntimePort(): FounderRuntimePort {
  const listeners = new Set<(s: unknown) => void>();
  return {
    id: 'founder-runtime',
    contractVersion: null,
    getState: () => unavailable(FOUNDER_RUNTIME_ABSENT_REASON),
    subscribe(listener) {
      listeners.add(listener);
      let removed = false;
      return () => {
        if (removed) return;
        removed = true;
        listeners.delete(listener);
      };
    },
  };
}
