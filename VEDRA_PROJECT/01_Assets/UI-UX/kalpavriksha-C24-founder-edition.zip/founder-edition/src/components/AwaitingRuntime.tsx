/**
 * C24 · AwaitingRuntime
 *
 * Brief requirement satisfied: honest unavailable state for any missing
 * dependency (C22 Environment Intelligence, C23 Founder Runtime). This
 * component is the canonical representation of "a port is absent". It is
 * never a placeholder for real content — the brief mandates this exact
 * treatment and it must not be replaced with fabricated or synthesised state.
 *
 * Design rules enforced here:
 *   - No red, no warning icon, no retry button (calm, not an error).
 *   - Uses the `muted` tone exclusively (--kv-ink-3).
 *   - The text "Awaiting runtime" appears verbatim — no paraphrase.
 *   - `reason` is optional ink-3 text; when absent the component still renders
 *     correctly.
 *   - No data, no fixtures, no invented fields.
 */

import { type ReactElement } from 'react';

export interface AwaitingRuntimeProps {
  /** Display name of the absent dependency, e.g. "Environment Intelligence". */
  readonly title: string;
  /** Human-readable reason from the port constant, e.g. ENVIRONMENT_ABSENT_REASON. */
  readonly reason?: string;
}

export function AwaitingRuntime({ title, reason }: AwaitingRuntimeProps): ReactElement {
  return (
    <div className="kv-awaiting">
      <span className="kv-awaiting__title">{title}</span>
      <span className="kv-awaiting__status">Awaiting runtime</span>
      {reason !== undefined && (
        <span className="kv-awaiting__reason">{reason}</span>
      )}
    </div>
  );
}
