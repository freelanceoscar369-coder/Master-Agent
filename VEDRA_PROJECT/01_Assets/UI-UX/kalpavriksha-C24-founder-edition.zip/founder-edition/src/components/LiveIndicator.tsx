/**
 * C24 · LiveIndicator
 *
 * Brief requirement satisfied: the ONLY animated element in C24. A live
 * indicator driven exclusively by real change in the snapshot sequence — no
 * timer, no setInterval, no random pulse, no simulated activity.
 *
 * Animation contract (strictly change-driven):
 *   - A ref tracks the previous `sequence` value.
 *   - When `sequence` increases, the CSS class `kv-live-indicator--flash` is
 *     applied for exactly 420ms, then removed.
 *   - If `sequence` does not change between renders, nothing animates.
 *   - `connected` is rendered as both a word and a colour:
 *       true  → "live"   in --kv-live
 *       false → STATIC_LABELS.disconnected in --kv-ink-3 (muted)
 *
 * This comment is the enforced documentation mandated by the brief: this is
 * the only animated element in C24 and it is strictly change-driven — no
 * timer produces motion on its own.
 */

import { useRef, useEffect, useState, type ReactElement } from 'react';
import { STATIC_LABELS } from '../../../surface/src/index.ts';

const FLASH_DURATION_MS = 420;

export interface LiveIndicatorProps {
  /** Monotonic sequence from PresenceSnapshot.sequence. Animation fires on increase. */
  readonly sequence: number;
  /** ISO-8601 timestamp from PresenceSnapshot.at. Rendered verbatim. */
  readonly at: string;
  /** True when snapshot !== null && !snapshot.meta.possiblyStale. */
  readonly connected: boolean;
}

export function LiveIndicator({ sequence, at, connected }: LiveIndicatorProps): ReactElement {
  const prevSequenceRef = useRef<number>(sequence);
  const [flashing, setFlashing] = useState(false);
  const flashTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    // Animate only when the sequence genuinely increases.
    if (sequence > prevSequenceRef.current) {
      prevSequenceRef.current = sequence;

      // Clear any in-progress flash timer before starting a new one.
      if (flashTimerRef.current !== null) {
        clearTimeout(flashTimerRef.current);
      }

      setFlashing(true);
      flashTimerRef.current = setTimeout(() => {
        setFlashing(false);
        flashTimerRef.current = null;
      }, FLASH_DURATION_MS);
    }
    // No else: if sequence did not increase, nothing changes.
  }, [sequence]);

  // Clean up the timer on unmount.
  useEffect(() => {
    return () => {
      if (flashTimerRef.current !== null) {
        clearTimeout(flashTimerRef.current);
      }
    };
  }, []);

  const dotClass = [
    'kv-live-indicator__dot',
    flashing ? 'kv-live-indicator__dot--flash' : '',
    connected ? 'kv-live-indicator__dot--connected' : 'kv-live-indicator__dot--disconnected',
  ]
    .filter(Boolean)
    .join(' ');

  const statusClass = connected
    ? 'kv-live-indicator__status kv-live-indicator__status--connected'
    : 'kv-live-indicator__status kv-live-indicator__status--disconnected';

  const statusText = connected ? 'live' : STATIC_LABELS.disconnected;

  return (
    <div className="kv-live-indicator">
      <span className={dotClass} aria-hidden="true" />
      <span className={statusClass}>{statusText}</span>
      {at.length > 0 && (
        <span className="kv-live-indicator__at">{at}</span>
      )}
    </div>
  );
}
