/**
 * C24 · FounderDashboard
 *
 * Brief requirement satisfied: the composition root for the Founder Edition
 * UI. Composes C21's ConversationSurface with the right-rail panels
 * (LiveIndicator, EnvironmentPanel, FounderRuntimePanel) in a two-column
 * layout at full viewport height.
 *
 * Composition rules enforced here:
 *   - C21's <ConversationSurface> is placed whole. It is not redesigned,
 *     forked, re-styled, or reimplemented.
 *   - snapshot === null is handled by C21 itself (via absentPresence).
 *     This dashboard does NOT branch around it.
 *   - No entries are appended here. No conversation state is created here.
 *     onSend passes straight through to ConversationSurface unchanged.
 *
 * PRESENCE / MISSION / ACTIVITY / CALM / VIGILANCE: already rendered by
 * C21's PresenceHeader and MissionStrip inside ConversationSurface. They are
 * intentionally absent from the right column — duplicating them here would
 * create a second source of truth for the same runtime state.
 */

import { type ReactElement } from 'react';
import type { PresenceSnapshot } from '../../../presence/src/index.ts';
import type { ConversationEntry } from '../../../desktop/src/types/execution.ts';
import {
  ConversationSurface,
  DEFAULT_FOUNDER_MODE,
  type FounderModeConfig,
} from '../../../surface/src/index.ts';
import {
  createAbsentEnvironmentPort,
  createAbsentFounderRuntimePort,
  type EnvironmentPort,
  type FounderRuntimePort,
} from '../ports/index.ts';
import { LiveIndicator } from './LiveIndicator.tsx';
import { EnvironmentPanel } from './EnvironmentPanel.tsx';
import { FounderRuntimePanel } from './FounderRuntimePanel.tsx';

export interface FounderDashboardProps {
  readonly snapshot: PresenceSnapshot | null;
  readonly entries: readonly ConversationEntry[];
  readonly founderMode?: FounderModeConfig;
  readonly environmentPort?: EnvironmentPort;
  readonly founderRuntimePort?: FounderRuntimePort;
  /** Passed straight through to ConversationSurface. No transformation here. */
  readonly onSend?: (text: string) => void;
}

export function FounderDashboard({
  snapshot,
  entries,
  founderMode = DEFAULT_FOUNDER_MODE,
  environmentPort = createAbsentEnvironmentPort(),
  founderRuntimePort = createAbsentFounderRuntimePort(),
  onSend,
}: FounderDashboardProps): ReactElement {
  // Live indicator inputs derived from the snapshot.
  // sequence=0 and at='' when absent — LiveIndicator handles both.
  const sequence = snapshot !== null ? snapshot.sequence : 0;
  const at = snapshot !== null ? snapshot.at : '';
  // connected = snapshot arrived AND not possibly stale.
  const connected = snapshot !== null && !snapshot.meta.possiblyStale;

  return (
    <div className="kv-dashboard">
      {/*
       * Left column (~2/3): C21 ConversationSurface — placed whole.
       * PresenceHeader, MissionStrip, ConversationArea, FounderActions, and
       * Composer are all inside this component. None are re-rendered here.
       */}
      <div className="kv-dashboard__primary">
        <ConversationSurface
          snapshot={snapshot}
          entries={entries}
          founderMode={founderMode}
          onSend={onSend}
        />
      </div>

      {/*
       * Right column (~1/3): supplementary panels.
       * Presence, Mission, Activity, Calm, and Vigilance are already rendered
       * by C21 in the left column. They must not appear here — duplication
       * would mean two components rendering the same runtime state, which
       * diverges the moment either render path lags.
       */}
      <div className="kv-dashboard__rail">
        {/* Hairline-separated stacked sections */}
        <div className="kv-dashboard__rail-section">
          <LiveIndicator sequence={sequence} at={at} connected={connected} />
        </div>
        <div className="kv-dashboard__rail-section">
          <EnvironmentPanel port={environmentPort} />
        </div>
        <div className="kv-dashboard__rail-section">
          <FounderRuntimePanel port={founderRuntimePort} />
        </div>
      </div>
    </div>
  );
}
