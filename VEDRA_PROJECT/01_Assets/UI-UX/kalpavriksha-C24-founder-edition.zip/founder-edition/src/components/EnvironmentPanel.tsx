/**
 * C24 · EnvironmentPanel
 *
 * Brief requirement satisfied: renders the availability state of the C22
 * Environment Intelligence port. When the port is unavailable (the only
 * possible outcome in this build), renders <AwaitingRuntime>. When available,
 * renders a mono contract-present notice — nothing field-specific, because
 * the payload type is `unknown` and C24 is forbidden from declaring C22's
 * contract.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * FIELDS NAMED IN BRIEF — NONE DECLARED HERE
 *
 * The brief names six fields the environment panel should eventually display:
 *   1. browsers               — type unknown; not declared
 *   2. preferred browser      — type unknown; not declared
 *   3. preferred editor       — type unknown; not declared
 *   4. preferred AI           — type unknown; not declared
 *   5. capability graph       — type unknown; not declared
 *   6. environment summary    — type unknown; not declared
 *
 * NONE of these are declared because their types are unknown to this session.
 * Declaring even a provisional shape would recreate C22's contract, which the
 * brief forbids twice. When C22's real type lands, this panel maps its fields
 * at the marked spot below.
 * ═══════════════════════════════════════════════════════════════════════════
 */

import { type ReactElement } from 'react';
import { isAvailable, type EnvironmentPort } from '../ports/index.ts';
import { AwaitingRuntime } from './AwaitingRuntime.tsx';

export interface EnvironmentPanelProps {
  readonly port: EnvironmentPort;
}

export function EnvironmentPanel({ port }: EnvironmentPanelProps): ReactElement {
  const state = port.getEnvironment();

  if (!isAvailable(state)) {
    return (
      <div className="kv-rail-panel">
        <AwaitingRuntime title="Environment Intelligence" reason={state.reason} />
      </div>
    );
  }

  // C22 contract is present but this build does not know its shape.
  // The payload is `unknown` by design — reading any field from it is a
  // compile error, enforcing the gap until C22's real type replaces `unknown`
  // in environmentPort.ts.
  //
  // ── C22 FIELD MAPPING POINT ──────────────────────────────────────────────
  // When C22's EnvironmentSnapshot type lands:
  //   1. Change EnvironmentPort payload from `unknown` to `EnvironmentSnapshot`.
  //   2. Destructure `state.value` here and render the six brief-named fields.
  //   3. Remove the mono notice below.
  // No component signature changes are needed.
  // ─────────────────────────────────────────────────────────────────────────
  return (
    <div className="kv-rail-panel">
      <span className="kv-rail-panel__contract-present">
        environment · contract present · fields unmapped
      </span>
    </div>
  );
}
