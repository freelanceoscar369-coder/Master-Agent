/**
 * C24 · FounderRuntimePanel
 *
 * Brief requirement satisfied: renders the availability state of the C23
 * Founder Runtime port. When unavailable (the only outcome in this build),
 * renders <AwaitingRuntime>. Subscribes to port.subscribe in a useEffect with
 * correct cleanup — the absent port registers the listener and never calls it,
 * but the lifecycle is correct and testable before C23 exists.
 *
 * The payload type is `unknown` by design. C24 does not know C23's aggregate
 * shape and is forbidden from inventing one. When C23 lands, its real type
 * replaces `unknown` in founderRuntimePort.ts and the mapping point below
 * becomes live.
 */

import { useEffect, type ReactElement } from 'react';
import { isAvailable, type FounderRuntimePort } from '../ports/index.ts';
import { AwaitingRuntime } from './AwaitingRuntime.tsx';

export interface FounderRuntimePanelProps {
  readonly port: FounderRuntimePort;
}

export function FounderRuntimePanel({ port }: FounderRuntimePanelProps): ReactElement {
  // Subscribe to port updates. The absent port registers the listener and
  // never emits — unsubscribing on cleanup is still mandatory and is correct.
  // When C23 arrives and the real port emits, a re-render will be triggered
  // by the subscription handler (which at that point will call a state setter
  // added here alongside the C23 field mapping).
  useEffect(() => {
    // The listener is intentionally a no-op: this build has no C23 state to
    // fold in. It exists so the subscription lifecycle is exercised and
    // verifiable without C23 being present.
    const unsubscribe = port.subscribe((_state: unknown) => {
      // ── C23 STATE MAPPING POINT ─────────────────────────────────────────
      // When C23's FounderRuntimeState type lands:
      //   1. Change FounderRuntimePort payload from `unknown` to that type.
      //   2. Add a useState here to hold the received state.
      //   3. Call the setter with the typed value from `_state`.
      //   4. Render C23's fields below (replacing the contract-present notice).
      // No prop signature changes are needed.
      // ────────────────────────────────────────────────────────────────────
    });
    return unsubscribe;
  }, [port]);

  const state = port.getState();

  if (!isAvailable(state)) {
    return (
      <div className="kv-rail-panel">
        <AwaitingRuntime title="Founder Runtime" reason={state.reason} />
      </div>
    );
  }

  // C23 contract is present but this build does not know its shape.
  return (
    <div className="kv-rail-panel">
      <span className="kv-rail-panel__contract-present">
        founder-runtime · contract present · fields unmapped
      </span>
    </div>
  );
}
