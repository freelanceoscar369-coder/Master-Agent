# HEALTH — C24 · Founder Edition UI Integration

**Status:** delivered to the limit of available grounding. Stopping. Awaiting audit.

| Check | Result |
|---|---|
| `npm test` | **52 pass / 0 fail**, 15 suites |
| `node tests/integration-guard.mjs` | **COMPOSED** — 10 modules, 37 imports, 0 findings |
| Recreated contract types | **0** |
| Fabricated field names in code | **0** |
| Imports of `environment/` or `founder-runtime/` | **0** |
| `setInterval` / `Math.random` in source | **0** |
| Runtime dependencies | **zero** (React is a peer) |

Deliverables: `Engineering/C24_DEPENDENCY_MAP.md` · `Engineering/C24_BLOCKERS.md` ·
`founder-edition/` · this file.

---

## 1 · What was composed

C24 wrote **no new UI**. It placed existing assets.

| Asset | Origin | Treatment |
|---|---|---|
| `ConversationSurface` (with header, strip, area, composer, actions) | C21 | Imported whole and placed. Not forked, not restyled, not reimplemented. |
| `PresenceSnapshot` and members | C20 | Consumed as types. C24 creates no layer, folds no observation, calls no `derive*`. |
| `ConversationEntry` | C19A | Consumed as a type. |
| Design tokens | C21 `surface.css` | Referenced via `var(--kv-*)`. **Zero tokens redefined** — verified. |

New code is layout plus two port consumers: **633 lines** across 5 components,
1 stylesheet and a barrel.

Presence · Conversation · Mission · Activity · Calm · Vigilance are all
rendered — by C21's own `PresenceHeader` and `MissionStrip`. **They are
deliberately not repeated in the right rail.** Duplicating them would create a
second source of truth for the same snapshot, which is the failure mode an
integration milestone exists to prevent.

---

## 2 · The two absent dependencies

C22 Environment Intelligence and C23 Founder Runtime are not in this
workspace. Verified by recursive scan, recorded in `C24_BLOCKERS.md`.

### How the gap is held open without fabricating

Both ports carry `PortState<unknown>`.

```ts
getEnvironment(): PortState<unknown>;
getState(): PortState<unknown>;
```

**`unknown` is the whole mechanism.** Typing the payload — even
"provisionally" — would have become the de-facto C22 contract the moment a
component read a field from it. With `unknown`, reading a field is a **compile
error**. The absence is enforced by the type system rather than by my
discipline holding for the length of a build.

The consequence is intentional and visible: the Environment Panel *cannot*
render browsers, preferred browser, preferred editor, preferred AI, capability
graph or environment summary. It renders what the brief mandated:

```
Environment Intelligence
Awaiting runtime
```
```
Founder Runtime
Awaiting runtime
```

Both strings verified present verbatim in the source.

The six field names appear in exactly one place in C24 — a comment in
`EnvironmentPanel.tsx` documenting what is deliberately absent. A test asserts
they appear in **no code line anywhere**.

---

## 3 · Declared deviation — "All data comes from C23"

The brief states this. C23 does not exist.

C24 therefore reads **C20 presence and C19A conversation entries directly from
their owning packages**, and declares the C23 port for the aggregate it is
expected to supply.

I judged this more honest than the alternative, which would have required
inventing a C23 aggregate shape so the dashboard could claim to read from it —
fabricating the exact contract the brief forbade in the same paragraph.

**If C23 should be the sole source even for presence, that is a one-question
decision** recorded as item 2 in the dependency map's reconciliation checklist.
It changes where `FounderDashboard` reads from, not how anything renders.

---

## 4 · Living feel, without fake activity

The brief asks for smooth transitions, subtle animation, status changes and
live indicators — and forbids fake activity. Those pull against each other when
there is no live data.

Resolution: **`LiveIndicator` is the only animated element in C24, and it is
strictly change-driven.** It holds the previous snapshot `sequence` in a ref;
when the sequence *increases*, a dot fades from full to resting opacity over
420ms. If the sequence does not change, nothing moves. There is no timer, no
loop, no simulated pulse.

`setInterval` is banned outright by the integration guard — stricter than C21,
deliberately, because C24 is where a "make it feel alive" instinct would put
one. Connection state renders as **word and colour** (`no signal`), never
colour alone.

The honest result: **on a dead feed, C24 is completely still.** That is
correct. A product that animates when nothing is happening is lying, and this
one is built to be trusted about exactly that.

---

## 5 · Constraint compliance

| Forbidden | Status | Evidence |
|---|---|---|
| New architecture | ✅ none | Two ports reusing the C19A port pattern; no new concepts |
| Backend logic | ✅ none | Guard fails on `fetch`, `WebSocket`, `EventSource`, `node:http` |
| Runtime changes | ✅ none | No file outside `founder-edition/` and `Engineering/` written |
| Kernel changes | ✅ none | No kernel symbol referenced |
| Scanning logic | ✅ none | C24 discovers nothing about the machine |
| Orchestration | ✅ none | No scheduler, planner or dispatcher |
| AI routing | ✅ none | No model concept |
| Redesign of existing assets | ✅ none | C21 components imported, not modified |
| Recreated types | ✅ none | 0 contract types matching `Environment(Snapshot\|State\|Data)` or `FounderRuntime(State\|Snapshot)` |
| Duplicate contracts | ✅ none | Presence/Vigilance/Calm read from C20 as fact |
| Fake data / fixtures | ✅ none | No file named `fixture\|mock\|sample\|seed\|demo\|fake`; ports return no payload |
| Fake responses / AI generation | ✅ none | C24 emits no assistant text; no greeting regex match |
| Electron | ✅ none | Guard fails on `electron`, `ipcRenderer`, `webContents` |

---

## 6 · Tests

52 assertions, 15 suites, no network, no timers, no fixtures.

| File | Covers |
|---|---|
| `ports.test.ts` | Both factories: id, `contractVersion === null`, unavailable reasons, repeat-call stability, no throws. Subscription lifecycle: listener never invoked, unsubscribe works, **double-unsubscribe safe**, independent registration. `isAvailable` narrowing. **Ports carry no payload** — serialised result has only `available` and `reason`. |
| `noFabrication.test.ts` | No `value` key on unavailable results. **None of the 11 environment field identifiers appear in any code line** (comments permitted, and used to document the absence). No recreated contract type. No greeting. No fixture-named file. |
| `composition.test.ts` | Builds a **real C20 snapshot** via `createPresenceLayer()` and asserts all 8 presence fields — proving the contract C24 depends on is genuinely present and intact. Barrel exports ports, not contracts. |
| `integration-guard.mjs` | External imports, **imports of the absent packages**, network APIs, Electron, `Math.random`, `setInterval`, literal URLs. |

**Run:**
```
cd founder-edition
npm test        # 52 pass
npm run verify  # guard + tests
```

> Invocation trap: `node --test tests/` fails — use
> `node --test 'tests/**/*.test.ts'`, which is what `npm test` runs.

---

## 7 · Known issues

**Blocking completion** — see `Engineering/C24_BLOCKERS.md`
1. C22 Environment Intelligence package absent.
2. C23 Founder Runtime package absent.

Both are absent directories, not open decisions. Nothing in C24 waits on a
judgement call.

**Environmental**
3. **Components never rendered or type-checked.** React cannot be installed
   here. The 5 `.tsx` files have never mounted. All `.ts` logic is tested.
4. **No `tsc` run.** Node's type-stripping executes `.ts` but does not
   type-check, and does not process `.tsx`.
5. `composition.test.ts` cannot import the barrel at runtime, because the
   barrel re-exports `.tsx` and Node has no JSX transform. That one assertion
   is covered by static text analysis instead, and the skip is logged rather
   than hidden.

**By design**
6. On a dead feed the interface is completely still (§4).
7. The right rail shows two `Awaiting runtime` panels — that is the specified
   behaviour, not a placeholder to be replaced with content.

---

## 8 · Wiring cost once C22/C23 land

```
environmentPort.ts     3 lines   import type · replace `unknown` · swap factory
founderRuntimePort.ts  3 lines   same
EnvironmentPanel.tsx   n lines   map real fields at the marked location
FounderDashboard.tsx   0 lines   unchanged
ConversationSurface    0 lines   unchanged (C21, untouched)
presence/              0 lines   unchanged (C20, untouched)
```

If wiring C22/C23 requires changing anything in C20, C21, or the dashboard
layout, this integration was built wrong and I would want to know.

---

**Stopping here as instructed. Awaiting audit.**
