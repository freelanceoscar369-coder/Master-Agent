import { test, describe } from 'node:test';
import assert from 'node:assert/strict';

import { FOUNDER_ACTIONS } from '../src/config/founderActions.ts';

describe('FOUNDER_ACTIONS — count and keys', () => {
  test('exactly 4 actions', () => {
    assert.equal(FOUNDER_ACTIONS.length, 4);
  });

  test('keys are start-mission, review-approvals, show-activity, open-settings in that order', () => {
    const expectedKeys = ['start-mission', 'review-approvals', 'show-activity', 'open-settings'];
    const actualKeys = FOUNDER_ACTIONS.map((a) => a.key);
    assert.deepEqual(actualKeys, expectedKeys);
  });
});

describe('FOUNDER_ACTIONS — non-empty label and reason', () => {
  for (let i = 0; i < 4; i++) {
    test(`action[${i}] has non-empty label`, () => {
      const action = FOUNDER_ACTIONS[i];
      assert.ok(action !== undefined);
      assert.ok(typeof action.label === 'string' && action.label.length > 0, `label is empty`);
    });

    test(`action[${i}] has non-empty reason`, () => {
      const action = FOUNDER_ACTIONS[i];
      assert.ok(action !== undefined);
      assert.ok(typeof action.reason === 'string' && action.reason.length > 0, `reason is empty`);
    });
  }
});

describe('FOUNDER_ACTIONS — nothing is wired', () => {
  test('no action has any function-valued property', () => {
    for (const action of FOUNDER_ACTIONS) {
      for (const value of Object.values(action)) {
        assert.notEqual(
          typeof value,
          'function',
          `Action "${action.key}" has a function-valued property — brief says nothing is wired`,
        );
      }
    }
  });
});
