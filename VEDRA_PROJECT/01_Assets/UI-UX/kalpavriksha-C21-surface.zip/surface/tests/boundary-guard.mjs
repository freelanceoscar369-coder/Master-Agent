/**
 * Boundary guard for C21 surface.
 *
 * Walks src/**\/*.{ts,tsx} and fails with exit 1 if any of the forbidden
 * patterns are found. Skips comment lines.
 *
 * Run: node tests/boundary-guard.mjs
 */

import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join, extname, relative } from 'node:path';

/* ─────────────────────── file walker ───────────────────────────────────── */

function walk(dir) {
  const results = [];
  let entries;
  try {
    entries = readdirSync(dir);
  } catch {
    return results;
  }
  for (const name of entries) {
    const full = join(dir, name);
    let stat;
    try {
      stat = statSync(full);
    } catch {
      continue;
    }
    if (stat.isDirectory()) {
      results.push(...walk(full));
    } else {
      const ext = extname(name);
      if (ext === '.ts' || ext === '.tsx') {
        results.push(full);
      }
    }
  }
  return results;
}

/* ─────────────────────── comment line detector ─────────────────────────── */

/** Returns true if the trimmed line starts like a comment (skip it). */
function isCommentLine(trimmed) {
  return (
    trimmed.startsWith('//') ||
    trimmed.startsWith('/*') ||
    trimmed.startsWith('*')
  );
}

/* ─────────────────────── patterns ──────────────────────────────────────── */

/**
 * External package import: an import/require from a bare specifier that is not:
 * - a relative path (./  or ../)
 * - node: builtins
 * - The allowed cross-package paths (../../presence/ or ../../desktop/)
 * The only allowed external is `react`.
 */
const EXTERNAL_IMPORT_RE = /(?:import|require)\s*(?:type\s+)?(?:\{[^}]*\}|\*[^'"]*|['"])\s*from\s*['"]([^'"]+)['"]/g;

function checkExternalImport(line, filePath, findings, lineNo) {
  // Reset lastIndex before each use.
  EXTERNAL_IMPORT_RE.lastIndex = 0;
  let m;
  while ((m = EXTERNAL_IMPORT_RE.exec(line)) !== null) {
    const spec = m[1];
    if (!spec) continue;
    // Relative imports are fine.
    if (spec.startsWith('./') || spec.startsWith('../')) continue;
    // node: builtins are fine (not present in src, but safe to allow).
    if (spec.startsWith('node:')) continue;
    // react is the only allowed external peer.
    if (spec === 'react' || spec.startsWith('react/') || spec.startsWith('react-')) continue;
    // Anything else is a violation.
    findings.push({
      file: filePath,
      line: lineNo,
      rule: 'external-import',
      text: line.trim(),
      detail: `import from "${spec}"`,
    });
  }
}

const FORBIDDEN_PATTERNS = [
  { re: /\bfetch\s*\(/, rule: 'fetch(', skipTsx: false },
  { re: /\bXMLHttpRequest\b/, rule: 'XMLHttpRequest', skipTsx: false },
  { re: /\bWebSocket\b/, rule: 'WebSocket', skipTsx: false },
  { re: /\bEventSource\b/, rule: 'EventSource', skipTsx: false },
  { re: /['"]node:fs['"]/, rule: 'node:fs', skipTsx: false },
  { re: /['"]node:http['"]/, rule: 'node:http', skipTsx: false },
  { re: /\bchild_process\b/, rule: 'child_process', skipTsx: false },
  { re: /\bsetInterval\s*\(/, rule: 'setInterval(', skipTsx: true },  // allowed in .tsx
  { re: /\bsetTimeout\s*\(/, rule: 'setTimeout(', skipTsx: true },    // allowed in .tsx
  { re: /\bMath\.random\s*\(/, rule: 'Math.random(', skipTsx: false },
  { re: /good (morning|afternoon|evening)/i, rule: 'greeting', skipTsx: false },
  { re: /['"]electron['"]/, rule: 'electron import', skipTsx: false },
  { re: /\bipcRenderer\b/, rule: 'ipcRenderer', skipTsx: false },
  { re: /\bwebContents\b/, rule: 'webContents', skipTsx: false },
  // api/ or http(s):// outside comments
  { re: /api\/|https?:\/\//, rule: 'api/https URL', skipTsx: false },
];

/* ─────────────────────── main ──────────────────────────────────────────── */

const srcDir = join(new URL('.', import.meta.url).pathname, '..', 'src');
const files = walk(srcDir);

let modulesScanned = 0;
let importsFound = 0;
const findings = [];

for (const filePath of files) {
  const rel = relative(srcDir, filePath);
  const isTsx = filePath.endsWith('.tsx');
  modulesScanned++;

  let content;
  try {
    content = readFileSync(filePath, 'utf8');
  } catch {
    findings.push({ file: rel, line: 0, rule: 'read-error', text: '', detail: 'Could not read file' });
    continue;
  }

  const lines = content.split('\n');
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i] ?? '';
    const trimmed = line.trim();
    if (trimmed.length === 0) continue;

    // Count import statements.
    if (/^\s*import\b/.test(line)) importsFound++;

    // Skip comment lines entirely.
    if (isCommentLine(trimmed)) continue;

    // Check external imports.
    checkExternalImport(line, rel, findings, i + 1);

    // Check forbidden patterns.
    for (const { re, rule, skipTsx } of FORBIDDEN_PATTERNS) {
      if (skipTsx && isTsx) continue;
      if (re.test(line)) {
        findings.push({ file: rel, line: i + 1, rule, text: trimmed });
      }
    }
  }
}

/* ─────────────────────── report ────────────────────────────────────────── */

console.log('');
console.log('C21 Boundary Guard');
console.log('══════════════════════════════════════════════════════');
console.log(`Modules scanned : ${modulesScanned}`);
console.log(`Import lines    : ${importsFound}`);
console.log('');

if (findings.length === 0) {
  console.log('Findings        : none');
  console.log('');
  console.log('RESULT: BOUNDED');
  process.exit(0);
} else {
  console.log(`Findings        : ${findings.length}`);
  console.log('');
  for (const f of findings) {
    console.log(`  [${f.rule}] ${f.file}:${f.line}`);
    if (f.detail) console.log(`    → ${f.detail}`);
    if (f.text) console.log(`    ${f.text}`);
  }
  console.log('');
  console.log('RESULT: BOUNDARY BREACH');
  process.exit(1);
}
