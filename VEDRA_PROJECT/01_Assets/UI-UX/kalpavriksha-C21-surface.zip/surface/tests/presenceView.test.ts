import { test, describe } from 'node:test';
import assert from 'node:assert/strict';

import {
  projectPresence,
  absentPresence,
  stripFields,
  STATIC_LABELS,
} from '../src/presentation/presenceView.ts';
import type { PresenceView, ViewField } from '../src/presentation/presenceView.ts';
import { buildSnapshot, ALL_VARIANTS } from './helpers.ts';

const ASSISTANT_NAME = 'TestBot';
const ALLOWED_TONES: ReadonlySet<string> = new Set(['live', 'needs-you', 'done', 'risk', 'muted']);

const EIGHT_FIELDS: ReadonlyArray<keyof PresenceView> = [
  'mission', 'execution', 'approvals', 'calm',
  'vigilance', 'activity', 'lastAction', 'reasoning',
];

describe('projectPresence — totality', () => {
  for (const variant of ALL_VARIANTS) {
    test(`${variant}: produces all 8 fields plus meta`, () => {
      const snap = buildSnapshot(variant);
      const view = projectPresence(snap, ASSISTANT_NAME);

      // Check the 8 named fields exist.
      for (const field of EIGHT_FIELDS) {
        assert.ok(Object.hasOwn(view, field), `missing field: ${field}`);
      }
      // Meta fields.
      assert.ok(Object.hasOwn(view, 'assistantName'), 'missing assistantName');
      assert.ok(Object.hasOwn(view, 'possiblyStale'), 'missing possiblyStale');
      assert.ok(Object.hasOwn(view, 'sequence'), 'missing sequence');
      assert.ok(Object.hasOwn(view, 'at'), 'missing at');
    });
  }
});

describe('projectPresence — field shape', () => {
  const staticLabelValues = new Set(Object.values(STATIC_LABELS));

  for (const variant of ALL_VARIANTS) {
    test(`${variant}: every field has a label from STATIC_LABELS and an allowed tone`, () => {
      const snap = buildSnapshot(variant);
      const view = projectPresence(snap, ASSISTANT_NAME);

      for (const key of EIGHT_FIELDS) {
        const field = view[key] as ViewField;
        assert.ok(
          staticLabelValues.has(field.label as string),
          `${key}.label "${field.label}" not in STATIC_LABELS`,
        );
        assert.ok(
          ALLOWED_TONES.has(field.tone),
          `${key}.tone "${field.tone}" not in allowed set`,
        );
      }
    });
  }
});

describe('projectPresence — verbatim values', () => {
  test('mission title appears verbatim', () => {
    const snap = buildSnapshot('with-running-mission');
    const view = projectPresence(snap, ASSISTANT_NAME);
    assert.ok(
      view.mission.value.includes('Process Data Pipeline'),
      `expected mission title in "${view.mission.value}"`,
    );
  });

  test('held mission title appears verbatim', () => {
    const snap = buildSnapshot('with-held-mission');
    const view = projectPresence(snap, ASSISTANT_NAME);
    assert.ok(
      view.mission.value.includes('Deploy Alpha Release'),
      `expected held mission title in "${view.mission.value}"`,
    );
  });

  test('calm statement appears verbatim', () => {
    const snap = buildSnapshot('calm');
    const view = projectPresence(snap, ASSISTANT_NAME);
    // The C20 calm statement when calm is "Nothing needs you."
    assert.ok(
      view.calm.value.includes('Nothing needs you.'),
      `expected calm statement in "${view.calm.value}"`,
    );
  });

  test('activity line appears verbatim', () => {
    const snap = buildSnapshot('with-running-mission');
    const view = projectPresence(snap, ASSISTANT_NAME);
    // C20 generates "Working on Process Data Pipeline."
    assert.ok(
      view.activity.value.includes('Process Data Pipeline'),
      `expected activity line in "${view.activity.value}"`,
    );
  });

  test('reasoning text appears verbatim', () => {
    const snap = buildSnapshot('with-reasoning');
    const view = projectPresence(snap, ASSISTANT_NAME);
    assert.ok(
      view.reasoning.value.includes('Evaluating options for the next deployment step'),
      `expected reasoning text in "${view.reasoning.value}"`,
    );
  });

  test('last action description appears verbatim', () => {
    const snap = buildSnapshot('with-failure');
    const view = projectPresence(snap, ASSISTANT_NAME);
    assert.ok(
      view.lastAction.value.includes('Connection retry initiated'),
      `expected action description in "${view.lastAction.value}"`,
    );
  });
});

describe('projectPresence — null paths', () => {
  test('no mission → value=None, source=static', () => {
    const snap = buildSnapshot('empty');
    const view = projectPresence(snap, ASSISTANT_NAME);
    assert.equal(view.mission.value, STATIC_LABELS.none);
    assert.equal(view.mission.source, 'static');
  });

  test('no approvals → value=None, source=static', () => {
    const snap = buildSnapshot('calm');
    const view = projectPresence(snap, ASSISTANT_NAME);
    assert.equal(view.approvals.value, STATIC_LABELS.none);
    assert.equal(view.approvals.source, 'static');
  });

  test('no last action → value=None, source=static', () => {
    const snap = buildSnapshot('empty');
    const view = projectPresence(snap, ASSISTANT_NAME);
    assert.equal(view.lastAction.value, STATIC_LABELS.none);
    assert.equal(view.lastAction.source, 'static');
  });

  test('reasoning null → value=absent label, source=static', () => {
    const snap = buildSnapshot('empty');
    const view = projectPresence(snap, ASSISTANT_NAME);
    assert.equal(view.reasoning.value, STATIC_LABELS.absent);
    assert.equal(view.reasoning.source, 'static');
  });
});

describe('absentPresence', () => {
  test('every field value is "no signal"', () => {
    const view = absentPresence(ASSISTANT_NAME);
    for (const key of EIGHT_FIELDS) {
      const field = view[key] as ViewField;
      assert.equal(
        field.value,
        STATIC_LABELS.disconnected,
        `${key}.value should be "no signal", got "${field.value}"`,
      );
    }
  });

  test('every field tone is muted', () => {
    const view = absentPresence(ASSISTANT_NAME);
    for (const key of EIGHT_FIELDS) {
      const field = view[key] as ViewField;
      assert.equal(field.tone, 'muted', `${key}.tone should be muted`);
    }
  });

  test('possiblyStale is true', () => {
    const view = absentPresence(ASSISTANT_NAME);
    assert.equal(view.possiblyStale, true);
  });

  test('assistantName is carried through', () => {
    const view = absentPresence('MyName');
    assert.equal(view.assistantName, 'MyName');
  });
});

describe('stripFields', () => {
  test('returns exactly 5 fields in fixed order: mission, execution, approvals, calm, vigilance', () => {
    const snap = buildSnapshot('calm');
    const view = projectPresence(snap, ASSISTANT_NAME);
    const strip = stripFields(view);
    assert.equal(strip.length, 5);
    assert.equal(strip[0], view.mission);
    assert.equal(strip[1], view.execution);
    assert.equal(strip[2], view.approvals);
    assert.equal(strip[3], view.calm);
    assert.equal(strip[4], view.vigilance);
  });
});

describe('projectPresence — purity', () => {
  test('calling twice on same snapshot yields deep-equal output', () => {
    const snap = buildSnapshot('with-running-mission');
    const v1 = projectPresence(snap, ASSISTANT_NAME);
    const v2 = projectPresence(snap, ASSISTANT_NAME);
    assert.deepEqual(v1, v2);
  });

  test('snapshot is not mutated by projectPresence', () => {
    const snap = buildSnapshot('with-running-mission');
    // Serialise before.
    const before = JSON.stringify(snap);
    projectPresence(snap, ASSISTANT_NAME);
    const after = JSON.stringify(snap);
    assert.equal(before, after);
  });
});
