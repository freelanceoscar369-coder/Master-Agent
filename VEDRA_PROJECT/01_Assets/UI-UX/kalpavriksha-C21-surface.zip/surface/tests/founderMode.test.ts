import { test, describe } from 'node:test';
import assert from 'node:assert/strict';

import * as fm from '../src/config/founderMode.ts';
import {
  DEFAULT_FOUNDER_MODE,
  validateFounderMode,
  readFounderMode,
  writeFounderMode,
  MAX_NAME_LENGTH,
} from '../src/config/founderMode.ts';

describe('DEFAULT_FOUNDER_MODE', () => {
  test('has name Kalpavriksha', () => {
    assert.equal(DEFAULT_FOUNDER_MODE.assistant_display_name, 'Kalpavriksha');
  });

  test('has empty alias list', () => {
    assert.deepEqual([...DEFAULT_FOUNDER_MODE.assistant_aliases], []);
  });
});

describe('validateFounderMode — valid config', () => {
  test('valid config → valid: true, no issues', () => {
    const result = validateFounderMode({
      assistant_display_name: 'Kalpavriksha',
      assistant_aliases: ['Jarvis', 'Buddy'],
    });
    assert.equal(result.valid, true);
    assert.equal(result.issues.length, 0);
  });

  test('name at exactly MAX_NAME_LENGTH → valid', () => {
    const name = 'A'.repeat(MAX_NAME_LENGTH);
    const result = validateFounderMode({ assistant_display_name: name, assistant_aliases: [] });
    assert.equal(result.valid, true);
  });
});

describe('validateFounderMode — empty/whitespace name', () => {
  test('empty name → display-name-empty', () => {
    const result = validateFounderMode({ assistant_display_name: '', assistant_aliases: [] });
    assert.equal(result.valid, false);
    const issue = result.issues.find((i) => i.code === 'display-name-empty');
    assert.ok(issue, 'expected display-name-empty issue');
    assert.equal(issue.field, 'assistant_display_name');
    assert.equal(issue.index, null);
  });

  test('whitespace-only name → display-name-empty', () => {
    const result = validateFounderMode({ assistant_display_name: '   ', assistant_aliases: [] });
    assert.equal(result.valid, false);
    const issue = result.issues.find((i) => i.code === 'display-name-empty');
    assert.ok(issue, 'expected display-name-empty issue');
  });
});

describe('validateFounderMode — over-length name', () => {
  test('name at MAX_NAME_LENGTH + 1 → display-name-too-long', () => {
    const name = 'A'.repeat(MAX_NAME_LENGTH + 1);
    const result = validateFounderMode({ assistant_display_name: name, assistant_aliases: [] });
    assert.equal(result.valid, false);
    const issue = result.issues.find((i) => i.code === 'display-name-too-long');
    assert.ok(issue, 'expected display-name-too-long issue');
    assert.equal(issue.field, 'assistant_display_name');
    assert.equal(issue.index, null);
  });
});

describe('validateFounderMode — alias issues', () => {
  test('blank alias → alias-empty with correct index', () => {
    const result = validateFounderMode({
      assistant_display_name: 'Kalpa',
      assistant_aliases: ['Jarvis', '   ', 'Buddy'],
    });
    assert.equal(result.valid, false);
    const issue = result.issues.find((i) => i.code === 'alias-empty');
    assert.ok(issue, 'expected alias-empty issue');
    assert.equal(issue.index, 1);
  });

  test('over-length alias → alias-too-long with correct index', () => {
    const longAlias = 'B'.repeat(MAX_NAME_LENGTH + 1);
    const result = validateFounderMode({
      assistant_display_name: 'Kalpa',
      assistant_aliases: ['Jarvis', longAlias],
    });
    assert.equal(result.valid, false);
    const issue = result.issues.find((i) => i.code === 'alias-too-long');
    assert.ok(issue, 'expected alias-too-long issue');
    assert.equal(issue.index, 1);
    assert.equal(issue.field, 'assistant_aliases');
  });

  test('case-insensitive duplicate → alias-duplicate on SECOND occurrence only', () => {
    const result = validateFounderMode({
      assistant_display_name: 'Kalpa',
      assistant_aliases: ['Jarvis', 'jarvis'],
    });
    assert.equal(result.valid, false);
    const dupeIssues = result.issues.filter((i) => i.code === 'alias-duplicate');
    assert.equal(dupeIssues.length, 1);
    // Second occurrence is index 1.
    assert.equal(dupeIssues[0]?.index, 1);
  });

  test('case-insensitive duplicate: first occurrence has no issue', () => {
    const result = validateFounderMode({
      assistant_display_name: 'Kalpa',
      assistant_aliases: ['Jarvis', 'jarvis'],
    });
    // Index 0 (Jarvis) should not appear in issues.
    const idx0Issues = result.issues.filter((i) => i.index === 0);
    assert.equal(idx0Issues.length, 0);
  });
});

describe('validateFounderMode — multiple simultaneous issues', () => {
  test('all issues reported together', () => {
    const longAlias = 'C'.repeat(MAX_NAME_LENGTH + 1);
    const result = validateFounderMode({
      assistant_display_name: 'Kalpa',
      assistant_aliases: ['Jarvis', '   ', longAlias, 'jarvis'],
    });
    assert.equal(result.valid, false);
    const codes = result.issues.map((i) => i.code);
    assert.ok(codes.includes('alias-empty'), 'expected alias-empty');
    assert.ok(codes.includes('alias-too-long'), 'expected alias-too-long');
    assert.ok(codes.includes('alias-duplicate'), 'expected alias-duplicate');
  });
});

describe('readFounderMode — defensive parsing', () => {
  test('null → DEFAULT_FOUNDER_MODE', () => {
    const result = readFounderMode(null);
    assert.equal(result.assistant_display_name, DEFAULT_FOUNDER_MODE.assistant_display_name);
  });

  test('undefined → DEFAULT_FOUNDER_MODE', () => {
    const result = readFounderMode(undefined);
    assert.equal(result.assistant_display_name, DEFAULT_FOUNDER_MODE.assistant_display_name);
  });

  test('primitive string → DEFAULT_FOUNDER_MODE', () => {
    const result = readFounderMode('hello');
    assert.equal(result.assistant_display_name, DEFAULT_FOUNDER_MODE.assistant_display_name);
  });

  test('array → DEFAULT_FOUNDER_MODE', () => {
    const result = readFounderMode(['a', 'b']);
    assert.equal(result.assistant_display_name, DEFAULT_FOUNDER_MODE.assistant_display_name);
  });

  test('{} → DEFAULT_FOUNDER_MODE', () => {
    const result = readFounderMode({});
    assert.equal(result.assistant_display_name, DEFAULT_FOUNDER_MODE.assistant_display_name);
  });

  test('partial object with valid name fills in defaults', () => {
    const result = readFounderMode({ assistant_display_name: 'MyBot' });
    assert.equal(result.assistant_display_name, 'MyBot');
    assert.deepEqual([...result.assistant_aliases], []);
  });

  test('non-string aliases are filtered out', () => {
    const result = readFounderMode({
      assistant_display_name: 'MyBot',
      assistant_aliases: ['Jarvis', 42, null, true, 'Computer'],
    });
    assert.deepEqual([...result.assistant_aliases], ['Jarvis', 'Computer']);
  });

  test('blank aliases are filtered out', () => {
    const result = readFounderMode({
      assistant_display_name: 'MyBot',
      assistant_aliases: ['Jarvis', '   ', '', 'Computer'],
    });
    assert.deepEqual([...result.assistant_aliases], ['Jarvis', 'Computer']);
  });

  test('never throws on malformed input', () => {
    const inputs = [
      null, undefined, 0, '', [], {},
      { assistant_display_name: 123 },
      { assistant_aliases: 'not-an-array' },
      { assistant_display_name: null, assistant_aliases: null },
    ];
    for (const input of inputs) {
      assert.doesNotThrow(() => readFounderMode(input), `should not throw for: ${JSON.stringify(input)}`);
    }
  });
});

describe('writeFounderMode — round-trip', () => {
  test('round-trips through readFounderMode losslessly', () => {
    const config = { assistant_display_name: 'Kalpa', assistant_aliases: ['Jarvis', 'Computer'] };
    const written = writeFounderMode(config);
    const read = readFounderMode(written);
    assert.equal(read.assistant_display_name, config.assistant_display_name);
    assert.deepEqual([...read.assistant_aliases], config.assistant_aliases);
  });

  test('returned aliases array is a copy — mutating it does not affect source', () => {
    const config = { assistant_display_name: 'Kalpa', assistant_aliases: ['Jarvis'] };
    const written = writeFounderMode(config);
    const aliases = written['assistant_aliases'] as string[];
    aliases.push('INJECTED');
    // Re-read: INJECTED should not appear because writeFounderMode returns a copy.
    const read = readFounderMode(writeFounderMode(config));
    assert.ok(![...read.assistant_aliases].includes('INJECTED'), 'mutation of returned array affected source');
  });
});

describe('No matching functions exported — brief rule', () => {
  test('no exported key matches /match|detect|recognis|recognize|resolve|route|parse/i', () => {
    const MATCHING_RE = /match|detect|recognis|recognize|resolve|route|parse/i;
    for (const key of Object.keys(fm)) {
      assert.ok(
        !MATCHING_RE.test(key),
        `Exported key "${key}" matches the matching-function pattern — forbidden by brief`,
      );
    }
  });
});
