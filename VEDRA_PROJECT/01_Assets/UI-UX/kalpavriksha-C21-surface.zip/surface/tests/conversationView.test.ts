import { test, describe } from 'node:test';
import assert from 'node:assert/strict';

import {
  projectConversation,
  isEmptyConversation,
  EMPTY_CONVERSATION,
  ROLE_AUTHORS,
} from '../src/presentation/conversationView.ts';
import { entry } from './helpers.ts';

const ASSISTANT_NAME = 'Kalpavriksha';
const GREETING_RE = /good (morning|afternoon|evening)/i;

describe('projectConversation — role → author mapping', () => {
  test('assistant role maps to assistantName', () => {
    const e = entry({ role: 'assistant', text: 'Hello founder' });
    const [row] = projectConversation([e], ASSISTANT_NAME);
    assert.ok(row !== undefined);
    assert.equal(row.author, ASSISTANT_NAME);
    assert.equal(row.role, 'assistant');
  });

  test('user role maps to "You"', () => {
    const e = entry({ role: 'user', text: 'Start the deployment' });
    const [row] = projectConversation([e], ASSISTANT_NAME);
    assert.ok(row !== undefined);
    assert.equal(row.author, ROLE_AUTHORS.user);
    assert.equal(row.author, 'You');
  });

  test('system role maps to "System"', () => {
    const e = entry({ role: 'system', text: 'Connection restored' });
    const [row] = projectConversation([e], ASSISTANT_NAME);
    assert.ok(row !== undefined);
    assert.equal(row.author, ROLE_AUTHORS.system);
    assert.equal(row.author, 'System');
  });

  test('different assistant names are reflected', () => {
    const e = entry({ role: 'assistant', text: 'Roger' });
    const [row] = projectConversation([e], 'Roger');
    assert.ok(row !== undefined);
    assert.equal(row.author, 'Roger');
  });
});

describe('projectConversation — text is verbatim', () => {
  test('text is carried exactly including newlines', () => {
    const originalText = '  Line one\n\n  Line two  ';
    const e = entry({ text: originalText });
    const [row] = projectConversation([e], ASSISTANT_NAME);
    assert.ok(row !== undefined);
    assert.equal(row.text, originalText);
  });

  test('text with leading whitespace is not trimmed', () => {
    const originalText = '   indented text';
    const e = entry({ text: originalText });
    const [row] = projectConversation([e], ASSISTANT_NAME);
    assert.ok(row !== undefined);
    assert.equal(row.text, originalText);
  });

  test('text with trailing whitespace is not trimmed', () => {
    const originalText = 'trailing whitespace   ';
    const e = entry({ text: originalText });
    const [row] = projectConversation([e], ASSISTANT_NAME);
    assert.ok(row !== undefined);
    assert.equal(row.text, originalText);
  });

  test('empty text string is carried verbatim', () => {
    const e = entry({ text: '' });
    const [row] = projectConversation([e], ASSISTANT_NAME);
    assert.ok(row !== undefined);
    assert.equal(row.text, '');
  });
});

describe('projectConversation — streaming and superseded flags', () => {
  test('streaming: true when entry is streaming', () => {
    const e = entry({ streaming: true });
    const [row] = projectConversation([e], ASSISTANT_NAME);
    assert.ok(row !== undefined);
    assert.equal(row.streaming, true);
  });

  test('streaming: false when entry is not streaming', () => {
    const e = entry({ streaming: false });
    const [row] = projectConversation([e], ASSISTANT_NAME);
    assert.ok(row !== undefined);
    assert.equal(row.streaming, false);
  });

  test('superseded: true when supersededBy is non-null', () => {
    const e = entry({ supersededBy: 'entry-99' });
    const [row] = projectConversation([e], ASSISTANT_NAME);
    assert.ok(row !== undefined);
    assert.equal(row.superseded, true);
  });

  test('superseded: false when supersededBy is null', () => {
    const e = entry({ supersededBy: null });
    const [row] = projectConversation([e], ASSISTANT_NAME);
    assert.ok(row !== undefined);
    assert.equal(row.superseded, false);
  });

  test('superseded is ONLY true when supersededBy !== null', () => {
    const notSuperseded = entry({ supersededBy: null });
    const superseded = entry({ supersededBy: 'some-id' });
    const rows = projectConversation([notSuperseded, superseded], ASSISTANT_NAME);
    assert.equal(rows[0]?.superseded, false);
    assert.equal(rows[1]?.superseded, true);
  });
});

describe('projectConversation — empty input', () => {
  test('empty array → empty array', () => {
    const rows = projectConversation([], ASSISTANT_NAME);
    assert.equal(rows.length, 0);
  });

  test('isEmptyConversation: true for empty array', () => {
    assert.equal(isEmptyConversation([]), true);
  });

  test('isEmptyConversation: false for non-empty array', () => {
    const e = entry({});
    assert.equal(isEmptyConversation([e]), false);
  });
});

describe('projectConversation — never fabricates assistant entries', () => {
  test('user and system entries only → no row with role assistant', () => {
    const entries = [
      entry({ role: 'user', text: 'Hello' }),
      entry({ role: 'system', text: 'Session started' }),
      entry({ role: 'user', text: 'What is the status?' }),
    ];
    const rows = projectConversation(entries, ASSISTANT_NAME);
    for (const row of rows) {
      assert.notEqual(
        row.role,
        'assistant',
        `Expected no assistant row but found one: "${row.text}"`,
      );
    }
  });
});

describe('EMPTY_CONVERSATION — no greeting', () => {
  test('headline does not contain a greeting', () => {
    assert.ok(
      !GREETING_RE.test(EMPTY_CONVERSATION.headline),
      `headline contains greeting: "${EMPTY_CONVERSATION.headline}"`,
    );
  });

  test('body does not contain a greeting', () => {
    assert.ok(
      !GREETING_RE.test(EMPTY_CONVERSATION.body),
      `body contains greeting: "${EMPTY_CONVERSATION.body}"`,
    );
  });
});

describe('projectConversation — field mapping', () => {
  test('id and at are carried from entry', () => {
    const e = entry({ id: 'test-id-123', at: '2024-01-15T12:00:00.000Z' });
    const [row] = projectConversation([e], ASSISTANT_NAME);
    assert.ok(row !== undefined);
    assert.equal(row.id, 'test-id-123');
    assert.equal(row.at, '2024-01-15T12:00:00.000Z');
  });

  test('multiple entries maintain order', () => {
    const e1 = entry({ id: 'first', role: 'user', text: 'First message' });
    const e2 = entry({ id: 'second', role: 'assistant', text: 'Second message' });
    const e3 = entry({ id: 'third', role: 'system', text: 'Third message' });
    const rows = projectConversation([e1, e2, e3], ASSISTANT_NAME);
    assert.equal(rows.length, 3);
    assert.equal(rows[0]?.id, 'first');
    assert.equal(rows[1]?.id, 'second');
    assert.equal(rows[2]?.id, 'third');
  });
});
