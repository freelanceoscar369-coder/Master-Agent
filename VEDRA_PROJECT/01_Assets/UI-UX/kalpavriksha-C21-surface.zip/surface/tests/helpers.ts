/**
 * Test helpers for C21 surface tests.
 * Uses the REAL C20 createPresenceLayer() to build genuine snapshots.
 */

import { createPresenceLayer } from '../../presence/src/index.ts';
import type { PresenceSnapshot } from '../../presence/src/index.ts';
import type { ConversationEntry } from '../../desktop/src/types/execution.ts';

/* ─────────────────────────── timestamps ───────────────────────────────── */

/** Fixed base instant so tests are reproducible. */
const BASE_MS = Date.parse('2024-01-15T12:00:00.000Z');

/** ISO timestamp at BASE + seconds. */
export function at(seconds: number): string {
  return new Date(BASE_MS + seconds * 1000).toISOString();
}

/** The "now" used when taking snapshots — well past all observations. */
export const NOW = at(600);

/* ─────────────────────────── snapshot builder ──────────────────────────── */

export type SnapshotVariant =
  | 'empty'
  | 'calm'
  | 'with-pending-approvals'
  | 'with-held-mission'
  | 'with-running-mission'
  | 'coverage-incomplete'
  | 'with-failure'
  | 'with-reasoning'
  | 'stale-reasoning';

export function buildSnapshot(variant: SnapshotVariant): PresenceSnapshot {
  const layer = createPresenceLayer({
    thresholds: {
      reasoningStaleSeconds: 300,
      silenceSeconds: 9999, // prevent stale in most tests
      defaultFreshnessSeconds: 900,
    },
  });

  switch (variant) {
    case 'empty': {
      // No observations — entirely blank state.
      return layer.snapshot(NOW);
    }

    case 'calm': {
      // Two healthy covered domains, no approvals, no mission, execution idle.
      layer.observe({ type: 'coverage.expected', at: at(1), domains: ['kernel', 'scheduler'] });
      layer.observe({ type: 'coverage.reported', at: at(2), domain: 'kernel', healthy: true, freshnessSeconds: 900 });
      layer.observe({ type: 'coverage.reported', at: at(3), domain: 'scheduler', healthy: true, freshnessSeconds: 900 });
      return layer.snapshot(at(10));
    }

    case 'with-pending-approvals': {
      layer.observe({ type: 'coverage.expected', at: at(1), domains: ['kernel'] });
      layer.observe({ type: 'coverage.reported', at: at(2), domain: 'kernel', healthy: true, freshnessSeconds: 900 });
      layer.observe({
        type: 'approval.opened',
        at: at(5),
        approvalId: 'appr-001',
        executionId: 'exec-001',
        prompt: 'Confirm deployment to production',
        domain: 'kernel',
        expiresAt: null,
      });
      layer.observe({
        type: 'approval.opened',
        at: at(6),
        approvalId: 'appr-002',
        executionId: 'exec-001',
        prompt: 'Allow external API call',
        domain: 'kernel',
        expiresAt: null,
      });
      return layer.snapshot(at(60));
    }

    case 'with-held-mission': {
      layer.observe({ type: 'coverage.expected', at: at(1), domains: ['kernel'] });
      layer.observe({ type: 'coverage.reported', at: at(2), domain: 'kernel', healthy: true, freshnessSeconds: 900 });
      layer.observe({
        type: 'mission.observed',
        at: at(3),
        ref: 'mission-alpha',
        title: 'Deploy Alpha Release',
        phase: 'held',
        progress: 0.5,
        domain: 'kernel',
        startedAt: at(3),
      });
      return layer.snapshot(at(30));
    }

    case 'with-running-mission': {
      layer.observe({ type: 'coverage.expected', at: at(1), domains: ['kernel'] });
      layer.observe({ type: 'coverage.reported', at: at(2), domain: 'kernel', healthy: true, freshnessSeconds: 900 });
      layer.observe({
        type: 'mission.observed',
        at: at(3),
        ref: 'mission-beta',
        title: 'Process Data Pipeline',
        phase: 'running',
        progress: 0.3,
        domain: 'kernel',
        startedAt: at(3),
      });
      layer.observe({
        type: 'execution.observed',
        at: at(4),
        executionId: 'exec-002',
        phase: 'running',
        failureCode: null,
      });
      return layer.snapshot(at(30));
    }

    case 'coverage-incomplete': {
      // Expected domain but never reported.
      layer.observe({ type: 'coverage.expected', at: at(1), domains: ['kernel', 'missing-domain'] });
      layer.observe({ type: 'coverage.reported', at: at(2), domain: 'kernel', healthy: true, freshnessSeconds: 900 });
      // 'missing-domain' never reports.
      return layer.snapshot(at(10));
    }

    case 'with-failure': {
      layer.observe({ type: 'coverage.expected', at: at(1), domains: ['kernel'] });
      layer.observe({ type: 'coverage.reported', at: at(2), domain: 'kernel', healthy: true, freshnessSeconds: 900 });
      layer.observe({
        type: 'failure.raised',
        at: at(3),
        code: 'ERR_TIMEOUT',
        detail: 'Scheduler connection timed out',
        domain: 'kernel',
      });
      layer.observe({
        type: 'action.recorded',
        at: at(5),
        actor: 'kernel',
        description: 'Connection retry initiated',
        domain: 'kernel',
        succeeded: true,
      });
      return layer.snapshot(at(30));
    }

    case 'with-reasoning': {
      layer.observe({ type: 'coverage.expected', at: at(1), domains: ['kernel'] });
      layer.observe({ type: 'coverage.reported', at: at(2), domain: 'kernel', healthy: true, freshnessSeconds: 900 });
      layer.observe({
        type: 'reasoning.supplied',
        at: at(3),
        text: 'Evaluating options for the next deployment step',
      });
      return layer.snapshot(at(10));
    }

    case 'stale-reasoning': {
      // Reasoning supplied far in the past relative to reasoningStaleSeconds=300.
      const layer2 = createPresenceLayer({
        thresholds: { reasoningStaleSeconds: 60, silenceSeconds: 9999, defaultFreshnessSeconds: 900 },
      });
      layer2.observe({ type: 'coverage.expected', at: at(1), domains: ['kernel'] });
      layer2.observe({ type: 'coverage.reported', at: at(2), domain: 'kernel', healthy: true, freshnessSeconds: 900 });
      layer2.observe({
        type: 'reasoning.supplied',
        at: at(3),
        text: 'Old reasoning about something',
      });
      // Now is at(200) — 197 seconds after reasoning, > 60s threshold → stale.
      return layer2.snapshot(at(200));
    }
  }
}

/** All variants in one array for iteration. */
export const ALL_VARIANTS: SnapshotVariant[] = [
  'empty',
  'calm',
  'with-pending-approvals',
  'with-held-mission',
  'with-running-mission',
  'coverage-incomplete',
  'with-failure',
  'with-reasoning',
  'stale-reasoning',
];

/* ───────────────────────── ConversationEntry factory ───────────────────── */

let _entrySeq = 0;

export function entry(partial: Partial<ConversationEntry>): ConversationEntry {
  _entrySeq++;
  return {
    id: `entry-${_entrySeq}`,
    role: 'user',
    text: 'Hello',
    at: at(_entrySeq),
    executionId: null,
    streaming: false,
    supersededBy: null,
    missions: [],
    ...partial,
  };
}
