/**
 * The most important test file.
 *
 * Enforces the brief's "Never infer. Never synthesize. Never decorate runtime
 * values." Every user-visible string in a projected view must be either an
 * exact STATIC_LABELS value or traceable back to the snapshot.
 */

import { test, describe } from 'node:test';
import assert from 'node:assert/strict';

import {
  projectPresence,
  STATIC_LABELS,
} from '../src/presentation/presenceView.ts';
import type { PresenceView, ViewField } from '../src/presentation/presenceView.ts';
import type { PresenceSnapshot } from '../../presence/src/index.ts';
import { buildSnapshot, ALL_VARIANTS } from './helpers.ts';

const ASSISTANT_NAME = 'Kalpavriksha';

const FIELD_KEYS: ReadonlyArray<keyof PresenceView> = [
  'mission', 'execution', 'approvals', 'calm',
  'vigilance', 'activity', 'lastAction', 'reasoning',
];

const STATIC_LABEL_VALUES = new Set(Object.values(STATIC_LABELS));

/**
 * The spec says: after removing all STATIC_LABELS values, all digits, and the
 * separator characters `·s,: -`, the remainder is empty OR is a substring of
 * the JSON-serialised snapshot.
 *
 * The separator characters are: `·`, `,`, `:`, ` `, `-`, and `s` (the literal
 * seconds suffix). We remove them token-by-token after removing known static
 * labels first, then strip individual chars from the allowed set.
 *
 * We also accept any string that itself appears as a substring in the snapshot
 * JSON — this handles composite values assembled by C20's derive layer whose
 * full text appears verbatim in the snapshot.
 */
function assertTraceable(str: string, snapJson: string, context: string): void {
  // (a) — exact static label match.
  if (STATIC_LABEL_VALUES.has(str)) return;

  // (b) — the full string appears verbatim in the snapshot JSON.
  // This handles calm.statement, activity.line, lastAction.description, etc.
  // that are composed by C20 and stored as fields in the snapshot.
  if (snapJson.includes(str)) return;

  // (c) — strip mechanical composites:
  //   1. Remove the seconds suffix pattern `<digits>s` (e.g. "25s", "300s").
  //   2. Remove multi-char static labels (skip single-char 's' which is the
  //      seconds unit — handled in step 1 above, and stripping it globally
  //      would corrupt words like "release", "reasoning").
  //   3. Remove the separator punctuation · , : - (replace with space).
  //   4. Remove bare digits.
  //   5. Split on whitespace; each remaining fragment must appear in snapshot.

  let remainder = str;

  // Step 1: strip `<digits>s` — the mechanical seconds rendering.
  remainder = remainder.replace(/\d+s\b/g, '');

  // Step 2: remove multi-char static labels (not the single-char 's').
  for (const label of STATIC_LABEL_VALUES) {
    const l = label as string;
    if (l.length <= 1) continue; // skip 's' and '—'
    let prev = '';
    while (prev !== remainder) {
      prev = remainder;
      remainder = remainder.split(l).join('');
    }
  }

  // Step 3: replace separator punctuation with spaces.
  remainder = remainder
    .replace(/·/g, ' ')
    .replace(/,/g, ' ')
    .replace(/:/g, ' ')
    .replace(/-/g, ' ');

  // Step 4: remove remaining bare digits.
  remainder = remainder.replace(/\d+/g, '');

  if (remainder.trim().length === 0) return;

  // Step 5: each non-empty token must appear in the snapshot JSON.
  const fragments = remainder.split(/\s+/).filter((f) => f.length > 0);
  for (const frag of fragments) {
    assert.ok(
      snapJson.includes(frag),
      `Non-synthesis violation in ${context}: "${str}" — fragment "${frag}" not found in snapshot JSON`,
    );
  }
}

/**
 * Collects every user-visible string from a projected view:
 * both label and value of each field.
 */
function collectStrings(view: PresenceView): string[] {
  const strings: string[] = [];
  for (const key of FIELD_KEYS) {
    const field = view[key as keyof PresenceView] as ViewField;
    strings.push(field.label as string);
    strings.push(field.value);
  }
  return strings;
}

describe('Non-synthesis rule: every view string is a static label or traceable to the snapshot', () => {
  for (const variant of ALL_VARIANTS) {
    test(`variant: ${variant}`, () => {
      const snap = buildSnapshot(variant);
      const snapJson = JSON.stringify(snap);
      const view = projectPresence(snap, ASSISTANT_NAME);
      const strings = collectStrings(view);

      for (const str of strings) {
        assertTraceable(str, snapJson, `${variant}`);
      }
    });
  }
});

describe('Non-synthesis rule: no greeting', () => {
  const GREETING_RE = /good (morning|afternoon|evening)/i;

  for (const variant of ALL_VARIANTS) {
    test(`${variant}: no view string is a greeting`, () => {
      const snap = buildSnapshot(variant);
      const view = projectPresence(snap, ASSISTANT_NAME);
      for (const str of collectStrings(view)) {
        assert.ok(
          !GREETING_RE.test(str),
          `Greeting found in ${variant}: "${str}"`,
        );
      }
    });
  }
});

describe('Non-synthesis rule: no hedging or inference language', () => {
  const HEDGE_RE = /\b(probably|likely|seems|appears|might|should be|I think)\b/i;

  for (const variant of ALL_VARIANTS) {
    test(`${variant}: no view string hedges or infers`, () => {
      const snap = buildSnapshot(variant);
      const view = projectPresence(snap, ASSISTANT_NAME);
      for (const str of collectStrings(view)) {
        assert.ok(
          !HEDGE_RE.test(str),
          `Hedging language found in ${variant}: "${str}"`,
        );
      }
    });
  }
});

describe('Non-synthesis rule: no invented activity', () => {
  const ACTIVITY_RE = /thinking|working on it|please wait/i;

  for (const variant of ALL_VARIANTS) {
    test(`${variant}: no view string invents activity`, () => {
      const snap = buildSnapshot(variant);
      const view = projectPresence(snap, ASSISTANT_NAME);
      for (const str of collectStrings(view)) {
        assert.ok(
          !ACTIVITY_RE.test(str),
          `Invented activity found in ${variant}: "${str}"`,
        );
      }
    });
  }
});
