# HEALTH — C21 · Founder Conversation Surface (Alpha)

**Status:** complete, awaiting Hermes/Claude audit. Not continuing to C22.

| Check | Result |
|---|---|
| `npm test` | **127 pass / 0 fail**, 30 suites, run twice |
| `node tests/boundary-guard.mjs` | **BOUNDED** — 12 modules, 30 imports, 0 findings |
| Frozen directories modified | **none** |
| Runtime dependencies | **zero** (React is a peer, nothing else) |

The boundary guard was re-run after the `.tsx` components landed, so its result
covers the whole tree rather than only the modules that existed when it was
first written.

---

## 1 · Grounding gaps — recorded, as instructed

The brief says: *"Ground ONLY on: Kernel Specification, ADR-0022, ADR-0023,
VEDA, Roadmap, C1–C20, Approved UI Prototype. No assumptions. If grounding is
missing, record it."*

**Of the eight grounding sources, I had two:**

| Source | Available | Consequence |
|---|---|---|
| Approved UI Prototype | ✅ | Design language reused directly, not redesigned |
| C19A, C20 | ✅ (built in this thread) | Consumed as-is; not duplicated |
| Kernel Specification | ❌ not provided | Kernel vocabulary reached only through C19A/C20 types |
| ADR-0022 | ❌ not provided | May already define the presence contract this surface reads |
| ADR-0023 | ❌ not provided | May own staleness/threshold policy |
| VEDA | ❌ not provided | No VEDA concept is referenced anywhere in C21 |
| Roadmap | ❌ not provided | Scope taken strictly from this brief |
| kalpavriksha-s1-c18.0 | ❌ not inspected | Treated as frozen; nothing here references it |
| C1–C18 | ❌ not provided | — |

**How I avoided assuming.** C21 introduces **no new domain vocabulary at all.**
Every runtime concept it displays is imported from `presence/` (C20) or
`desktop/src/types/execution.ts` (C19A). The only new types in this package are
view models (`PresenceView`, `ConversationRow`) and configuration
(`FounderModeConfig`) — none of which name anything in the Kernel.

That is the direct answer to "No duplicate Kernel vocabulary": there is none to
duplicate here, because this layer defines none.

---

## 2 · One brief-internal tension, resolved conservatively

The brief says **"First Screen: No metrics. No cards. No dashboard grid. No KPI
wall."** and also asks for a **Mission Strip** displaying five runtime values
including approval counts.

Those pull against each other. I resolved it as follows and am flagging it
rather than deciding silently:

- The Mission Strip is **one horizontal line of `label: value` pairs**,
  hairline-separated, horizontally scrollable on narrow widths.
- It is **not** cards, tiles, or a grid. There is a comment in
  `MissionStrip.tsx` stating that tile rendering is forbidden there.
- Values are words wherever the snapshot gives words; digits appear only where
  the brief explicitly names a count (approvals waiting).

If the audit reads "no metrics" as excluding the approvals count, deleting that
one field is a one-line change.

---

## 3 · What was built

| File | Lines | Role |
|---|---|---|
| `src/presentation/presenceView.ts` | 268 | Strict projection of a C20 snapshot. The non-synthesis rule lives here. |
| `src/presentation/conversationView.ts` | 78 | Entry → row projection. Verbatim text. |
| `src/config/founderMode.ts` | 178 | Configuration + validation only. |
| `src/config/founderActions.ts` | 33 | Four placeholders as data. |
| `src/components/*.tsx` (7) | 771 | Header · Strip · Conversation · Composer · Actions · Settings · Root |
| `src/styles/surface.css` | 641 | Tokens and classes. Reused prototype language. |
| `src/index.ts` | 78 | Barrel |
| `tests/` (6 + guard) | 1,237 | 127 assertions |

Layout, top to bottom: **PresenceHeader · MissionStrip · ConversationArea
(the only scrolling region) · FounderActions · Composer.**

---

## 4 · The hardest constraint, and how it is enforced

> *"Never infer. Never synthesize. Never decorate runtime values."*

This is enforced structurally, then tested.

**Structurally:** every user-visible string produced by `presenceView.ts` is
either (a) carried verbatim out of the snapshot, possibly with mechanical
number formatting, or (b) drawn from a frozen `STATIC_LABELS` allowlist of 19
field labels and absence markers. Each `ViewField` records which, in a `source`
field. There is no third category.

**Tested:** `tests/noSynthesis.test.ts` walks every string in a projected view
across nine snapshot variants and asserts each is traceable to (a) or (b).
Adding an unlisted phrase fails the suite. It additionally asserts that no view
string matches:

- `/good (morning|afternoon|evening)/i` — **the surface never greets**
- `/probably|likely|seems|appears|might|should be|I think/i` — never hedges
- `/thinking|working on it|please wait/i` — never invents activity

### The consequence I want the audit to see clearly

**"Kalpavriksha is already here" is produced by real state, not by a greeting.**

The obvious way to make an app feel alive on open is a warm synthesized line —
*"Good evening, Onkar."* That is precisely what this brief forbids, and it
would be the first thing the founder ever reads, which makes it the worst
possible place for a fabricated sentence.

So the opening screen is: the assistant's configured name, C20's own activity
line carried verbatim, and the mission strip. When no snapshot has arrived yet,
every field reads **`no signal`** — the surface does not pretend presence
exists before it does.

Whether that clears the emotional bar the brief sets is a judgement I cannot
make alone, and it is the second thing I would put to the audit. **The honest
version is quieter than the synthesized version.** I chose honest.

---

## 5 · Constraint compliance

| Forbidden | Status | Evidence |
|---|---|---|
| Mission OS | ✅ absent | No orchestration concept anywhere |
| Autonomous planning | ✅ absent | No planner, no goal, no scheduler |
| Orchestration | ✅ absent | Surface holds no execution reference |
| Plugin execution | ✅ absent | No plugin surface exists |
| Voice | ✅ absent | No audio API referenced |
| Electron integration | ✅ absent | Guard fails on `electron`/`ipcRenderer`/`webContents` |
| Model routing | ✅ absent | No model concept |
| API calls | ✅ absent | Guard fails on `fetch(`, `http(s)://`, `WebSocket`, `EventSource` |
| Runtime mutation | ✅ absent | Surface receives props; the composer calls `onSend` and appends nothing itself |
| Business logic | ✅ absent | Projection + validation only |
| Duplicate Presence logic | ✅ absent | Imports C20; decides no calm, evaluates no coverage, ranks no mission |
| Duplicate Vigilance logic | ✅ absent | Reads `snapshot.vigilance` as fact |
| Duplicate Kernel vocabulary | ✅ absent | Defines no domain type; imports all of them |
| AI generation / mock reasoning | ✅ absent | See §4 |
| Command palette / toolbar | ✅ absent | One textarea, one send affordance |
| Founder actions connected | ✅ inert | Zero `onClick` attributes in `FounderActions.tsx`; buttons `disabled` + `aria-disabled` with `title={reason}` |
| Alias matching | ✅ absent | `founderMode.ts` exports nothing matching `/match|detect|recognis|resolve|route|parse/i` — asserted by test |

A note on the last two: both are enforced by **named tests**, not by
inspection. `founderActions.test.ts` asserts no action object holds a
function-valued property; `founderMode.test.ts` asserts the module's export
surface contains no matching capability.

---

## 6 · Test coverage

127 assertions, 30 suites, deterministic — no real clock, no network, no timers.

Tests build **real C20 snapshots** via `createPresenceLayer()` rather than
hand-faked objects, so the projection is verified against genuine layer output.

| File | Covers |
|---|---|
| `presenceView.test.ts` | Totality across 9 snapshot variants; all labels from the allowlist; verbatim carriage of mission title, calm statement, activity line, reasoning text, last-action description; every null path; `absentPresence`; `stripFields` order; projection purity and snapshot non-mutation |
| `noSynthesis.test.ts` | The traceability walk plus the three forbidden-language assertions |
| `conversationView.test.ts` | Role→author mapping; **verbatim text including newlines and whitespace** (strict equality, untrimmed); streaming/superseded flags; never fabricates an assistant row; empty state carries no greeting |
| `founderMode.test.ts` | All five validation codes; boundary at exactly `MAX_NAME_LENGTH` and +1; case-insensitive duplicates flagged on the second index only; `readFounderMode` against null/undefined/primitive/array/`{}`/partial/dirty aliases without throwing; lossless round-trip; returned array is a copy; **no matching capability exported** |
| `founderActions.test.ts` | Exactly four, correct keys and order, non-empty labels and reasons, **no function-valued properties** |

**Run:**
```
cd surface
npm test        # 127 pass
npm run verify  # boundary guard + tests
```

> Invocation trap: `node --test tests/` fails — Node resolves `tests` as a
> module specifier. Use `node --test 'tests/**/*.test.ts'`, which is what
> `npm test` runs.

---

## 7 · Known issues and residual risk

**High**
1. **Six of eight grounding sources unavailable** (§1). If ADR-0022 defines a
   presence contract, both C20 and this surface's reading of it need review.
2. **Components are untested.** React cannot be installed here, so the seven
   `.tsx` files have never been rendered, mounted or type-checked. All logic
   they depend on is tested; the JSX itself is unverified. Everything in
   `src/presentation` and `src/config` is covered.
3. **No `tsc` run.** Node's type-stripping executes `.ts` but does not
   type-check, and does not touch `.tsx` at all. 127 passing tests prove
   behaviour, not type correctness.

**Medium**
4. **Package location assumed.** No path was given. I created a sibling package
   `surface/` and touched no frozen directory. It imports `presence/` and
   `desktop/src/types` by relative path — if the repository uses workspace
   aliases, those two import lines change.
5. **The emotional bar is unverified** (§4). The honest opening is quieter than
   a synthesized one. That is a product judgement for the audit.
6. **`ConversationArea` auto-scroll is unproven** — the 64px "reading" guard is
   reasonable but has never run in a browser.

**Low / by design**
7. Nothing renders yet in an app. The surface is a component library until
   something mounts it — which is the intent of an Alpha.
8. `assistant_aliases` is stored and validated but read by nothing, exactly as
   briefed.
9. Founder action buttons are permanently disabled and say why.

---

## 8 · Position in the stack

```
   FOUNDER CONVERSATION SURFACE   ← C21 ✅ view only, zero domain logic
        │                    ▲
        │ onSend(text)       │ PresenceSnapshot · ConversationEntry[]
        ▼                    │
   C19A adapters        PRESENCE LAYER (C20)     ← both frozen w.r.t. this work
        │                    ▲
        ▼                    │
   Runtime Bridge ─── Coordinator ─── Kernel     ← untouched, unreachable from here
```

C21 renders downward-flowing state and emits one upward call (`onSend`), which
it does not implement. It cannot reach the runtime, and it defines nothing the
runtime owns.

---

**Stopping here as instructed. Not proceeding to C22. Awaiting Hermes/Claude audit.**
