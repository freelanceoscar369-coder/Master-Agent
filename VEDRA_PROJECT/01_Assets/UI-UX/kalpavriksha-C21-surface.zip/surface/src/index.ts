/**
 * C21 · Barrel export.
 *
 * Re-exports every component and the public API of the presentation and
 * config modules. Import from '@kalpavriksha/conversation-surface' to get
 * everything.
 */

// ── Components ───────────────────────────────────────────────────────────────

export { PresenceHeader } from './components/PresenceHeader.tsx';
export type { PresenceHeaderProps } from './components/PresenceHeader.tsx';

export { MissionStrip } from './components/MissionStrip.tsx';
export type { MissionStripProps } from './components/MissionStrip.tsx';

export { ConversationArea } from './components/ConversationArea.tsx';
export type { ConversationAreaProps } from './components/ConversationArea.tsx';

export { Composer } from './components/Composer.tsx';
export type { ComposerProps } from './components/Composer.tsx';

export { FounderActions } from './components/FounderActions.tsx';

export { FounderModeSettings } from './components/FounderModeSettings.tsx';
export type { FounderModeSettingsProps } from './components/FounderModeSettings.tsx';

export { ConversationSurface } from './components/ConversationSurface.tsx';
export type { ConversationSurfaceProps } from './components/ConversationSurface.tsx';

// ── Presentation — presenceView ───────────────────────────────────────────

export {
  projectPresence,
  absentPresence,
  stripFields,
  STATIC_LABELS,
} from './presentation/presenceView.ts';
export type {
  PresenceView,
  ViewField,
  StaticLabel,
} from './presentation/presenceView.ts';

// ── Presentation — conversationView ──────────────────────────────────────

export {
  projectConversation,
  isEmptyConversation,
  EMPTY_CONVERSATION,
  ROLE_AUTHORS,
} from './presentation/conversationView.ts';
export type { ConversationRow } from './presentation/conversationView.ts';

// ── Config — founderMode ──────────────────────────────────────────────────

export {
  DEFAULT_FOUNDER_MODE,
  EXAMPLE_ALIASES,
  MAX_NAME_LENGTH,
  validateFounderMode,
  readFounderMode,
  writeFounderMode,
} from './config/founderMode.ts';
export type {
  FounderModeConfig,
  FounderModeIssue,
  FounderModeIssueCode,
  FounderModeValidation,
} from './config/founderMode.ts';

// ── Config — founderActions ───────────────────────────────────────────────

export {
  FOUNDER_ACTIONS,
  ALL_ACTIONS_INERT,
} from './config/founderActions.ts';
export type { FounderActionDef } from './config/founderActions.ts';
