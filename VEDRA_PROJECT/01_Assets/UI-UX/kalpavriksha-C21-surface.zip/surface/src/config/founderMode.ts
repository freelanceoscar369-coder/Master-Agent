/**
 * C21 · Founder Mode — configuration only.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * SCOPE, EXACTLY AS BRIEFED
 *
 * The brief asks for two configuration fields and is explicit that
 * "Conversation matching is NOT implemented. Only configuration."
 *
 * So this module declares, validates and stores the configuration. It does
 * NOT match aliases against conversation text, does not route on them, does
 * not tokenise, and exposes no matching function of any kind. There is
 * deliberately nothing in this file that could be called to answer "did the
 * founder address the assistant?" — because answering that is C22's or later.
 *
 * Validation is present because a configuration surface that accepts an empty
 * display name produces a UI with no name in it, which is a defect the audit
 * would rightly find. Validation is not matching.
 * ═══════════════════════════════════════════════════════════════════════════
 */

/* ─────────────────────────── the shape ────────────────────────────────── */

export interface FounderModeConfig {
  /** Rendered wherever the assistant is named. Never inferred. */
  readonly assistant_display_name: string;
  /**
   * Additional names the founder may use for the assistant.
   *
   * STORED ONLY. Nothing in C21 reads this array to make a decision. It exists
   * so the configuration is captured now and whatever implements matching
   * later has a settled contract to read.
   */
  readonly assistant_aliases: readonly string[];
}

export const DEFAULT_FOUNDER_MODE: FounderModeConfig = {
  assistant_display_name: 'Kalpavriksha',
  assistant_aliases: [],
};

/**
 * Examples from the brief. Offered as suggestions in a configuration surface.
 * NOT defaults, and not a matching table.
 */
export const EXAMPLE_ALIASES = ['Kalpavriksha', 'Jarvis', 'Buddy', 'Computer'] as const;

/* ─────────────────────────── validation ───────────────────────────────── */

export type FounderModeIssueCode =
  | 'display-name-empty'
  | 'display-name-too-long'
  | 'alias-empty'
  | 'alias-too-long'
  | 'alias-duplicate';

export interface FounderModeIssue {
  readonly code: FounderModeIssueCode;
  readonly field: 'assistant_display_name' | 'assistant_aliases';
  /** Index into assistant_aliases when the issue concerns one alias. */
  readonly index: number | null;
  /** A sentence a founder can act on. */
  readonly message: string;
}

export const MAX_NAME_LENGTH = 64;

export interface FounderModeValidation {
  readonly valid: boolean;
  readonly issues: readonly FounderModeIssue[];
}

/**
 * Checks a configuration for structural problems.
 *
 * Pure. Does not normalise, does not mutate, does not persist, and — to be
 * explicit — does not compare either field against any conversation text.
 */
export function validateFounderMode(config: FounderModeConfig): FounderModeValidation {
  const issues: FounderModeIssue[] = [];
  const name = config.assistant_display_name;

  if (name.trim().length === 0) {
    issues.push({
      code: 'display-name-empty',
      field: 'assistant_display_name',
      index: null,
      message: 'The assistant needs a display name.',
    });
  } else if (name.length > MAX_NAME_LENGTH) {
    issues.push({
      code: 'display-name-too-long',
      field: 'assistant_display_name',
      index: null,
      message: `The display name must be ${MAX_NAME_LENGTH} characters or fewer.`,
    });
  }

  const seen = new Set<string>();
  config.assistant_aliases.forEach((alias, index) => {
    if (alias.trim().length === 0) {
      issues.push({
        code: 'alias-empty',
        field: 'assistant_aliases',
        index,
        message: 'An alias cannot be blank.',
      });
      return;
    }
    if (alias.length > MAX_NAME_LENGTH) {
      issues.push({
        code: 'alias-too-long',
        field: 'assistant_aliases',
        index,
        message: `"${alias}" is longer than ${MAX_NAME_LENGTH} characters.`,
      });
    }
    // Case-insensitive duplicate detection. This is a uniqueness check on the
    // configuration list itself — it never touches conversation content.
    const key = alias.trim().toLowerCase();
    if (seen.has(key)) {
      issues.push({
        code: 'alias-duplicate',
        field: 'assistant_aliases',
        index,
        message: `"${alias}" is already in the list.`,
      });
    }
    seen.add(key);
  });

  return { valid: issues.length === 0, issues };
}

/* ─────────────────────────── serialisation ────────────────────────────── */

/**
 * Reads a configuration from an unknown value, falling back field-by-field.
 *
 * Never throws: a corrupt stored configuration must not prevent the surface
 * from opening. Unreadable fields fall back to the default and the caller can
 * see what was recovered.
 */
export function readFounderMode(value: unknown): FounderModeConfig {
  if (typeof value !== 'object' || value === null) return DEFAULT_FOUNDER_MODE;
  const o = value as Record<string, unknown>;

  const name =
    typeof o['assistant_display_name'] === 'string' && o['assistant_display_name'].trim().length > 0
      ? o['assistant_display_name']
      : DEFAULT_FOUNDER_MODE.assistant_display_name;

  const rawAliases = o['assistant_aliases'];
  const aliases = Array.isArray(rawAliases)
    ? rawAliases.filter((a): a is string => typeof a === 'string' && a.trim().length > 0)
    : [];

  return { assistant_display_name: name, assistant_aliases: aliases };
}

/** Plain JSON, stable key order. */
export function writeFounderMode(config: FounderModeConfig): Record<string, unknown> {
  return {
    assistant_display_name: config.assistant_display_name,
    assistant_aliases: [...config.assistant_aliases],
  };
}
