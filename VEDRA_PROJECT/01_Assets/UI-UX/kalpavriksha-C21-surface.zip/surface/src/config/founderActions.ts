/**
 * C21 · Founder actions — placeholders.
 *
 * The brief lists four buttons and says: "Only placeholders. No
 * implementation. Do not connect."
 *
 * So this module declares them as data. There is no handler, no dispatch, no
 * navigation and no reference to anything that could perform them. Rendering
 * code reads this list and renders disabled controls carrying `reason`.
 *
 * Making them data rather than inline JSX means the audit can see the whole
 * set in one place and confirm nothing is wired.
 */

export interface FounderActionDef {
  readonly key: 'start-mission' | 'review-approvals' | 'show-activity' | 'open-settings';
  readonly label: string;
  /** Shown to the founder so a dead control is honest rather than broken. */
  readonly reason: string;
}

export const FOUNDER_ACTIONS: readonly FounderActionDef[] = Object.freeze([
  { key: 'start-mission',    label: 'Start Mission',    reason: 'Not connected in C21.' },
  { key: 'review-approvals', label: 'Review Approvals', reason: 'Not connected in C21.' },
  { key: 'show-activity',    label: 'Show Activity',    reason: 'Not connected in C21.' },
  { key: 'open-settings',    label: 'Open Settings',    reason: 'Not connected in C21.' },
]);

/** Every action is inert in C21. Asserted by the test suite. */
export const ALL_ACTIONS_INERT = true;
