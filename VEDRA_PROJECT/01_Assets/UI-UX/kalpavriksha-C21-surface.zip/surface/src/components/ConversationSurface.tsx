/**
 * C21 · ConversationSurface
 *
 * Composition root. Brief constraints satisfied:
 * - Uses projectPresence(snapshot, name) when snapshot is non-null,
 *   absentPresence(name) otherwise.
 * - Uses projectConversation(entries, name).
 * - Layout: PresenceHeader · MissionStrip · ConversationArea (flex-grow) ·
 *   FounderActions · Composer. Full viewport height; conversation scrolls.
 * - Composer text in local state. onSubmit calls onSend?.(text) then clears.
 * - Does NOT append an entry itself — entries arrive from outside only. The
 *   surface is a pure view; it owns no conversation state.
 * - showSettings: renders FounderModeSettings in place of the conversation
 *   area. Not a modal — modals are forbidden by the brief.
 * - No API calls, no fetch, no timers, no Electron, no routing library.
 */

// IMPORTANT: This component does NOT append entries to the conversation list.
// Entries come exclusively from the `entries` prop (the runtime, via the
// parent). Calling onSend dispatches to the runtime; the runtime produces a
// new entry that will arrive via the next render of `entries`. Any
// self-appending logic here would create a duplicate and violate the
// no-synthesis rule.

import { useState, useCallback, type ReactElement } from 'react';
import type { PresenceSnapshot } from '../../../presence/src/index.ts';
import type { ConversationEntry } from '../../../desktop/src/types/execution.ts';
import type { FounderModeConfig } from '../config/founderMode.ts';
import { DEFAULT_FOUNDER_MODE } from '../config/founderMode.ts';
import {
  projectPresence,
  absentPresence,
} from '../presentation/presenceView.ts';
import { projectConversation } from '../presentation/conversationView.ts';

import { PresenceHeader } from './PresenceHeader.tsx';
import { MissionStrip } from './MissionStrip.tsx';
import { ConversationArea } from './ConversationArea.tsx';
import { FounderActions } from './FounderActions.tsx';
import { Composer } from './Composer.tsx';
import { FounderModeSettings } from './FounderModeSettings.tsx';

export interface ConversationSurfaceProps {
  readonly snapshot: PresenceSnapshot | null;
  readonly entries: readonly ConversationEntry[];
  readonly founderMode?: FounderModeConfig;
  readonly onSend?: (text: string) => void;
  readonly showSettings?: boolean;
  readonly onFounderModeChange?: (c: FounderModeConfig) => void;
}

export function ConversationSurface({
  snapshot,
  entries,
  founderMode,
  onSend,
  showSettings = false,
  onFounderModeChange,
}: ConversationSurfaceProps): ReactElement {
  // Resolve the effective configuration, defaulting gracefully.
  const config = founderMode ?? DEFAULT_FOUNDER_MODE;
  const name = config.assistant_display_name;

  // Project the presence view from the snapshot (or absent state).
  const presenceView =
    snapshot !== null
      ? projectPresence(snapshot, name)
      : absentPresence(name);

  // Project the conversation rows from entries. Never synthesized here.
  const rows = projectConversation(entries, name);

  // Composer text state — the surface owns the draft only, not the sent entries.
  const [composerText, setComposerText] = useState('');

  const handleSubmit = useCallback(() => {
    const trimmed = composerText.trim();
    if (trimmed.length === 0) return;
    // Dispatch to the caller. The surface does NOT append an entry itself.
    onSend?.(trimmed);
    setComposerText('');
  }, [composerText, onSend]);

  return (
    <div className="kv-surface kv-layout">
      {/* Top: presence status and name */}
      <PresenceHeader view={presenceView} />

      {/* Below header: mission strip */}
      <MissionStrip view={presenceView} />

      {/* Main scrolling region — conversation or settings (no modal) */}
      {showSettings ? (
        <div className="kv-layout__conversation">
          <FounderModeSettings
            config={config}
            onChange={onFounderModeChange ?? (() => undefined)}
          />
        </div>
      ) : (
        <ConversationArea rows={rows} />
      )}

      {/* Inert action row */}
      <FounderActions />

      {/* Composer — the only interactive input region */}
      <Composer
        value={composerText}
        onChange={setComposerText}
        onSubmit={handleSubmit}
        disabled={onSend === undefined}
        placeholder={onSend === undefined ? 'Not connected.' : undefined}
      />
    </div>
  );
}
