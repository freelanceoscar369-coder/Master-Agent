/**
 * C21 · Composer
 *
 * Brief constraints satisfied:
 * - One auto-growing textarea (max ~6 rows), one hairline border, one send
 *   affordance in mono. No toolbar, no attachments, no slash commands.
 * - Enter submits; Shift+Enter inserts newline.
 * - Submitting empty/whitespace does nothing.
 * - Properly labelled for screen readers.
 * - No API calls, no timers, no routing.
 */

import { type ReactElement, useCallback, useEffect, useRef } from 'react';

export interface ComposerProps {
  readonly value: string;
  readonly onChange: (v: string) => void;
  readonly onSubmit: () => void;
  readonly disabled?: boolean;
  readonly placeholder?: string;
}

/** The row height in pixels matching the 24px prose line-height. */
const LINE_HEIGHT_PX = 24;
/** Padding top + bottom on the textarea (6px each side = 12px total). */
const VERTICAL_PADDING_PX = 12;
/** Maximum rows before the textarea scrolls internally. */
const MAX_ROWS = 6;
const MAX_HEIGHT_PX = MAX_ROWS * LINE_HEIGHT_PX + VERTICAL_PADDING_PX;

export function Composer({
  value,
  onChange,
  onSubmit,
  disabled = false,
  placeholder,
}: ComposerProps): ReactElement {
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-grow the textarea to fit content, capped at MAX_HEIGHT_PX.
  useEffect(() => {
    const el = textareaRef.current;
    if (el === null) return;
    // Reset height so scrollHeight measures the content without the previous
    // constrained height interfering.
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, MAX_HEIGHT_PX)}px`;
  }, [value]);

  const handleChange = useCallback(
    (e: React.ChangeEvent<HTMLTextAreaElement>) => {
      onChange(e.target.value);
    },
    [onChange],
  );

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        // Enter alone submits; Shift+Enter produces a newline (default).
        e.preventDefault();
        if (value.trim().length > 0) {
          onSubmit();
        }
      }
    },
    [value, onSubmit],
  );

  const handleSendClick = useCallback(() => {
    if (value.trim().length > 0) {
      onSubmit();
    }
  }, [value, onSubmit]);

  const canSend = !disabled && value.trim().length > 0;

  return (
    <div className="kv-composer" role="form" aria-label="Message composer">
      {/* Visually hidden label for screen readers */}
      <label
        htmlFor="kv-composer-textarea"
        className="kv-composer__label"
      >
        Message
      </label>

      <textarea
        id="kv-composer-textarea"
        ref={textareaRef}
        className="kv-composer__textarea"
        value={value}
        onChange={handleChange}
        onKeyDown={handleKeyDown}
        disabled={disabled}
        placeholder={placeholder}
        rows={1}
        aria-multiline="true"
        aria-label="Type a message"
        aria-disabled={disabled}
      />

      <button
        type="button"
        className="kv-composer__send"
        onClick={handleSendClick}
        disabled={!canSend}
        aria-label="Send message"
        aria-disabled={!canSend}
      >
        send
      </button>
    </div>
  );
}
