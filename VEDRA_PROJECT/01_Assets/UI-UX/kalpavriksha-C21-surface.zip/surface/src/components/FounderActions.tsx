/**
 * C21 · FounderActions
 *
 * Brief constraints satisfied:
 * - Renders FOUNDER_ACTIONS as four disabled mono buttons in one row.
 * - Every button: disabled, aria-disabled="true", title={reason}.
 * - NO onClick prop anywhere in this file — connecting these is explicitly
 *   out of scope for C21. This is enforced by the test suite (ALL_ACTIONS_INERT).
 * - Buttons rendered from data, not hard-coded JSX, so the audit sees the
 *   full set in FOUNDER_ACTIONS and confirms nothing is wired.
 */

// IMPORTANT: Connecting these actions is explicitly out of scope for C21.
// Do NOT add onClick handlers to any button in this file. The FOUNDER_ACTIONS
// list in src/config/founderActions.ts is data only; these controls are
// intentionally inert. Any wiring belongs to a future cycle, not C21.

import { type ReactElement } from 'react';
import { FOUNDER_ACTIONS } from '../config/founderActions.ts';

export function FounderActions(): ReactElement {
  return (
    <div
      className="kv-actions"
      role="toolbar"
      aria-label="Founder actions (not connected)"
    >
      {FOUNDER_ACTIONS.map((action) => (
        <button
          key={action.key}
          type="button"
          className="kv-actions__btn"
          disabled
          aria-disabled="true"
          title={action.reason}
          // No onClick — connecting these is out of scope for C21.
        >
          {action.label}
        </button>
      ))}
    </div>
  );
}
