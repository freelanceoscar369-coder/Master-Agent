/**
 * C21 · ConversationArea
 *
 * Brief constraints satisfied:
 * - Renders entry text verbatim with white-space: pre-wrap. Never rewrites,
 *   summarises, or interprets content.
 * - Empty state uses EMPTY_CONVERSATION.headline and .body verbatim — no
 *   other text and no greeting of any kind.
 * - streaming rows get a 2px live-coloured cursor block via CSS only.
 * - superseded rows render at reduced opacity with the word "superseded".
 * - Auto-scroll to newest row, suspended when the user has scrolled up
 *   more than 64px from the bottom (tracked via a ref).
 * - New row animation: 240ms opacity fade only (no transform, no slide).
 */

import { type ReactElement, useEffect, useRef } from 'react';
import type { ConversationRow } from '../presentation/conversationView.ts';
import { EMPTY_CONVERSATION } from '../presentation/conversationView.ts';

export interface ConversationAreaProps {
  readonly rows: readonly ConversationRow[];
}

/** Threshold in pixels: farther than this from the bottom = "reading" mode. */
const READING_THRESHOLD = 64;

export function ConversationArea({ rows }: ConversationAreaProps): ReactElement {
  const scrollRef = useRef<HTMLDivElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  /** True when the user has scrolled up and is reading. */
  const isReadingRef = useRef(false);

  // Track whether the user is in "reading" mode by monitoring scroll position.
  useEffect(() => {
    const el = scrollRef.current;
    if (el === null) return;

    function handleScroll(): void {
      if (el === null) return;
      const distanceFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
      isReadingRef.current = distanceFromBottom > READING_THRESHOLD;
    }

    el.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      el.removeEventListener('scroll', handleScroll);
    };
  }, []);

  // Scroll to the bottom when a new row arrives, unless the user is reading.
  useEffect(() => {
    if (isReadingRef.current) return;
    bottomRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [rows.length]);

  return (
    <div
      ref={scrollRef}
      className="kv-layout__conversation"
      role="log"
      aria-live="polite"
      aria-label="Conversation"
    >
      <div className="kv-conversation">
        {rows.length === 0 ? (
          // Empty state: EMPTY_CONVERSATION verbatim — no other words, no greeting
          <div className="kv-conversation__empty" role="status">
            <p className="kv-conversation__empty-headline">
              {EMPTY_CONVERSATION.headline}
            </p>
            <p className="kv-conversation__empty-body">
              {EMPTY_CONVERSATION.body}
            </p>
          </div>
        ) : (
          rows.map((row) => <ConversationRow key={row.id} row={row} />)
        )}
        {/* Sentinel element for auto-scroll targeting */}
        <div ref={bottomRef} aria-hidden="true" />
      </div>
    </div>
  );
}

/* ──────────────────────────────────────────────────────────────────────────
   Single conversation row — extracted to keep the map callback clean.
   ────────────────────────────────────────────────────────────────────────── */

interface RowProps {
  readonly row: ConversationRow;
}

function ConversationRow({ row }: RowProps): ReactElement {
  // Build the class list from role and state flags. Classes are defined in
  // surface.css; no inline styles needed for role or state treatment.
  const classes = [
    'kv-row',
    `kv-row--${row.role}`,
    row.streaming  ? 'kv-row--streaming'   : '',
    row.superseded ? 'kv-row--superseded'  : '',
  ]
    .filter(Boolean)
    .join(' ');

  return (
    <article
      className={classes}
      aria-label={`${row.author} at ${row.at}`}
    >
      {/* Meta line: author + timestamp, one line */}
      <div className="kv-row__meta">
        <span className="kv-row__author">{row.author}</span>
        <time className="kv-row__at" dateTime={row.at}>
          {row.at}
        </time>
        {row.superseded && (
          <span className="kv-row__superseded-label" aria-label="superseded">
            superseded
          </span>
        )}
      </div>

      {/* Text: verbatim, pre-wrap preserves newlines */}
      <p className="kv-row__text">
        {row.text}
      </p>
    </article>
  );
}
