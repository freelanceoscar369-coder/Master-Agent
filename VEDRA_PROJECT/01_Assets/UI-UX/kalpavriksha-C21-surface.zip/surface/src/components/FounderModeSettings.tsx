/**
 * C21 · FounderModeSettings
 *
 * Brief constraints satisfied:
 * - Configuration form only: text input for assistant_display_name, editable
 *   list for assistant_aliases (add / remove / edit rows).
 * - EXAMPLE_ALIASES shown as non-interactive suggestion text.
 * - validateFounderMode is run on the current value; issues rendered inline
 *   as sentences next to the offending field.
 * - No modal. No navigation. No routing.
 *
 * IMPORTANT — ALIASES ARE STORED CONFIGURATION ONLY.
 * C21 implements NO conversation matching against them. The assistant_aliases
 * field exists so the configuration is captured and whatever implements
 * matching in a future cycle has a settled contract to read. Nothing in C21
 * reads assistant_aliases to make a decision of any kind.
 */

import { type ReactElement, useCallback } from 'react';
import type { FounderModeConfig, FounderModeIssue } from '../config/founderMode.ts';
import {
  validateFounderMode,
  EXAMPLE_ALIASES,
  MAX_NAME_LENGTH,
} from '../config/founderMode.ts';

export interface FounderModeSettingsProps {
  readonly config: FounderModeConfig;
  readonly onChange: (next: FounderModeConfig) => void;
}

/** Finds issues for a specific field (and optionally index). */
function issuesFor(
  issues: readonly FounderModeIssue[],
  field: FounderModeIssue['field'],
  index?: number,
): readonly FounderModeIssue[] {
  return issues.filter(
    (iss) =>
      iss.field === field &&
      (index === undefined || iss.index === index),
  );
}

export function FounderModeSettings({
  config,
  onChange,
}: FounderModeSettingsProps): ReactElement {
  const validation = validateFounderMode(config);
  const nameIssues = issuesFor(validation.issues, 'assistant_display_name');

  // ── Display name ──────────────────────────────────────────────────────────

  const handleNameChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      onChange({ ...config, assistant_display_name: e.target.value });
    },
    [config, onChange],
  );

  // ── Aliases ───────────────────────────────────────────────────────────────

  const handleAliasChange = useCallback(
    (index: number, value: string) => {
      const next = config.assistant_aliases.map((a, i) =>
        i === index ? value : a,
      );
      onChange({ ...config, assistant_aliases: next });
    },
    [config, onChange],
  );

  const handleAliasRemove = useCallback(
    (index: number) => {
      const next = config.assistant_aliases.filter((_, i) => i !== index);
      onChange({ ...config, assistant_aliases: next });
    },
    [config, onChange],
  );

  const handleAliasAdd = useCallback(() => {
    onChange({
      ...config,
      assistant_aliases: [...config.assistant_aliases, ''],
    });
  }, [config, onChange]);

  return (
    <div
      className="kv-settings"
      aria-label="Founder mode settings"
      role="region"
    >
      {/* ── Display name section ────────────────────────────────────────── */}
      <div className="kv-settings__section">
        <label
          className="kv-settings__label"
          htmlFor="kv-settings-display-name"
        >
          Assistant display name
        </label>

        <input
          id="kv-settings-display-name"
          type="text"
          className="kv-settings__input"
          value={config.assistant_display_name}
          onChange={handleNameChange}
          maxLength={MAX_NAME_LENGTH}
          aria-invalid={nameIssues.length > 0}
          aria-describedby={
            nameIssues.length > 0 ? 'kv-settings-name-issues' : undefined
          }
          autoComplete="off"
          spellCheck={false}
        />

        {/* Inline validation issues for display name */}
        {nameIssues.length > 0 && (
          <div
            id="kv-settings-name-issues"
            role="alert"
            aria-live="polite"
          >
            {nameIssues.map((iss) => (
              <p key={iss.code} className="kv-settings__issue">
                {iss.message}
              </p>
            ))}
          </div>
        )}
      </div>

      <hr className="kv-settings__separator" aria-hidden="true" />

      {/* ── Aliases section ─────────────────────────────────────────────── */}
      <div className="kv-settings__section">
        <span className="kv-settings__label" id="kv-aliases-label">
          Assistant aliases
        </span>

        {/* ALIASES ARE STORED CONFIGURATION ONLY — see file-level comment. */}
        <div
          className="kv-settings__aliases"
          role="group"
          aria-labelledby="kv-aliases-label"
        >
          {config.assistant_aliases.map((alias, index) => {
            const aliasIssues = issuesFor(
              validation.issues,
              'assistant_aliases',
              index,
            );
            const inputId = `kv-alias-input-${index}`;
            const issueId = `kv-alias-issue-${index}`;

            return (
              <div key={index} className="kv-settings__alias-row">
                <input
                  id={inputId}
                  type="text"
                  className="kv-settings__alias-input"
                  value={alias}
                  onChange={(e) => handleAliasChange(index, e.target.value)}
                  maxLength={MAX_NAME_LENGTH}
                  aria-label={`Alias ${index + 1}`}
                  aria-invalid={aliasIssues.length > 0}
                  aria-describedby={
                    aliasIssues.length > 0 ? issueId : undefined
                  }
                  autoComplete="off"
                  spellCheck={false}
                />

                <button
                  type="button"
                  className="kv-settings__alias-remove"
                  onClick={() => handleAliasRemove(index)}
                  aria-label={`Remove alias ${index + 1}`}
                >
                  remove
                </button>

                {/* Inline validation issues for this alias row */}
                {aliasIssues.length > 0 && (
                  <div id={issueId} role="alert" aria-live="polite">
                    {aliasIssues.map((iss) => (
                      <p key={iss.code} className="kv-settings__issue">
                        {iss.message}
                      </p>
                    ))}
                  </div>
                )}
              </div>
            );
          })}

          <button
            type="button"
            className="kv-settings__alias-add"
            onClick={handleAliasAdd}
            aria-label="Add alias"
          >
            + add alias
          </button>
        </div>

        {/* EXAMPLE_ALIASES — non-interactive suggestion text only */}
        <p className="kv-settings__suggestions">
          <span className="kv-settings__suggestions-label">Suggestions:</span>
          {EXAMPLE_ALIASES.join(', ')}
        </p>
      </div>
    </div>
  );
}
