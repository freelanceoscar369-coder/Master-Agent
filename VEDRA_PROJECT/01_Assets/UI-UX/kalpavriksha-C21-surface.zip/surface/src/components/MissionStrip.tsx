/**
 * C21 · MissionStrip
 *
 * Brief constraint satisfied: read-only strip of mission · execution ·
 * approvals · calm · vigilance. No buttons, no links, no click handlers.
 *
 * IMPORTANT — CARD/TILE RENDERING IS FORBIDDEN BY THE BRIEF'S "NO KPI WALL"
 * RULE. This component is a single horizontal scrollable row. It must never
 * be changed to a card grid, tile layout, metric panel, or dashboard widget.
 * Violating this constraint is an explicit brief failure.
 *
 * Each item: label in mono uppercase, then value. Hairline separators between
 * items. Horizontally scrollable on narrow widths.
 */

import { type ReactElement } from 'react';
import type { PresenceView, ViewField } from '../presentation/presenceView.ts';
import { stripFields } from '../presentation/presenceView.ts';

export interface MissionStripProps {
  readonly view: PresenceView;
}

/**
 * Resolves the tone name to the CSS custom property expression so the value
 * text can be coloured via an inline style (genuine dynamic value).
 */
function toneColor(tone: ViewField['tone']): string {
  switch (tone) {
    case 'live':      return 'var(--kv-live)';
    case 'needs-you': return 'var(--kv-needs-you)';
    case 'done':      return 'var(--kv-done)';
    case 'risk':      return 'var(--kv-risk)';
    case 'muted':     return 'var(--kv-ink-3)';
  }
}

export function MissionStrip({ view }: MissionStripProps): ReactElement {
  // stripFields returns [mission, execution, approvals, calm, vigilance] in
  // fixed order defined by the view model — the strip does not reorder them.
  const fields = stripFields(view);

  return (
    // aria-label describes the strip's purpose; role="region" is appropriate
    // for a landmarks-level grouping of related status fields.
    <section
      className="kv-strip"
      aria-label="Mission strip"
      role="region"
    >
      {fields.map((field) => (
        <div
          key={field.label}
          className="kv-strip__item"
          aria-label={`${field.label}: ${field.value}`}
        >
          {/* Label: mono uppercase — the static label from STATIC_LABELS */}
          <span className="kv-strip__label" aria-hidden="true">
            {field.label}
          </span>
          {/* Value: verbatim from the view field; tone applied as colour only */}
          <span
            className="kv-strip__value"
            style={{ color: toneColor(field.tone) }}
          >
            {field.value}
          </span>
        </div>
      ))}
    </section>
  );
}
