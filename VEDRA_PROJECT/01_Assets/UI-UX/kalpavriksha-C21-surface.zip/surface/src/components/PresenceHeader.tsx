/**
 * C21 · PresenceHeader
 *
 * Brief constraint satisfied: displays only view model values verbatim.
 * No greeting, no avatar, no animation, no synthesized text.
 * The `possiblyStale` flag is rendered as the word "no signal" in risk tone
 * — word plus colour, never colour alone (accessibility requirement from brief).
 *
 * Reads: view.assistantName (mono tracked caps, largest element),
 *        view.activity.value (single prose line, verbatim from C20),
 *        view.sequence + view.at (right-aligned mono block),
 *        view.possiblyStale (plain marker, risk tone).
 */

import { type ReactElement } from 'react';
import type { PresenceView } from '../presentation/presenceView.ts';
import { STATIC_LABELS } from '../presentation/presenceView.ts';

export interface PresenceHeaderProps {
  readonly view: PresenceView;
}

/**
 * Maps a ViewField tone name to the corresponding CSS custom property value.
 * Only the four signal colours plus muted are permitted by the design language.
 */
function toneVar(tone: PresenceView['activity']['tone']): string {
  switch (tone) {
    case 'live':      return 'var(--kv-live)';
    case 'needs-you': return 'var(--kv-needs-you)';
    case 'done':      return 'var(--kv-done)';
    case 'risk':      return 'var(--kv-risk)';
    case 'muted':     return 'var(--kv-ink-3)';
  }
}

export function PresenceHeader({ view }: PresenceHeaderProps): ReactElement {
  return (
    <header className="kv-header" aria-label="Presence header">
      {/* Left: name (largest, mono tracked caps) then activity line */}
      <div className="kv-header__left">
        <span className="kv-header__name" aria-label="Assistant name">
          {view.assistantName}
        </span>
        {/* view.activity.value is C20's line, carried verbatim — never rewritten */}
        <span
          className="kv-header__activity"
          style={{ color: toneVar(view.activity.tone) }}
        >
          {view.activity.value}
        </span>
      </div>

      {/* Right: sequence + timestamp, then stale marker when applicable */}
      <div className="kv-header__right" aria-label="Presence metadata">
        <span className="kv-header__meta">
          {view.sequence !== 0 && (
            <span aria-label="Sequence number">#{view.sequence}</span>
          )}
          {view.sequence !== 0 && view.at && (
            <span aria-hidden="true"> · </span>
          )}
          {view.at && (
            <time dateTime={view.at} aria-label="Last seen at">
              {view.at}
            </time>
          )}
        </span>

        {/* Stale marker: word "no signal" in risk tone — word + colour only */}
        {view.possiblyStale && (
          <span className="kv-header__stale" role="status" aria-live="polite">
            {STATIC_LABELS.disconnected}
          </span>
        )}
      </div>
    </header>
  );
}
