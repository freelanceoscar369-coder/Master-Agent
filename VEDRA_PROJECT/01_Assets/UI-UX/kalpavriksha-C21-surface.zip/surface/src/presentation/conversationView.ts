/**
 * C21 · Conversation view model.
 *
 * Projects C19A `ConversationEntry` values into what the conversation area
 * renders. Pure, total, and free of generation:
 *
 *  · It never creates an assistant entry. The only entries it can display are
 *    ones the runtime or the founder produced.
 *  · It never composes a greeting, a placeholder reply, or a "thinking"
 *    message. When the conversation is empty, it says the conversation is
 *    empty — see `EMPTY_CONVERSATION`.
 *  · It performs no reasoning, no summarisation and no formatting of content.
 *    Entry text is carried verbatim.
 */

import type { ConversationEntry, EntryRole } from '../../../desktop/src/types/execution.ts';

export interface ConversationRow {
  readonly id: string;
  readonly role: EntryRole;
  /** Verbatim. Never rewritten, trimmed or summarised. */
  readonly text: string;
  readonly at: string;
  readonly streaming: boolean;
  readonly superseded: boolean;
  /** Display name for the row's author. Configuration for the assistant,
   *  fixed words for the other two roles. Never inferred from content. */
  readonly author: string;
}

export const ROLE_AUTHORS = Object.freeze({
  user: 'You',
  system: 'System',
} as const);

/**
 * The empty state.
 *
 * Deliberately not a greeting. A synthesized "Good evening" would be exactly
 * the fabrication this brief forbids — and it would be the first thing the
 * founder ever read from the product, which makes it the worst possible place
 * to put an invented sentence.
 */
export const EMPTY_CONVERSATION = Object.freeze({
  headline: 'No conversation yet.',
  body: 'Anything said here will appear in this column, in order.',
} as const);

export function projectConversation(
  entries: readonly ConversationEntry[],
  assistantName: string,
): readonly ConversationRow[] {
  return entries.map((e) => ({
    id: e.id,
    role: e.role,
    text: e.text,
    at: e.at,
    streaming: e.streaming,
    superseded: e.supersededBy !== null,
    author:
      e.role === 'assistant' ? assistantName
      : e.role === 'user' ? ROLE_AUTHORS.user
      : ROLE_AUTHORS.system,
  }));
}

/** True when nothing has been said. Used to choose the empty state. */
export function isEmptyConversation(entries: readonly ConversationEntry[]): boolean {
  return entries.length === 0;
}
