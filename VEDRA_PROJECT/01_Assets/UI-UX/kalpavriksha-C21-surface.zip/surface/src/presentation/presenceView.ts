/**
 * C21 · Presence view model — strict projection of a C20 PresenceSnapshot.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * THE NON-SYNTHESIS RULE
 *
 * The brief is emphatic: "Display only runtime state. Never infer. Never
 * synthesize. Never decorate runtime values."
 *
 * That rule is enforced here structurally, not by care.
 *
 * Every user-visible string produced by this module is one of exactly two
 * things:
 *   (a) a value carried verbatim out of the snapshot, or a purely mechanical
 *       rendering of one (a number to its decimal string, a count to digits);
 *   (b) a STATIC LABEL drawn from the frozen `STATIC_LABELS` allowlist below.
 *
 * There is no third category. No adjectives are added, no sentences are
 * composed, no state is interpreted into a mood, and nothing is filled in when
 * the snapshot is silent — a null field renders as the `absent` label and
 * stops there.
 *
 * `tests/noSynthesis.test.ts` walks a generated view model and asserts every
 * string is traceable to (a) or (b). Adding an unlisted phrase fails the suite.
 *
 * NOTE ON DUPLICATION: this module deliberately holds NO presence or vigilance
 * logic. It does not decide whether the system is calm, does not evaluate
 * coverage, and does not rank missions. All of that already happened in C20
 * and is read here as fact. If a value is not in the snapshot, this surface
 * does not know it.
 * ═══════════════════════════════════════════════════════════════════════════
 */

import type {
  PresenceSnapshot,
  CalmState,
  VigilanceState,
} from '../../../presence/src/index.ts';

/* ───────────────────────── the label allowlist ────────────────────────── */

/**
 * Every static string this module may emit. Frozen and exported so the test
 * suite can assert nothing outside it appears in a view model.
 *
 * These are field labels and absence markers — the furniture of a readout.
 * None of them describes or characterises runtime state.
 */
export const STATIC_LABELS = Object.freeze({
  mission: 'Mission',
  execution: 'Execution',
  approvals: 'Approvals',
  calm: 'Calm',
  vigilance: 'Vigilance',
  activity: 'Activity',
  lastAction: 'Last action',
  reasoning: 'Reasoning',
  absent: '—',
  none: 'None',
  stale: 'stale',
  unreported: 'not reported',
  covered: 'complete',
  incomplete: 'incomplete',
  yes: 'yes',
  no: 'no',
  waiting: 'waiting',
  seconds: 's',
  disconnected: 'no signal',
} as const);

export type StaticLabel = (typeof STATIC_LABELS)[keyof typeof STATIC_LABELS];

/* ─────────────────────────── the view model ───────────────────────────── */

/**
 * Each field carries `value` (what to render) and `source`, which records
 * where the string came from. `source` is what makes the non-synthesis rule
 * checkable rather than aspirational.
 */
export interface ViewField {
  readonly label: StaticLabel;
  readonly value: string;
  readonly source: 'snapshot' | 'static';
  /** Snapshot signal, carried through unchanged. Never assigned by this module. */
  readonly tone: 'live' | 'needs-you' | 'done' | 'risk' | 'muted';
}

export interface PresenceView {
  /** The assistant's configured name. Configuration, not runtime state. */
  readonly assistantName: string;

  readonly mission: ViewField;
  readonly execution: ViewField;
  readonly approvals: ViewField;
  readonly calm: ViewField;
  readonly vigilance: ViewField;
  readonly activity: ViewField;
  readonly lastAction: ViewField;
  readonly reasoning: ViewField;

  /** Straight from `meta.possiblyStale`. Not inferred here. */
  readonly possiblyStale: boolean;
  readonly sequence: number;
  readonly at: string;
}

/* ────────────────────────── mechanical helpers ────────────────────────── */

/** Number → decimal string. The only numeric formatting permitted. */
function n(value: number): string {
  return String(value);
}

/** Seconds → "<n>s". Mechanical; adds no words. */
function secs(value: number): string {
  return `${n(value)}${STATIC_LABELS.seconds}`;
}

/* ─────────────────────────── field builders ───────────────────────────── */

function missionField(s: PresenceSnapshot): ViewField {
  if (s.activeMission === null) {
    return { label: STATIC_LABELS.mission, value: STATIC_LABELS.none, source: 'static', tone: 'muted' };
  }
  // Title and phase are carried verbatim from the snapshot. The separator is
  // punctuation, not a word.
  return {
    label: STATIC_LABELS.mission,
    value: `${s.activeMission.title} · ${s.activeMission.phase}`,
    source: 'snapshot',
    tone: s.activeMission.phase === 'held' ? 'needs-you' : 'live',
  };
}

function executionField(s: PresenceSnapshot): ViewField {
  const phase = s.execution.phase;
  const inPhase = s.execution.inPhaseSeconds;
  const value = inPhase === null ? phase : `${phase} · ${secs(inPhase)}`;
  return {
    label: STATIC_LABELS.execution,
    value,
    source: 'snapshot',
    tone: phase === 'failed' ? 'risk' : phase === 'idle' ? 'muted' : 'live',
  };
}

function approvalsField(s: PresenceSnapshot): ViewField {
  const count = s.pendingApprovals.length;
  if (count === 0) {
    return { label: STATIC_LABELS.approvals, value: STATIC_LABELS.none, source: 'static', tone: 'muted' };
  }
  const oldest = s.pendingApprovals[0];
  const wait = oldest === undefined ? '' : ` · ${STATIC_LABELS.waiting} ${secs(oldest.waitingSeconds)}`;
  return {
    label: STATIC_LABELS.approvals,
    value: `${n(count)}${wait}`,
    source: 'snapshot',
    tone: 'needs-you',
  };
}

function calmField(calm: CalmState): ViewField {
  // `statement` is composed by C20 and carried verbatim. This surface neither
  // rewrites it nor adds to it.
  return {
    label: STATIC_LABELS.calm,
    value: calm.statement,
    source: 'snapshot',
    tone: calm.calm ? 'done' : 'needs-you',
  };
}

function vigilanceField(v: VigilanceState): ViewField {
  if (v.complete) {
    return {
      label: STATIC_LABELS.vigilance,
      value: `${STATIC_LABELS.covered} · ${n(v.domains.length)}`,
      source: 'snapshot',
      tone: 'done',
    };
  }
  const names = v.gaps.map((g) => g.domain).join(', ');
  return {
    label: STATIC_LABELS.vigilance,
    value: `${STATIC_LABELS.incomplete} · ${names}`,
    source: 'snapshot',
    tone: 'risk',
  };
}

function activityField(s: PresenceSnapshot): ViewField {
  // `line` is composed by C20's template layer and carried verbatim.
  return {
    label: STATIC_LABELS.activity,
    value: s.activity.line,
    source: 'snapshot',
    tone: s.activity.kind === 'degraded' ? 'risk'
      : s.activity.kind === 'waiting-on-founder' ? 'needs-you'
      : s.activity.kind === 'idle' ? 'muted'
      : 'live',
  };
}

function lastActionField(s: PresenceSnapshot): ViewField {
  if (s.lastAction === null) {
    return { label: STATIC_LABELS.lastAction, value: STATIC_LABELS.none, source: 'static', tone: 'muted' };
  }
  const a = s.lastAction;
  return {
    label: STATIC_LABELS.lastAction,
    value: `${a.description} · ${a.actor} · ${secs(a.agoSeconds)}`,
    source: 'snapshot',
    tone: a.succeeded ? 'done' : 'risk',
  };
}

function reasoningField(s: PresenceSnapshot): ViewField {
  // When the runtime has supplied nothing, the surface says nothing. It does
  // not describe what the system is "probably" doing.
  if (s.reasoning.text === null) {
    return { label: STATIC_LABELS.reasoning, value: STATIC_LABELS.absent, source: 'static', tone: 'muted' };
  }
  const suffix = s.reasoning.stale ? ` · ${STATIC_LABELS.stale}` : '';
  return {
    label: STATIC_LABELS.reasoning,
    value: `${s.reasoning.text}${suffix}`,
    source: 'snapshot',
    tone: s.reasoning.stale ? 'muted' : 'live',
  };
}

/* ──────────────────────────── the projection ──────────────────────────── */

/**
 * Projects a snapshot into a view model.
 *
 * Pure. Total — every snapshot shape produces a complete view, including the
 * empty one. Adds no information that is not already in the snapshot or in
 * `STATIC_LABELS`.
 *
 * @param snapshot the C20 snapshot, consumed read-only.
 * @param assistantName configured display name (C21 Founder Mode).
 */
export function projectPresence(snapshot: PresenceSnapshot, assistantName: string): PresenceView {
  return {
    assistantName,
    mission: missionField(snapshot),
    execution: executionField(snapshot),
    approvals: approvalsField(snapshot),
    calm: calmField(snapshot.calm),
    vigilance: vigilanceField(snapshot.vigilance),
    activity: activityField(snapshot),
    lastAction: lastActionField(snapshot),
    reasoning: reasoningField(snapshot),
    possiblyStale: snapshot.meta.possiblyStale,
    sequence: snapshot.sequence,
    at: snapshot.at,
  };
}

/**
 * The view shown before any snapshot has arrived.
 *
 * Every field reads `no signal`. This is the honest opening state: the surface
 * does not pretend presence exists before it does, and it does not greet.
 */
export function absentPresence(assistantName: string): PresenceView {
  const blank = (label: StaticLabel): ViewField => ({
    label,
    value: STATIC_LABELS.disconnected,
    source: 'static',
    tone: 'muted',
  });
  return {
    assistantName,
    mission: blank(STATIC_LABELS.mission),
    execution: blank(STATIC_LABELS.execution),
    approvals: blank(STATIC_LABELS.approvals),
    calm: blank(STATIC_LABELS.calm),
    vigilance: blank(STATIC_LABELS.vigilance),
    activity: blank(STATIC_LABELS.activity),
    lastAction: blank(STATIC_LABELS.lastAction),
    reasoning: blank(STATIC_LABELS.reasoning),
    possiblyStale: true,
    sequence: 0,
    at: '',
  };
}

/** Ordered fields, for the mission strip. Order is fixed, not computed. */
export function stripFields(view: PresenceView): readonly ViewField[] {
  return [view.mission, view.execution, view.approvals, view.calm, view.vigilance];
}
