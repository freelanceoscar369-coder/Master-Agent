# Resolved · Decision 1: the approval queue at volume

Open decision 1 is now designed. See **Screen 04b — Approval Queue at Volume**.

### The frame

At five open items the Approval Center is a list. At twenty it is an inbox, and an inbox turns an executive partner back into a to-do app — the founder starts triaging the AI instead of the business. So the design goal is inverted from every inbox ever built: **success is the queue shrinking**, and the headline metric is not throughput but the share of decisions Kalpavriksha stops needing to ask about.

### Three principles

1. **Rank by consequence, never by time.** A chronological queue makes the founder do the prioritisation the AI should have done. Ranking function: `irreversibility × log(exposure) × deadline_proximity × novelty`, and it is inspectable on request — opaque prioritisation is the fastest way to lose trust in a queue.
2. **Delegating judgment beats delegating tasks.** Batching is a bandage; the cure is a standing rule. The founder teaches a decision boundary once and never sees that class of request again.
3. **Silence must have a stated default.** Every item declares what happens if the founder never responds ("if I don't hear from you by Thursday 18:00, I'll let it renew"). Pre-committed defaults make ignoring the queue a decision rather than a debt.

### Three tiers

| Tier | Contents | Interaction |
|---|---|---|
| **Needs you** | Irreversible, novel, high exposure | Full consequence card, individual verdict. **Never batches** — no checkboxes at any volume. |
| **Sweep** | Routine, reversible, precedent exists | Dense rows, multi-select, running aggregate exposure, 60s undo. |
| **Auto-handled** | Covered by a standing rule | Shown as a **receipt**, not a request. |

Read as a ratio, not a total: 2 / 9 / 14 is a healthy day; 12 / 9 / 4 means the rules aren't working.

### Standing rules — proposed, never authored

A settings page for approval rules is where rules go to die; nobody writes policy preemptively. Kalpavriksha instead watches its own approval history and asks once it has earned the right: *"You've approved 9 of 9 tooling renewals under ₹50,000. Want me to stop asking?"* — with the evidence strip, the median time-to-approve, and the one rejection that sets the ceiling.

**This is the emotional peak of the product** — not the neural tree. The moment the AI proposes a boundary from observed behaviour is when the founder feels accompanied rather than assisted.

Rule anatomy is non-negotiable, five parts: **trigger** (narrow and boring) · **blast radius** (a cumulative cap, not just per-item — a per-item cap alone is how you lose ₹8L in forty ₹20K approvals) · **never-clause** (explicit exclusions, always displayed) · **trial period** (30 days; rules expire unless renewed) · **receipt** (every firing logged and reviewable).

### Mute, snooze, delegate

Snooze defers with a re-surface time. Mute silences a class for a period but never hides the receipt. **Delegate routes to a human** — the most under-designed option in every approval product. A founder at twenty items a day usually shouldn't be the approver at all; invoices over ₹2L go to the CFO, seats to the Head of Eng.

### Trust anchors

Undo windows are graded by who was in the room: batch sweep 60s, single approval 30s, **rule firing 24h** (longest, precisely because the founder wasn't present), irreversible actions none. A single **Pause all autonomy** control makes every rule dormant instantly — Kalpavriksha keeps working and keeps queueing, it just stops deciding. This also makes "AUTONOMY · LEVEL 3" on Mission Control real: level is derived from active rules, and it collapses to zero in one gesture. *(Partially resolves open decision 4.)*

### The headline metric

**Autonomy ratio** — the share of decisions handled by rule versus escalated. This line going up is the product working. If it flattens, Kalpavriksha has stopped learning the founder's judgment, and that is a churn signal months before the founder can articulate it.

### Deliberately refused

No unread badges or counts (a number on a nav item is an obligation — Kalpavriksha says "2 need you," never "23 unread"). No inbox-zero gamification. No bulk-approve on tier 1. No silent rule creation from inferred consent. No settings page called "Approval Rules" — rules live where decisions live.

### It's one screen, not two

Screen 04 doesn't fork. Below ~5 open items it renders as full consequence cards; at 6–15 tiers appear and the sweep list densifies; past 16 rule proposals start surfacing. The founder never learns two interfaces — and the transition is itself information: **the day the tiers appear is the day the founder learns they're becoming the bottleneck.**
