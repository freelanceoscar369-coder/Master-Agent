# Thread Context

## Numbers & Values

## Corrections

## Constraints

## Key Entities

## Decisions

## Notes

## Plan Overview

## Kalpavriksha Founder Dashboard — Experience Design v1

**Deliverable:** a design-only milestone (no product engineering). Three artifacts: (1) an interactive, clickable 5-screen visual concept the founder can actually walk through, (2) a design system page, (3) a UX/interaction + animation spec doc.

### Where I'm challenging the brief (CPO view)

**1. Swiss Grid skill: take the discipline, invert the palette.**
The pinned skill's canon is white paper / near-black ink / Swiss red — the exact opposite of the cinematic dark environment you want. Blindly following it would produce a Müller-Brockmann report, not a mission control. What actually transfers, and is the reason to use it: one CSS-variable source of truth, 12-column modular grid with subgrid bands so every card snaps to a column line, an 8px baseline lock, the toggleable grid overlay, optical ink alignment on display type, and the Puppeteer 0px verification harness. NASA mission control is itself rigorously gridded — telemetry earns trust through alignment. So: Swiss *structure*, dark *surface*. I'll also ship the grid-toggle as a live feature of the concept — it doubles as proof of engineering rigor to anyone reviewing the design.

**2. The neural tree is the hook, not the product.** The tree earns 8 seconds of awe on arrival; the Approval Center earns the subscription. I'll make the tree recede — after arrival it demotes to a small persistent "presence" sigil in the corner that pulses with system state (thinking / idle / awaiting you). A full-screen particle organism that never gets out of the way becomes a screensaver you resent by day four. The tree should be *state*, not *scenery*.

**3. Voice cannot autoplay.** Every browser blocks unprompted audio; a greeting that silently fails to speak makes the AI feel broken on turn one. Design fix: arrival screen opens with the tree assembling and a single gesture ("Wake Kalpavriksha" / any keypress) that unlocks audio and starts the typed+spoken greeting in sync. The toggle stays, but the first interaction is the permission grant, disguised as ceremony. Typing is the source of truth; voice rides on top.

**4. The 15–20s idle prompt is needy.** "What's on your mind today?" fired at a founder mid-thought reads as an assistant interrupting a CEO. I'll pitch it as: the three choices surface *silently* (no voice, no modal) as the tree settles, ambient rather than interrogative. Voice only re-engages if the founder has been idle and then moves the cursor — i.e. attention returned.

**5. Add a sixth state the brief is missing: the empty/quiet day.** "While you were away: 0 missions" is where most AI-partner products die. I'll design the low-activity variant of the Executive Brief — the AI reporting a calm system with conviction is a stronger trust signal than a wall of achievements.

**6. Approvals need consequence framing, not just Approve/Discuss/Reject.** Each approval card gets: what changes, what it costs, what happens if you do nothing, and reversibility. That's the Bloomberg 10% doing real work.

### Visual direction
Near-black field (#05070A) with cool graphite panels, one restrained cyan-white accent for live/AI state and a single amber for "requires you." Glass panels at low opacity with hairline strokes, never blurred to mush. Type: a grotesque (Inter / Archivo) for display + body, a mono (IBM Plex Mono) for telemetry, mission IDs, timestamps, folios — the mono is what sells "instrument, not app." Big numerals set large. No neon, no gradients-as-decoration, no robot imagery.

### Motion
Tree assembly on arrival (particles converging, ~2.5s), breathing idle at low amplitude, a "thinking" reorganization state, typed greeting with cursor synced to speech cadence, cards entering on the baseline grid with staggered rise, approval cards floating in with a weight/settle. All specified with durations and easing in the spec doc, plus an honest note on the perf budget (canvas particle count, prefers-reduced-motion fallback).

## Plan Tasks

- [x] Milestone 1 delivered: 5-screen concept artifact, design system, UX and interaction spec
- [x] Milestone 1b: design the approval queue at volume — triage model, batch sweep, standing rules, mute and delegate, silence defaults
- [x] Build the queue as a focused interactive screen 04b on the same grid and design system
- [x] Add the queue design to the spec doc as a resolved decision with the reasoning

## Plan Context

**Key considerations / risks**

- *Skill/brief conflict:* Swiss Grid canon is white + red; brief demands cinematic dark. Resolution is grid discipline + inverted surface. The skill's verification harness still applies unchanged and is worth running — it's the difference between a mood board and a system.
- *Perf:* a real particle field costs frames. Canvas 2D with a capped particle count (~1.5–3k, scaled by viewport) beats WebGL for a concept artifact; artifacts run sandboxed so no external WebGL libs are assumed. `prefers-reduced-motion` gets a static assembled-tree fallback.
- *Audio in the artifact:* browser SpeechSynthesis is used for the concept demo only, gated behind the wake gesture. Production voice would be a real TTS; the spec will say so rather than implying the demo stack ships.
- *Scope guard:* this milestone stops at concept + spec. No backend, no data model, no real missions. Content in the screens is representative sample data using the founder name Onkar.
- *What I'll flag at the end:* open decisions I don't want to silently resolve — persistent-sigil vs full tree on every screen, whether Discuss opens Conversation Mode inline or as a takeover, and whether approvals need a queue/batch view once volume exceeds ~5/day.
