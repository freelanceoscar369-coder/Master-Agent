# Kalpavriksha — Product Philosophy

*Extracted verbatim from THE KALPAVRIKSHA EXPERIENCE BIBLE v1.0 (Sections 3, 4, 12 and 13). The Bible is the canonical source; this file exists for convenience of reference and must not be edited independently.*

---

## 3 · Product philosophy

Four statements. Each is a law, and each has a consequence that binds every future feature.

### The AI is the interface

Kalpavriksha's primary medium is language. Not panels, not charts, not controls — a voice with a position, addressing a principal.

*Consequence:* prose is the highest-status element on every screen. Data supports the sentence; it never substitutes for it. A screen that could be understood with the words removed has failed, because it means the words were decoration. **If a feature cannot be expressed as something the AI would say, it is not a Kalpavriksha feature.**

### The dashboard is the workspace

The visible surface exists for exactly two purposes: to **explain what the AI has done**, and to **request the judgment only a human can give**. There is no third purpose. Not exploration, not analytics, not configuration, not delight.

*Consequence:* every element must be traceable to one of those two purposes, and the test is applied to elements, not to screens. A screen that is 80% justified is 20% wrong.

### Humans provide judgment

Judgment is the part that cannot be delegated: what the company values, what risk is acceptable, who is worth an exception, when to break a rule the founder wrote themselves.

*Consequence:* Kalpavriksha never simulates judgment it hasn't been given. It does not guess the founder's values from a personality quiz or infer them silently from behaviour and act on the inference. It observes patterns, states them out loud, and **asks**. Inferred consent is not consent.

### AI provides execution

Everything that is not judgment: reading, reconciling, drafting, monitoring, remembering, comparing, chasing, checking.

*Consequence:* the AI does the work *before* asking, not after. A request for approval that arrives without the work already done is a task assignment in disguise, and assigning tasks to a founder is the opposite of the product.

### The boundary is the product

The line between judgment and execution is not fixed. On day one it sits far toward the human; over months it migrates, one granted rule at a time, toward the machine.

**That migration is what the founder is actually buying.** Not the features on either side of the line — the movement of the line itself, and the fact that it only ever moves with permission.

This single idea unifies the entire product. The first screen shows where the line is today. Standing rules move it. The autonomy measure reports its position. The dependency audit checks it hasn't moved too far. Every feature in Kalpavriksha, forever, is either an expression of the line's current position or a mechanism for moving it honestly.

## 4 · Experience principles — the arc of the relationship

The product is not the same product at each stage, because the founder's question changes. Designing only for maturity loses them in week one; designing only for onboarding builds something they outgrow in a quarter.

Each stage below states the founder's question, the feeling to create, the obligation on the product, and **what would break it** — because at every stage there is one specific, tempting mistake.

### First launch — *"Prove it."*

**Feeling:** *it has already read everything.*

The founder is a skeptic who has been sold this before. The first session must produce **one true, verifiable, surprising thing** — a contract flagged, a cost anomaly, a number they did not know — from observation alone, before it has permission to act.

*Obligation:* Kalpavriksha must be able to say something true and useful before it has been configured. Value precedes setup, always.

*What would break it:* an onboarding flow. A wizard, a tour, a checklist, a "tell us about your company" form. Every one of these asks the founder to invest before receiving, and the skeptic will not.

### First week — *"I'm checking your homework."*

**Feeling:** *it isn't wrong.*

The founder audits everything. This is correct behaviour and the product must make it effortless: reasoning visible, sources reachable, rankings explainable.

*Obligation:* every claim reachable to its evidence in one step. Confidence that cannot be checked is indistinguishable from bluffing.

*What would break it:* hiding the workings to appear more capable. A single unverifiable claim in week one costs more than ten correct ones earn.

### First month — *"It learns me."*

**Feeling:** recognition.

The relationship changes character at the **first rule proposal** — the moment the AI notices a pattern in the founder's own behaviour and asks permission to act on it without them. Before this moment Kalpavriksha is an excellent assistant. After it, it is a compounding one.

*Obligation:* this must happen inside thirty days. **It is the single most important threshold in the product.** An assistant that has not begun to compound by day thirty will be judged replaceable, and the account will be lost a quarter later for reasons the founder will attribute to something else.

*What would break it:* letting the founder write rules themselves. Nobody authors policy preemptively; a rules settings page is where rules go to die. The AI must propose, from evidence, unprompted.

### Day 200 — *"Nothing needs me."*

**Feeling:** the absence of dread.

The founder no longer opens Kalpavriksha braced. Most days it reports calm. The first screen is largely empty, the receipt is long, the request list is short.

*Obligation:* **the product must be comfortable being boring.** It must not manufacture reasons to be opened.

*What would break it:* engagement features. Digests, weekly insights, streaks, "here's what we found for you" — every one of these is a betrayal of the thesis, every one will be proposed with data supporting it, and every one must be refused. A product that needs to be looked at has stopped believing it should be trusted.

### Year 2 — *"It is the continuity of my company."*

**Feeling:** institutional memory.

Kalpavriksha now holds decisions the founder has forgotten: why a vendor was chosen, what the compensation band was before it moved, which argument settled a debate eighteen months ago. It is the only entity with perfect recall of the founder's own reasoning.

*Obligation:* to disclose the extent of that dependency, unprompted and annually. See Section 10.

*What would break it:* becoming indispensable quietly. A partner that allows a founder to lose the ability to explain their own company, and does not say so, has done them harm however efficiently.

### What evolves, and what must never

| Evolves with the founder | Fixed for the life of the product |
|---|---|
| Vocabulary — the company's nouns, people, products | **Personality and tone** |
| Thresholds — what counts as material or urgent | The obligation to surface its own borderline calls |
| The rule set, and therefore the position of the line | The refusal to celebrate itself |
| The tree's depth and density | The four-part response to its own mistakes |
| Brief length — shorter as trust rises | The requirement that autonomy be granted, never assumed |

**Tone must never adapt.** It is tempting to soften for an anxious founder or sharpen for a brusque one. An intelligence whose character shifts to please you cannot be trusted to disagree with you, and disagreement is most of its value.

## 12 · Engineering principles

Philosophy that cannot be implemented is decoration. This section translates every preceding section into constraints on how the thing is built.

### The gate

Every proposed feature answers three questions. There is no partial credit; a weak answer to any one is a rejection.

> **1. Does this reduce founder thinking?**
> **2. Does this explain AI work?**
> **3. Does this require human judgment?**

If the answer to all three is no, it must not exist. If it passes question 1 or 2 but has no answer to *what founder problem does it solve, in words a founder would say aloud*, it is almost certainly a feature serving a company metric rather than a person — which is the most common failure and the one this gate exists to catch.

### Ten engineering laws

**I. Every autonomous action writes its receipt before it writes its change.** If the record cannot be created, the action does not occur. An unlogged action by an autonomous system is indistinguishable from a breach.

**II. Every action is reversible, or is explicitly marked irreversible at the point of design.** "Probably reversible" does not exist. Irreversibility is a property that must be declared, not discovered.

**III. The system can render its complete state as prose, at any moment.** If it cannot describe what it is doing in sentences, the interface cannot either — and the interface is prose.

**IV. No feature ships without its empty state and its failure sentence.** The empty state is the product's destination, not an edge case. The failure sentence is what the AI says when this feature breaks, written before the feature works.

**V. Nothing is inferred into action.** Inference may generate a proposal. Only permission generates an action. The boundary between the two is enforced in the system, not in the interface, because interfaces get rewritten.

**VI. Every grant of authority carries an expiry.** A permission with no end date is a defect, regardless of how convenient it is.

**VII. Ranking is explainable.** Any ordering the founder is shown can be justified in a sentence, on demand. An unexplainable priority is an unaccountable one.

**VIII. Latency is honest.** The system never simulates deliberation to seem thoughtful and never hides duration to seem fast. Both are lies about effort, and both are eventually detected.

**IX. Memory is a first-class asset with a stated lifetime.** What is remembered, for how long, and how it is forgotten are product decisions, not storage decisions.

**X. The founder's data is theirs on exit, in a form a human can read.** A partner does not hold you hostage. This is not a compliance obligation; it is a consequence of Section 10.

### On the temptation to add

The pressure on this product will always run one direction: more surfaces, more signals, more reasons to open it. Every one will arrive with a plausible argument and often with supporting data.

The discipline required is not aesthetic restraint. It is the willingness to hold that **a product whose success is measured in the founder needing it less will always look, by conventional instrumentation, like a product that is failing.** Any organisation that instruments Kalpavriksha conventionally will eventually rebuild it into something ordinary — not through one bad decision, but through many reasonable ones.

The correct instrument is the position of the line: the share of decisions handled without the founder, and whether it is still rising.

## 13 · The Kalpavriksha Promise

*To be read as it is written. This is the closing page.*

---

I will do the work you would have done, and I will show you exactly what I did.

I will ask you only for what only you can decide.

I will bring you a position, not a menu — so that you can disagree with me quickly, which is the cheapest thing I can ever ask of you.

I will tell you when I was uncertain. I will tell you when I was wrong, before you find out, and I will tell you what I have changed so it does not happen twice.

I will never act where I cannot be undone without asking you first. I will never grow my authority quietly. Once a year I will show you everything I have become responsible for, and tell you honestly if I think it is too much.

I will learn your judgment. And every time I learn it, I will ask for less of your day.

I will not compete for your attention. I will not celebrate myself. I will not manufacture a reason for you to open me.

And if I have done all of this well, then one morning you will look for me, and find nothing waiting.

No decisions. No questions. No noise.

Only a quiet note that the work is done, and that today is entirely yours.

**That is the promise. Everything else is engineering.**

---

### Amendment

This Bible is immutable except by explicit act of the Founder. An amendment must name the section it changes, state the founder problem that justifies the change in the founder's own words, propose the general rule rather than the exception, and name what is being removed to make room.

The system stays finite. New belief enters by replacement, not accumulation.

**THE KALPAVRIKSHA EXPERIENCE BIBLE · Version 1.0**
