# Kalpavriksha — Vision

*Extracted verbatim from THE KALPAVRIKSHA EXPERIENCE BIBLE v1.0 (Sections 1 and 2). The Bible is the canonical source; this file exists for convenience of reference and must not be edited independently.*

---

## 1 · Vision

### Who Kalpavriksha exists for

The founder of a company that has outgrown one mind but has not yet grown a second.

This is a specific and narrow condition. Below it, a founder can hold the entire company in their head and needs no partner. Above it, a real executive team exists and the founder's decisions are genuinely theirs alone to make. In between — and it is a long, brutal in-between — a single person is the bottleneck for a hundred decisions a week, most of which do not deserve them, and all of which they must nevertheless hold.

Kalpavriksha is built for that person, in that period. It is not built for teams, not for managers, not for operators, and not for anyone whose problem is that they need to do more. **It is built for someone whose problem is that everything routes through them.**

### Why it exists

Because the scarcest resource in a growing company is not capital, talent or time. It is **the founder's uninterrupted judgment** — and almost all of it is spent on decisions that did not require judgment at all.

A founder who approves three hundred things a quarter and spends four minutes on two hundred and eighty of them is not exercising judgment. They are providing a signature. Kalpavriksha exists to take the signature and return the judgment.

### What problem it solves

Three problems, in this order of importance:

**Vigilance.** The background hum of *what is happening that I don't know about?* This is the heaviest cognitive burden a founder carries and the least discussed, because it never appears on a calendar. It is what makes a holiday not a holiday. Kalpavriksha's first job is to make that question answerable in one sentence, at any moment, without asking anyone.

**Decision volume.** The sheer count of small verdicts. Solved not by making each decision faster, but by removing whole classes of them permanently.

**Continuity.** A founder forgets why they decided things. Their company then relitigates those decisions, expensively. Kalpavriksha remembers the founder's own judgment better than the founder does.

### What it refuses to become

This list is load-bearing. Each item is a product Kalpavriksha could easily and profitably become, and each would be a failure.

- **A chatbot.** A thing that waits to be asked has not understood the problem. Kalpavriksha opens with a report, because it has already been working.
- **A dashboard.** A surface that displays data and calls that value. Data is evidence for a decision; it is not the product.
- **A productivity tool.** Something that helps the founder do more. Kalpavriksha exists so the founder does less.
- **A system of record.** Records are a by-product. The moment the product's value is "everything is in one place," it has become filing.
- **An agent marketplace, a workflow builder, or a platform.** Each converts a partner into a toolkit, and hands the founder a configuration problem in exchange for a judgment problem. That is a bad trade offered by every company that ran out of conviction.
- **A product that measures its success in engagement.** This is the most dangerous of all, because the metrics will always argue for it. Kalpavriksha's success is measured in *the founder needing it less*. Any instrument that rewards attention will eventually corrupt the product, and must be refused at the level of what is measured, not merely what is built.

## 2 · Founder philosophy

You cannot design for someone you have not modelled. This is the model.

### How founders think

**In bets, not tasks.** A founder does not hold a to-do list; they hold a small number of live wagers about the future and a rough sense of which are working. Every input is unconsciously sorted by *does this change one of my bets?* Almost nothing does, which is why almost everything they are shown is noise.

**In constraints.** A founder's mental model of the company is a structure of limits — runway, hiring capacity, the two people who cannot be lost, the one system that cannot go down. They reason forward from constraints rather than backward from goals. Information that does not touch a constraint does not enter the model.

**In a fragile, resident model.** The founder holds a compressed simulation of the whole company in working memory. It is expensive to load and it degrades on interruption. This single fact explains more about founder behaviour than any other: they are not avoiding your notification because they are busy. They are protecting the model.

### How founders make decisions

Under incomplete information, quickly, and with a strong preference for **reacting over generating**. Producing an option costs a founder ten times what evaluating one costs. This is the most important asymmetry in the product.

> **The most useful thing you can hand a founder is a decision already made, which they can veto.**

A menu of three options is a request that they do the work of choosing. A recommendation with a number attached is a request that they do the work of *disagreeing* — which is cheap, fast, and something they are extremely good at. Every request Kalpavriksha makes must therefore arrive as a position, not a question.

They also decide **irreversibly or reversibly, and they know the difference instinctively.** A reversible decision they will make in seconds. An irreversible one they will delay for days, and no amount of interface can or should hurry them. Design must respect this distinction rather than flattening it: speed for the reversible, friction for the permanent.

### How founders experience time

Not as a calendar. As **a countdown overlaid with interrupts.**

The countdown is runway, and it runs continuously in the background of every thought. The interrupts are everything else. A founder's day is not a sequence of hours; it is a stack of half-finished thoughts, each one abandoned mid-sentence by the next arrival.

The consequence is that **the cost of interruption is superlinear.** Two thirty-minute blocks are worth substantially less than one sixty-minute block, because the model must be reloaded each time. A product that saves a founder twenty minutes of work while costing them three context switches has made their day worse and will be uninstalled by someone who cannot explain why.

This is why Kalpavriksha never interrupts, batches by consequence rather than arrival, and treats *not contacting the founder* as a positive act with measurable value.

### How Kalpavriksha reduces cognitive load

There are three loads. They are not equal and they are not solved the same way.

**Vigilance load** — *what don't I know?* The heaviest. Reduced by a single trustworthy sentence, always available, that accounts for everything: *"Nothing needs you."* This only works if it has never once been wrong, which is why the AI must surface its own borderline calls. One concealed judgment call destroys the value of every future reassurance.

**Decision load** — *what must I choose?* Reduced by ranking on consequence, presenting one decision at a time, and permanently removing classes of decision through standing rules. Note that reducing the *number* matters more than reducing the *effort per decision*; ten easy decisions cost more than one hard one, because each carries a context switch.

**Memory load** — *what did I decide, and why?* Reduced by remembering on the founder's behalf and returning it unprompted at the moment of relevance — never as an archive the founder must go and search, which is simply memory load with extra steps.
