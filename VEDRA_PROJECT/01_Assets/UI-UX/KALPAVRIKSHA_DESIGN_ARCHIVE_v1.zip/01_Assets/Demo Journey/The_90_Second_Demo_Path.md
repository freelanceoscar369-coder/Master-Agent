# The 90-second demo path

**Correction to an earlier note.** I previously flagged that the sales demo should "open on Mission Control, not the first screen." That was wrong. Opening on density is the trap every AI product falls into — *look how much it does!* Strangers don't buy activity. They buy a specific outcome they recognise as their own pain, then the belief that it compounds.

The sparse first screen isn't the problem. **Showing it before it has been earned** is. So don't skip it — end on it. The emptiness is the punchline.

### The structural insight

Kalpavriksha's value is a **derivative** — it lives in the change between day 1 and day 200. You cannot demo a derivative with a screenshot. The demo is therefore not a tour of screens; it is a **time-lapse of a relationship**.

Emotional arc: *this is my life* → *it did something I'd pay a person for* → *it gets better on its own* → *and then it leaves me alone.*

### Six beats, 90 seconds

| # | Time | Beat | On screen | Felt |
|---|---|---|---|---|
| 1 | 0:00 · 12s | **Cold open** | No interface. Two numbers: 340 approvals last quarter, 312 under four minutes. | Recognition |
| 2 | 0:12 · 18s | **The noise** | Day one. 23 open items stacking up. Deliberately uncomfortable. | Earned honesty |
| 3 | 0:30 · 20s | **The moment** | One decision in full — Datastack, ₹4.1L, counter-position written. **They click it.** | Competence |
| 4 | 0:50 · 15s | **The compound** | "You've approved 9 of 9 under ₹50K. Want me to stop asking?" + safety strip. | Surprise |
| 5 | 1:05 · 15s | **The slope** | Autonomy ratio 18% → 91%. The only chart in the demo. | Belief |
| 6 | 1:20 · 10s | **The silence** | "Nothing needs you." Four-second hold. | Desire |

Beat 3 gets the most time because it is the only beat that proves competence. Beat 6 holds silence for ten seconds, which will feel unbearable to the presenter and is exactly right.

### Six rules

1. **Open on their pain, not the product.** No interface for the first twelve seconds. If they don't nod at "312 of them took under four minutes," nothing after it lands.
2. **Hand them the mouse at beat 3.** They click *Send the counter*, not you. A demo watched is forgotten; a decision made with your own hand is a commitment — and it's the only moment they experience being the principal rather than the audience.
3. **Answer "what if it's wrong?" before they ask.** Four words under the rule proposal — *undo 24h · cap ₹2L · expires 30 days · pause one click* — four seconds of screen time. Pre-empt the autonomy objection while they're still excited.
4. **One chart, and it's a slope.** Not usage, not tasks, not hours saved. A rising slope is the only visual that expresses a derivative.
5. **The tree appears last, or not at all.** Every AI startup opens on a glowing particle animation; leading with it files you in that drawer within two seconds. Here it is atmosphere behind the final frame — the reward for having earned the silence.
6. **Never demo live.** A deterministic demo tenant with real data *shape* and fixed outcomes. Say so openly — "this is a scripted tenant" buys more trust than a live run that stumbles.

### Cut from the 90

**Conversation mode** (painful, but every AI product demos a chat box — it's the least differentiated thing you own). **Mission Control** (density reads as complexity to a stranger; right screen for the technical evaluator at minute eight). **The integrations wall** (a grid of logos says "another tool to configure"). **Voice** (delights in person, dies on a shared screen with bad audio — in-room only, never async). **Any sentence beginning "and it can also…"** — the 90 seconds proves exactly one claim, and a second claim halves the first.

### Variants off the same spine

- **90s cold** — all six beats. Booth, cold intro, opening of any call.
- **3 min async** — same beats plus the flagged judgment call from the receipt ("I approved this under your rule but the pattern might not be what you meant"). It needs its own beat to land, and async viewers rewind it. That clip is the one that gets forwarded.
- **15 min qualified** — run the 90 unchanged first, then open the floor. Mission Control, the queue at volume, conversation mode and the rule library all earn their place once the buyer is asking rather than being shown.

### The closing line

*"You're not buying a dashboard. You're buying that."* — said over the silent frame after a four-second hold, then stop talking. The instinct will be to fill the pause with features. **The pause is the product.**
