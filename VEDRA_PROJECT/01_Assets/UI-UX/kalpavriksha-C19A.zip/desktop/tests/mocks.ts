/**
 * Test doubles and fixture factories for the C19A adapter layer.
 * No dependencies on React or any external framework.
 */

import type {
  ApprovalVerdictRequest,
  CancelRequest,
  ConversationEntry,
  EntryId,
  ExecutionFailure,
  ExecutionId,
  KernelResponse,
  MissionCard,
  RetryRequest,
  RuntimeEvent,
  SendRequest,
  Timestamp,
} from '../src/types/execution.ts';
import type { RuntimeClient } from '../src/services/runtimeClient.ts';

/* ─────────────────────────── call recorder ────────────────────────────── */

export interface MockCalls {
  send: SendRequest[];
  submitApproval: ApprovalVerdictRequest[];
  cancel: CancelRequest[];
  retry: RetryRequest[];
  subscribe: Array<(event: RuntimeEvent) => void>;
}

/* ─────────────────────────── mock overrides ───────────────────────────── */

export type MockOverrides = {
  send?: KernelResponse<{ readonly executionId: ExecutionId }>;
  submitApproval?: KernelResponse<{ readonly accepted: true }>;
  cancel?: KernelResponse<{ readonly requested: true }>;
  retry?: KernelResponse<{ readonly executionId: ExecutionId }>;
};

/* ─────────────────────────── mock client ───────────────────────────────── */

export interface MockRuntimeClient extends RuntimeClient {
  calls: MockCalls;
  /** Push a RuntimeEvent to all current listeners. */
  emit(event: RuntimeEvent): void;
}

export function createMockRuntimeClient(overrides: MockOverrides = {}): MockRuntimeClient {
  const calls: MockCalls = {
    send: [],
    submitApproval: [],
    cancel: [],
    retry: [],
    subscribe: [],
  };

  const listeners = new Set<(event: RuntimeEvent) => void>();
  let disposed = false;

  function notWired(method: string): KernelResponse<never> {
    return { kind: 'not-wired', reason: `test: ${method} not wired`, method };
  }

  return {
    kind: 'stub',
    wired: false,

    calls,

    async send(req: SendRequest) {
      calls.send.push(req);
      return (overrides.send ?? notWired('send')) as KernelResponse<{ readonly executionId: ExecutionId }>;
    },

    async submitApproval(req: ApprovalVerdictRequest) {
      calls.submitApproval.push(req);
      return (overrides.submitApproval ?? notWired('submitApproval')) as KernelResponse<{ readonly accepted: true }>;
    },

    async cancel(req: CancelRequest) {
      calls.cancel.push(req);
      return (overrides.cancel ?? notWired('cancel')) as KernelResponse<{ readonly requested: true }>;
    },

    async retry(req: RetryRequest) {
      calls.retry.push(req);
      return (overrides.retry ?? notWired('retry')) as KernelResponse<{ readonly executionId: ExecutionId }>;
    },

    subscribe(listener: (event: RuntimeEvent) => void) {
      if (disposed) return () => {};
      calls.subscribe.push(listener);
      listeners.add(listener);
      let removed = false;
      return () => {
        if (removed) return;
        removed = true;
        listeners.delete(listener);
      };
    },

    listenerCount() {
      return listeners.size;
    },

    dispose() {
      disposed = true;
      listeners.clear();
    },

    emit(event: RuntimeEvent) {
      for (const l of listeners) l(event);
    },
  };
}

/* ─────────────────────────── fixture factories ─────────────────────────── */

let _seq = 0;
function seq(): string {
  return String(++_seq);
}

export function anEntry(partial: Partial<ConversationEntry> = {}): ConversationEntry {
  const id: EntryId = `entry_${seq()}`;
  return {
    id,
    role: 'user',
    text: 'test message',
    at: new Date().toISOString() as Timestamp,
    executionId: null,
    streaming: false,
    supersededBy: null,
    missions: [],
    ...partial,
  };
}

export function aMissionCard(partial: Partial<MissionCard> = {}): MissionCard {
  return {
    ref: `mission_${seq()}`,
    title: 'Test Mission',
    line: 'Doing test work',
    status: 'queued',
    progress: null,
    updatedAt: new Date().toISOString() as Timestamp,
    ...partial,
  };
}

export function anApprovalRequestedEvent(
  partial: Partial<Extract<RuntimeEvent, { type: 'approval.requested' }>> = {},
): Extract<RuntimeEvent, { type: 'approval.requested' }> {
  return {
    type: 'approval.requested',
    approvalId: `approval_${seq()}`,
    executionId: `exec_${seq()}`,
    prompt: 'Please approve this action',
    detail: null,
    at: new Date().toISOString() as Timestamp,
    expiresAt: null,
    ...partial,
  };
}

export function aFailure(partial: Partial<ExecutionFailure> = {}): ExecutionFailure {
  return {
    code: 'test-error',
    message: 'A test failure occurred',
    retryable: false,
    ...partial,
  };
}
