import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import {
  createConversationStore,
  createInitialState,
  initialApprovalState,
  initialExecutionState,
} from '../src/state/conversationStore.ts';
import { anEntry, aMissionCard, aFailure } from './mocks.ts';

describe('createInitialState', () => {
  test('has the expected shape', () => {
    const state = createInitialState('conv-1');
    assert.equal(state.conversationId, 'conv-1');
    assert.deepEqual(state.entries, []);
    assert.deepEqual(state.execution, initialExecutionState);
    assert.deepEqual(state.approval, initialApprovalState);
    assert.deepEqual(state.missions, []);
    assert.equal(state.streaming, false);
    assert.equal(state.transportConnected, false);
  });
});

describe('getState', () => {
  test('returns the current state by identity', () => {
    const store = createConversationStore('conv-1');
    const s1 = store.getState();
    const s2 = store.getState();
    assert.equal(s1, s2, 'getState must return the same reference between mutations');
  });
});

describe('subscribe', () => {
  test('fires on state change', () => {
    const store = createConversationStore('conv-1');
    let callCount = 0;
    store.subscribe(() => { callCount++; });
    store.setStreaming(true);
    assert.equal(callCount, 1);
  });

  test('returns working unsubscribe', () => {
    const store = createConversationStore('conv-1');
    let callCount = 0;
    const unsub = store.subscribe(() => { callCount++; });
    store.setStreaming(true);
    assert.equal(callCount, 1);
    unsub();
    store.setStreaming(false);
    assert.equal(callCount, 1, 'listener must not fire after unsubscribe');
  });

  test('double unsubscribe is safe', () => {
    const store = createConversationStore('conv-1');
    const unsub = store.subscribe(() => {});
    assert.equal(store.listenerCount(), 1);
    unsub();
    assert.equal(store.listenerCount(), 0);
    assert.doesNotThrow(() => unsub());
    assert.equal(store.listenerCount(), 0);
  });

  test('listenerCount is accurate', () => {
    const store = createConversationStore('conv-1');
    assert.equal(store.listenerCount(), 0);
    const u1 = store.subscribe(() => {});
    assert.equal(store.listenerCount(), 1);
    const u2 = store.subscribe(() => {});
    assert.equal(store.listenerCount(), 2);
    u1();
    assert.equal(store.listenerCount(), 1);
    u2();
    assert.equal(store.listenerCount(), 0);
  });

  test('multiple listeners all notified', () => {
    const store = createConversationStore('conv-1');
    let a = 0, b = 0, c = 0;
    store.subscribe(() => { a++; });
    store.subscribe(() => { b++; });
    store.subscribe(() => { c++; });
    store.setStreaming(true);
    assert.equal(a, 1);
    assert.equal(b, 1);
    assert.equal(c, 1);
  });
});

describe('immutability', () => {
  test('appendEntry: previous state unchanged, new object identity produced', () => {
    const store = createConversationStore('conv-1');
    const prevState = store.getState();
    const prevEntries = prevState.entries;
    store.appendEntry(anEntry({ text: 'hello' }));
    const nextState = store.getState();
    // Previous state object is unchanged
    assert.equal(prevState.entries, prevEntries, 'prev state entries array unchanged');
    assert.equal(prevState.entries.length, 0, 'prev entries length unchanged');
    // New object identity
    assert.notEqual(nextState, prevState, 'state identity must change');
    assert.notEqual(nextState.entries, prevEntries, 'entries array identity must change');
  });

  test('patchEntry: previous state unchanged after patch', () => {
    const store = createConversationStore('conv-1');
    const entry = anEntry({ text: 'original' });
    store.appendEntry(entry);
    const prevState = store.getState();
    const prevEntry = prevState.entries[0];
    store.patchEntry(entry.id, { text: 'patched' });
    // Previous state object is unchanged
    assert.equal(prevEntry?.text, 'original', 'previous entry text unchanged');
    assert.notEqual(store.getState(), prevState, 'state identity must change');
  });
});

describe('appendEntry', () => {
  test('appends the entry and changes state identity', () => {
    const store = createConversationStore('conv-1');
    const entry = anEntry({ text: 'first' });
    store.appendEntry(entry);
    const state = store.getState();
    assert.equal(state.entries.length, 1);
    assert.equal(state.entries[0]?.id, entry.id);
  });

  test('entries array identity changes on append', () => {
    const store = createConversationStore('conv-1');
    const before = store.getState().entries;
    store.appendEntry(anEntry());
    const after = store.getState().entries;
    assert.notEqual(before, after, 'entries array identity must change on append');
  });
});

describe('patchEntry', () => {
  test('replaces named entry fields', () => {
    const store = createConversationStore('conv-1');
    const entry = anEntry({ text: 'original', streaming: false });
    store.appendEntry(entry);
    store.patchEntry(entry.id, { text: 'patched', streaming: true });
    const patched = store.getState().entries.find(e => e.id === entry.id);
    assert.equal(patched?.text, 'patched');
    assert.equal(patched?.streaming, true);
  });

  test('no-op on unknown id: state identity unchanged and no listener fired', () => {
    const store = createConversationStore('conv-1');
    store.appendEntry(anEntry());
    const prevState = store.getState();
    let called = false;
    store.subscribe(() => { called = true; });
    store.patchEntry('unknown-id', { text: 'changed' });
    assert.equal(store.getState(), prevState, 'state identity unchanged on unknown id');
    assert.equal(called, false, 'listener must not fire on unknown id no-op');
  });
});

describe('appendEntryText', () => {
  test('concatenates text to existing entry', () => {
    const store = createConversationStore('conv-1');
    const entry = anEntry({ text: 'Hello' });
    store.appendEntry(entry);
    store.appendEntryText(entry.id, ' World');
    const updated = store.getState().entries.find(e => e.id === entry.id);
    assert.equal(updated?.text, 'Hello World');
  });

  test('no-op on unknown id', () => {
    const store = createConversationStore('conv-1');
    const prevState = store.getState();
    let called = false;
    store.subscribe(() => { called = true; });
    store.appendEntryText('unknown-id', 'delta');
    assert.equal(store.getState(), prevState, 'state identity unchanged on unknown id');
    assert.equal(called, false, 'listener must not fire on unknown id no-op');
  });
});

describe('removeEntry', () => {
  test('removes existing entry', () => {
    const store = createConversationStore('conv-1');
    const entry = anEntry();
    store.appendEntry(entry);
    assert.equal(store.getState().entries.length, 1);
    store.removeEntry(entry.id);
    assert.equal(store.getState().entries.length, 0);
  });

  test('no-op on unknown id fires no listener', () => {
    const store = createConversationStore('conv-1');
    const prevState = store.getState();
    let called = false;
    store.subscribe(() => { called = true; });
    store.removeEntry('unknown-id');
    assert.equal(store.getState(), prevState, 'state identity unchanged on unknown id');
    assert.equal(called, false, 'listener must not fire on unknown id no-op');
  });
});

describe('execution setters', () => {
  test('setExecutionPhase', () => {
    const store = createConversationStore('conv-1');
    const at = new Date().toISOString();
    store.setExecutionPhase('running', at);
    assert.equal(store.getState().execution.phase, 'running');
    assert.equal(store.getState().execution.since, at);
  });

  test('setExecutionId', () => {
    const store = createConversationStore('conv-1');
    store.setExecutionId('exec-123');
    assert.equal(store.getState().execution.executionId, 'exec-123');
    store.setExecutionId(null);
    assert.equal(store.getState().execution.executionId, null);
  });

  test('setExecutionFailure', () => {
    const store = createConversationStore('conv-1');
    const failure = aFailure({ code: 'my-error' });
    store.setExecutionFailure(failure);
    assert.deepEqual(store.getState().execution.failure, failure);
    store.setExecutionFailure(null);
    assert.equal(store.getState().execution.failure, null);
  });

  test('setCancelRequested', () => {
    const store = createConversationStore('conv-1');
    store.setCancelRequested(true);
    assert.equal(store.getState().execution.cancelRequested, true);
    store.setCancelRequested(false);
    assert.equal(store.getState().execution.cancelRequested, false);
  });

  test('setAttempt', () => {
    const store = createConversationStore('conv-1');
    store.setAttempt(3);
    assert.equal(store.getState().execution.attempt, 3);
  });

  test('resetExecution returns to initial execution state', () => {
    const store = createConversationStore('conv-1');
    store.setExecutionPhase('running', new Date().toISOString());
    store.setExecutionId('exec-123');
    store.resetExecution();
    assert.deepEqual(store.getState().execution, initialExecutionState);
  });
});

describe('approval', () => {
  test('setApproval replaces the approval state', () => {
    const store = createConversationStore('conv-1');
    const approval = {
      approvalId: 'appr-1',
      executionId: 'exec-1',
      decision: 'pending' as const,
      prompt: 'Please confirm',
      detail: null,
      requestedAt: new Date().toISOString(),
      decidedAt: null,
      expiresAt: null,
    };
    store.setApproval(approval);
    assert.deepEqual(store.getState().approval, approval);
  });

  test('setApprovalDecision sets decision and decidedAt', () => {
    const store = createConversationStore('conv-1');
    store.setApproval({
      approvalId: 'appr-1',
      executionId: 'exec-1',
      decision: 'pending',
      prompt: 'confirm?',
      detail: null,
      requestedAt: new Date().toISOString(),
      decidedAt: null,
      expiresAt: null,
    });
    const decidedAt = new Date().toISOString();
    store.setApprovalDecision('approved', decidedAt);
    assert.equal(store.getState().approval.decision, 'approved');
    assert.equal(store.getState().approval.decidedAt, decidedAt);
  });

  test('resetApproval returns to initial approval state', () => {
    const store = createConversationStore('conv-1');
    store.setApproval({
      approvalId: 'appr-1',
      executionId: 'exec-1',
      decision: 'approved',
      prompt: 'q',
      detail: null,
      requestedAt: new Date().toISOString(),
      decidedAt: new Date().toISOString(),
      expiresAt: null,
    });
    store.resetApproval();
    assert.deepEqual(store.getState().approval, initialApprovalState);
  });
});

describe('upsertMission', () => {
  test('inserts when new', () => {
    const store = createConversationStore('conv-1');
    const card = aMissionCard({ ref: 'mission-1', title: 'Alpha' });
    store.upsertMission(card);
    assert.equal(store.getState().missions.length, 1);
    assert.equal(store.getState().missions[0]?.ref, 'mission-1');
  });

  test('replaces in place preserving index order when ref matches', () => {
    const store = createConversationStore('conv-1');
    const c1 = aMissionCard({ ref: 'mission-1', title: 'Alpha', status: 'queued' });
    const c2 = aMissionCard({ ref: 'mission-2', title: 'Beta', status: 'queued' });
    const c3 = aMissionCard({ ref: 'mission-3', title: 'Gamma', status: 'queued' });
    store.upsertMission(c1);
    store.upsertMission(c2);
    store.upsertMission(c3);
    assert.equal(store.getState().missions.length, 3);

    // Update middle card
    const c2Updated = aMissionCard({ ref: 'mission-2', title: 'Beta Updated', status: 'running' });
    store.upsertMission(c2Updated);

    const missions = store.getState().missions;
    assert.equal(missions.length, 3, 'count must stay 3 after update');
    // Order must be preserved: mission-1, mission-2, mission-3
    assert.equal(missions[0]?.ref, 'mission-1', 'first card stays at index 0');
    assert.equal(missions[1]?.ref, 'mission-2', 'updated card stays at index 1');
    assert.equal(missions[2]?.ref, 'mission-3', 'third card stays at index 2');
    assert.equal(missions[1]?.title, 'Beta Updated', 'updated card has new title');
    assert.equal(missions[1]?.status, 'running', 'updated card has new status');
  });
});

describe('removeMission', () => {
  test('removes existing mission', () => {
    const store = createConversationStore('conv-1');
    const card = aMissionCard({ ref: 'mission-1' });
    store.upsertMission(card);
    store.removeMission('mission-1');
    assert.equal(store.getState().missions.length, 0);
  });

  test('unknown ref is a no-op', () => {
    const store = createConversationStore('conv-1');
    store.upsertMission(aMissionCard({ ref: 'mission-1' }));
    const prevState = store.getState();
    let called = false;
    store.subscribe(() => { called = true; });
    store.removeMission('unknown-ref');
    assert.equal(store.getState(), prevState, 'state identity unchanged on unknown ref');
    assert.equal(called, false, 'listener must not fire on unknown ref no-op');
  });
});

describe('flags', () => {
  test('setStreaming', () => {
    const store = createConversationStore('conv-1');
    store.setStreaming(true);
    assert.equal(store.getState().streaming, true);
    store.setStreaming(false);
    assert.equal(store.getState().streaming, false);
  });

  test('setTransportConnected', () => {
    const store = createConversationStore('conv-1');
    store.setTransportConnected(true);
    assert.equal(store.getState().transportConnected, true);
    store.setTransportConnected(false);
    assert.equal(store.getState().transportConnected, false);
  });
});

describe('lifecycle', () => {
  test('reset returns to initial state but keeps conversationId', () => {
    const store = createConversationStore('conv-xyz');
    store.appendEntry(anEntry());
    store.setStreaming(true);
    store.setTransportConnected(true);
    store.setExecutionPhase('running', new Date().toISOString());
    store.reset();
    const state = store.getState();
    assert.equal(state.conversationId, 'conv-xyz', 'conversationId preserved after reset');
    assert.equal(state.entries.length, 0);
    assert.equal(state.streaming, false);
    assert.equal(state.transportConnected, false);
    assert.deepEqual(state.execution, initialExecutionState);
    assert.deepEqual(state.approval, initialApprovalState);
  });

  test('hydrate replaces state wholesale', () => {
    const store = createConversationStore('conv-1');
    const freshState = createInitialState('conv-hydrated');
    store.hydrate(freshState);
    assert.equal(store.getState(), freshState);
    assert.equal(store.getState().conversationId, 'conv-hydrated');
  });
});
