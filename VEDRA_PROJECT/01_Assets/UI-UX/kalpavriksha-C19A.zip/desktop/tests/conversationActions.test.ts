import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import {
  createConversationActions,
  applyRuntimeEvent,
} from '../src/hooks/conversationActions.ts';
import { createConversationStore } from '../src/state/conversationStore.ts';
import { createMockRuntimeClient, anEntry, aMissionCard, aFailure } from './mocks.ts';
import type { KernelResponse, RuntimeEvent } from '../src/types/execution.ts';

function makeStore(id = 'conv-1') {
  return createConversationStore(id);
}

/* ══════════════════════════════════════════════════════════════════
   send
══════════════════════════════════════════════════════════════════ */

describe('send', () => {
  test('appends a user entry with role:user and the exact text', async () => {
    const store = makeStore();
    const client = createMockRuntimeClient();
    const actions = createConversationActions({ store, client });
    await actions.send('Hello World');
    const entries = store.getState().entries;
    const userEntries = entries.filter(e => e.role === 'user');
    assert.equal(userEntries.length, 1);
    assert.equal(userEntries[0]?.text, 'Hello World');
  });

  test('sets phase to dispatching before the call resolves (phase is dispatching while in-flight)', async () => {
    const store = makeStore();
    let phaseBeforeResolve: string | undefined;
    // We capture phase inside a client that checks just before resolving
    const client = createMockRuntimeClient();
    const origSend = client.send.bind(client);
    (client as { send: typeof client.send }).send = async (req) => {
      phaseBeforeResolve = store.getState().execution.phase;
      return origSend(req);
    };
    await createConversationActions({ store, client }).send('hi');
    assert.equal(phaseBeforeResolve, 'dispatching');
  });

  test('passes conversationId, text and a clientEntryId to client.send', async () => {
    const store = makeStore('my-conv');
    const client = createMockRuntimeClient();
    const actions = createConversationActions({ store, client });
    await actions.send('Test message');
    assert.equal(client.calls.send.length, 1);
    const req = client.calls.send[0]!;
    assert.equal(req.conversationId, 'my-conv');
    assert.equal(req.text, 'Test message');
    assert.ok(req.clientEntryId.length > 0, 'clientEntryId must be non-empty');
  });

  test('on not-wired: phase returns to idle', async () => {
    const store = makeStore();
    const client = createMockRuntimeClient(); // default: not-wired
    const actions = createConversationActions({ store, client });
    await actions.send('hi');
    assert.equal(store.getState().execution.phase, 'idle');
  });

  test('on not-wired: a system entry carrying the reason is appended', async () => {
    const store = makeStore();
    const client = createMockRuntimeClient();
    const actions = createConversationActions({ store, client });
    await actions.send('hi');
    const sysEntries = store.getState().entries.filter(e => e.role === 'system');
    assert.equal(sysEntries.length, 1);
    assert.ok((sysEntries[0]?.text ?? '').length > 0, 'system entry text must carry a reason');
  });

  test('NEVER FABRICATE AI TEXT: on not-wired, no entry with role:assistant is ever created', async () => {
    const store = makeStore();
    const client = createMockRuntimeClient(); // default: not-wired
    const actions = createConversationActions({ store, client });
    await actions.send('hello');
    const assistantEntries = store.getState().entries.filter(e => e.role === 'assistant');
    assert.equal(
      assistantEntries.length,
      0,
      'adapter must NEVER create an assistant entry — it cannot fabricate AI text',
    );
  });

  test('on ok: executionId is stored', async () => {
    const store = makeStore();
    const client = createMockRuntimeClient({
      send: { kind: 'ok', value: { executionId: 'exec-999' }, executionId: 'exec-999' },
    });
    const actions = createConversationActions({ store, client });
    await actions.send('hi');
    assert.equal(store.getState().execution.executionId, 'exec-999');
  });

  test('on ok: phase is NOT advanced past dispatching by the adapter (runtime owns later phases)', async () => {
    const store = makeStore();
    const client = createMockRuntimeClient({
      send: { kind: 'ok', value: { executionId: 'exec-999' }, executionId: 'exec-999' },
    });
    const actions = createConversationActions({ store, client });
    await actions.send('hi');
    assert.equal(
      store.getState().execution.phase,
      'dispatching',
      'phase must stay at dispatching after ok — the runtime owns phase transitions past this point',
    );
  });

  test('on failed: failure recorded and phase is failed', async () => {
    const store = makeStore();
    const failure = aFailure({ code: 'transport-error' });
    const client = createMockRuntimeClient({
      send: { kind: 'failed', failure, executionId: null },
    });
    const actions = createConversationActions({ store, client });
    await actions.send('hi');
    assert.equal(store.getState().execution.phase, 'failed');
    assert.deepEqual(store.getState().execution.failure, failure);
  });
});

/* ══════════════════════════════════════════════════════════════════
   approve
══════════════════════════════════════════════════════════════════ */

describe('approve', () => {
  function storeWithOpenApproval() {
    const store = makeStore();
    store.setApproval({
      approvalId: 'appr-1',
      executionId: 'exec-1',
      decision: 'pending',
      prompt: 'confirm?',
      detail: null,
      requestedAt: new Date().toISOString(),
      decidedAt: null,
      expiresAt: null,
    });
    return store;
  }

  test('with no open approval: resolves failed with code no-open-approval, client not called', async () => {
    const store = makeStore(); // no approval set
    const client = createMockRuntimeClient();
    const actions = createConversationActions({ store, client });
    const res = await actions.approve();
    assert.equal(res.kind, 'failed');
    if (res.kind === 'failed') {
      assert.equal(res.failure.code, 'no-open-approval');
    }
    assert.equal(client.calls.submitApproval.length, 0, 'client must not be called with no open approval');
  });

  test('with open approval and ok: decision becomes approved and decidedAt is set', async () => {
    const store = storeWithOpenApproval();
    const client = createMockRuntimeClient({
      submitApproval: { kind: 'ok', value: { accepted: true }, executionId: 'exec-1' },
    });
    const actions = createConversationActions({ store, client });
    await actions.approve();
    assert.equal(store.getState().approval.decision, 'approved');
    assert.ok(store.getState().approval.decidedAt !== null, 'decidedAt should be set');
  });

  test('note argument is forwarded when provided', async () => {
    const store = storeWithOpenApproval();
    const client = createMockRuntimeClient({
      submitApproval: { kind: 'ok', value: { accepted: true }, executionId: 'exec-1' },
    });
    const actions = createConversationActions({ store, client });
    await actions.approve('my note');
    const req = client.calls.submitApproval[0]!;
    assert.equal(req.note, 'my note');
  });

  test('note property is ABSENT (not undefined) when omitted — exactOptionalPropertyTypes', async () => {
    const store = storeWithOpenApproval();
    const client = createMockRuntimeClient({
      submitApproval: { kind: 'ok', value: { accepted: true }, executionId: 'exec-1' },
    });
    const actions = createConversationActions({ store, client });
    await actions.approve(); // no note
    const req = client.calls.submitApproval[0]!;
    assert.equal(
      Object.hasOwn(req, 'note'),
      false,
      'note property must be absent (not just undefined) when not passed',
    );
  });

  test('on not-wired: decision stays pending and a system entry is appended', async () => {
    const store = storeWithOpenApproval();
    const client = createMockRuntimeClient(); // default: not-wired
    const actions = createConversationActions({ store, client });
    await actions.approve();
    assert.equal(store.getState().approval.decision, 'pending');
    const sysEntries = store.getState().entries.filter(e => e.role === 'system');
    assert.equal(sysEntries.length, 1);
  });
});

/* ══════════════════════════════════════════════════════════════════
   reject
══════════════════════════════════════════════════════════════════ */

describe('reject', () => {
  function storeWithOpenApproval() {
    const store = makeStore();
    store.setApproval({
      approvalId: 'appr-1',
      executionId: 'exec-1',
      decision: 'pending',
      prompt: 'confirm?',
      detail: null,
      requestedAt: new Date().toISOString(),
      decidedAt: null,
      expiresAt: null,
    });
    return store;
  }

  test('with no open approval: resolves failed with code no-open-approval, client not called', async () => {
    const store = makeStore();
    const client = createMockRuntimeClient();
    const actions = createConversationActions({ store, client });
    const res = await actions.reject();
    assert.equal(res.kind, 'failed');
    if (res.kind === 'failed') {
      assert.equal(res.failure.code, 'no-open-approval');
    }
    assert.equal(client.calls.submitApproval.length, 0);
  });

  test('with open approval and ok: decision becomes rejected and decidedAt is set', async () => {
    const store = storeWithOpenApproval();
    const client = createMockRuntimeClient({
      submitApproval: { kind: 'ok', value: { accepted: true }, executionId: 'exec-1' },
    });
    const actions = createConversationActions({ store, client });
    await actions.reject();
    assert.equal(store.getState().approval.decision, 'rejected');
    assert.ok(store.getState().approval.decidedAt !== null, 'decidedAt should be set');
  });

  test('note argument is forwarded when provided', async () => {
    const store = storeWithOpenApproval();
    const client = createMockRuntimeClient({
      submitApproval: { kind: 'ok', value: { accepted: true }, executionId: 'exec-1' },
    });
    const actions = createConversationActions({ store, client });
    await actions.reject('my rejection note');
    const req = client.calls.submitApproval[0]!;
    assert.equal(req.note, 'my rejection note');
  });

  test('note property is ABSENT (not undefined) when omitted — exactOptionalPropertyTypes', async () => {
    const store = storeWithOpenApproval();
    const client = createMockRuntimeClient({
      submitApproval: { kind: 'ok', value: { accepted: true }, executionId: 'exec-1' },
    });
    const actions = createConversationActions({ store, client });
    await actions.reject(); // no note
    const req = client.calls.submitApproval[0]!;
    assert.equal(
      Object.hasOwn(req, 'note'),
      false,
      'note property must be absent when not passed',
    );
  });

  test('on not-wired: decision stays pending and a system entry is appended', async () => {
    const store = storeWithOpenApproval();
    const client = createMockRuntimeClient();
    const actions = createConversationActions({ store, client });
    await actions.reject();
    assert.equal(store.getState().approval.decision, 'pending');
    const sysEntries = store.getState().entries.filter(e => e.role === 'system');
    assert.equal(sysEntries.length, 1);
  });
});

/* ══════════════════════════════════════════════════════════════════
   cancel
══════════════════════════════════════════════════════════════════ */

describe('cancel', () => {
  test('with no executionId: resolves failed with code nothing-running, client not called', async () => {
    const store = makeStore();
    const client = createMockRuntimeClient();
    const actions = createConversationActions({ store, client });
    const res = await actions.cancel();
    assert.equal(res.kind, 'failed');
    if (res.kind === 'failed') {
      assert.equal(res.failure.code, 'nothing-running');
    }
    assert.equal(client.calls.cancel.length, 0);
  });

  test('with executionId: sets cancelRequested:true and phase cancelling, calls the client', async () => {
    const store = makeStore();
    store.setExecutionId('exec-1');
    store.setExecutionPhase('running', new Date().toISOString());
    const client = createMockRuntimeClient({
      cancel: { kind: 'ok', value: { requested: true }, executionId: 'exec-1' },
    });
    const actions = createConversationActions({ store, client });
    await actions.cancel();
    assert.equal(store.getState().execution.cancelRequested, true);
    assert.equal(store.getState().execution.phase, 'cancelling');
    assert.equal(client.calls.cancel.length, 1);
  });

  test('on not-wired: restores the prior phase and clears cancelRequested', async () => {
    const store = makeStore();
    store.setExecutionId('exec-1');
    store.setExecutionPhase('running', new Date().toISOString());
    // Confirm prior phase is "running", not "idle"
    assert.equal(store.getState().execution.phase, 'running');

    const client = createMockRuntimeClient(); // default: not-wired
    const actions = createConversationActions({ store, client });
    await actions.cancel();

    assert.equal(
      store.getState().execution.phase,
      'running',
      'prior phase (running) must be restored after not-wired cancel',
    );
    assert.equal(store.getState().execution.cancelRequested, false, 'cancelRequested must be cleared');
  });

  test('on ok: phase stays cancelling (runtime confirms via event, adapter does not self-declare)', async () => {
    const store = makeStore();
    store.setExecutionId('exec-1');
    store.setExecutionPhase('running', new Date().toISOString());
    const client = createMockRuntimeClient({
      cancel: { kind: 'ok', value: { requested: true }, executionId: 'exec-1' },
    });
    const actions = createConversationActions({ store, client });
    await actions.cancel();
    assert.equal(
      store.getState().execution.phase,
      'cancelling',
      'phase must stay cancelling after ok — runtime confirms cancellation, not the adapter',
    );
  });
});

/* ══════════════════════════════════════════════════════════════════
   retry
══════════════════════════════════════════════════════════════════ */

describe('retry', () => {
  test('with no executionId: resolves failed with code nothing-to-retry', async () => {
    const store = makeStore();
    const client = createMockRuntimeClient();
    const actions = createConversationActions({ store, client });
    const res = await actions.retry();
    assert.equal(res.kind, 'failed');
    if (res.kind === 'failed') {
      assert.equal(res.failure.code, 'nothing-to-retry');
    }
  });

  test('increments attempt by exactly 1 each call', async () => {
    const store = makeStore();
    store.setExecutionId('exec-1');
    assert.equal(store.getState().execution.attempt, 0);
    const client = createMockRuntimeClient({
      retry: { kind: 'ok', value: { executionId: 'exec-new' }, executionId: 'exec-new' },
    });
    const actions = createConversationActions({ store, client });

    await actions.retry();
    assert.equal(store.getState().execution.attempt, 1);

    // Need to set executionId again since retry set it to exec-new
    await actions.retry();
    assert.equal(store.getState().execution.attempt, 2);
  });

  test('clears the previous failure and sets phase dispatching', async () => {
    const store = makeStore();
    store.setExecutionId('exec-1');
    store.setExecutionFailure(aFailure({ code: 'prev-error' }));
    store.setExecutionPhase('failed', new Date().toISOString());
    const client = createMockRuntimeClient({
      retry: { kind: 'ok', value: { executionId: 'exec-new' }, executionId: 'exec-new' },
    });
    const actions = createConversationActions({ store, client });
    await actions.retry();
    assert.equal(store.getState().execution.failure, null);
    assert.equal(store.getState().execution.phase, 'dispatching');
  });

  test('on ok: new executionId stored', async () => {
    const store = makeStore();
    store.setExecutionId('exec-old');
    const client = createMockRuntimeClient({
      retry: { kind: 'ok', value: { executionId: 'exec-new' }, executionId: 'exec-new' },
    });
    const actions = createConversationActions({ store, client });
    await actions.retry();
    assert.equal(store.getState().execution.executionId, 'exec-new');
  });

  test('on not-wired: phase set to failed and system entry appended', async () => {
    const store = makeStore();
    store.setExecutionId('exec-1');
    const client = createMockRuntimeClient(); // default: not-wired
    const actions = createConversationActions({ store, client });
    await actions.retry();
    assert.equal(store.getState().execution.phase, 'failed');
    const sysEntries = store.getState().entries.filter(e => e.role === 'system');
    assert.equal(sysEntries.length, 1);
  });
});

/* ══════════════════════════════════════════════════════════════════
   onResponse callback
══════════════════════════════════════════════════════════════════ */

describe('onResponse callback', () => {
  test('fires exactly once per send action with the same envelope returned', async () => {
    const store = makeStore();
    const client = createMockRuntimeClient();
    const responses: KernelResponse<unknown>[] = [];
    const actions = createConversationActions({
      store,
      client,
      onResponse: (res) => responses.push(res),
    });
    const returned = await actions.send('hi');
    assert.equal(responses.length, 1);
    assert.equal(responses[0], returned, 'onResponse must receive the same envelope that is returned');
  });

  test('fires exactly once per approve action', async () => {
    const store = makeStore();
    store.setApproval({
      approvalId: 'appr-1',
      executionId: 'exec-1',
      decision: 'pending',
      prompt: 'q',
      detail: null,
      requestedAt: new Date().toISOString(),
      decidedAt: null,
      expiresAt: null,
    });
    const client = createMockRuntimeClient({
      submitApproval: { kind: 'ok', value: { accepted: true }, executionId: 'exec-1' },
    });
    const responses: KernelResponse<unknown>[] = [];
    const actions = createConversationActions({
      store,
      client,
      onResponse: (res) => responses.push(res),
    });
    const returned = await actions.approve();
    assert.equal(responses.length, 1);
    assert.equal(responses[0], returned);
  });

  test('fires exactly once per cancel action', async () => {
    const store = makeStore();
    store.setExecutionId('exec-1');
    const client = createMockRuntimeClient({
      cancel: { kind: 'ok', value: { requested: true }, executionId: 'exec-1' },
    });
    const responses: KernelResponse<unknown>[] = [];
    const actions = createConversationActions({
      store,
      client,
      onResponse: (res) => responses.push(res),
    });
    const returned = await actions.cancel();
    assert.equal(responses.length, 1);
    assert.equal(responses[0], returned);
  });

  test('fires exactly once per retry action', async () => {
    const store = makeStore();
    store.setExecutionId('exec-1');
    const client = createMockRuntimeClient({
      retry: { kind: 'ok', value: { executionId: 'exec-2' }, executionId: 'exec-2' },
    });
    const responses: KernelResponse<unknown>[] = [];
    const actions = createConversationActions({
      store,
      client,
      onResponse: (res) => responses.push(res),
    });
    const returned = await actions.retry();
    assert.equal(responses.length, 1);
    assert.equal(responses[0], returned);
  });
});

/* ══════════════════════════════════════════════════════════════════
   applyRuntimeEvent
══════════════════════════════════════════════════════════════════ */

describe('applyRuntimeEvent', () => {
  test('execution.phase: sets executionId and phase', () => {
    const store = makeStore();
    const at = new Date().toISOString();
    const event: RuntimeEvent = {
      type: 'execution.phase',
      executionId: 'exec-42',
      phase: 'running',
      at,
    };
    applyRuntimeEvent(store, event);
    assert.equal(store.getState().execution.executionId, 'exec-42');
    assert.equal(store.getState().execution.phase, 'running');
    assert.equal(store.getState().execution.since, at);
  });

  test('execution.delta: appends to the right entry only', () => {
    const store = makeStore();
    const entry1 = anEntry({ id: 'e-1', text: 'Hello' });
    const entry2 = anEntry({ id: 'e-2', text: 'World' });
    store.appendEntry(entry1);
    store.appendEntry(entry2);

    const event: RuntimeEvent = {
      type: 'execution.delta',
      executionId: 'exec-1',
      entryId: 'e-1',
      delta: ' delta',
    };
    applyRuntimeEvent(store, event);
    const entries = store.getState().entries;
    assert.equal(entries.find(e => e.id === 'e-1')?.text, 'Hello delta');
    assert.equal(entries.find(e => e.id === 'e-2')?.text, 'World', 'other entry unchanged');
  });

  test('execution.failed: sets failure and phase failed', () => {
    const store = makeStore();
    const failure = aFailure({ code: 'runtime-err' });
    const at = new Date().toISOString();
    const event: RuntimeEvent = {
      type: 'execution.failed',
      executionId: 'exec-1',
      failure,
      at,
    };
    applyRuntimeEvent(store, event);
    assert.deepEqual(store.getState().execution.failure, failure);
    assert.equal(store.getState().execution.phase, 'failed');
    assert.equal(store.getState().execution.since, at);
  });

  test('approval.requested: populates all approval fields AND sets phase awaiting-approval', () => {
    const store = makeStore();
    const at = new Date().toISOString();
    const expiresAt = new Date(Date.now() + 60000).toISOString();
    const event: RuntimeEvent = {
      type: 'approval.requested',
      approvalId: 'appr-1',
      executionId: 'exec-1',
      prompt: 'Please confirm this critical action',
      detail: { action: 'delete', target: 'resource-xyz' },
      at,
      expiresAt,
    };
    applyRuntimeEvent(store, event);
    const approval = store.getState().approval;
    assert.equal(approval.approvalId, 'appr-1');
    assert.equal(approval.executionId, 'exec-1');
    assert.equal(approval.decision, 'pending');
    assert.equal(approval.prompt, 'Please confirm this critical action');
    assert.deepEqual(approval.detail, { action: 'delete', target: 'resource-xyz' });
    assert.equal(approval.requestedAt, at);
    assert.equal(approval.decidedAt, null);
    assert.equal(approval.expiresAt, expiresAt);
    assert.equal(store.getState().execution.phase, 'awaiting-approval');
  });

  test('approval.resolved: sets decision and decidedAt', () => {
    const store = makeStore();
    const at = new Date().toISOString();
    store.setApproval({
      approvalId: 'appr-1',
      executionId: 'exec-1',
      decision: 'pending',
      prompt: 'q',
      detail: null,
      requestedAt: at,
      decidedAt: null,
      expiresAt: null,
    });
    const resolvedAt = new Date().toISOString();
    const event: RuntimeEvent = {
      type: 'approval.resolved',
      approvalId: 'appr-1',
      decision: 'approved',
      at: resolvedAt,
    };
    applyRuntimeEvent(store, event);
    assert.equal(store.getState().approval.decision, 'approved');
    assert.equal(store.getState().approval.decidedAt, resolvedAt);
  });

  test('mission.updated: inserts a new card', () => {
    const store = makeStore();
    const card = aMissionCard({ ref: 'mission-1', title: 'My Mission' });
    const event: RuntimeEvent = { type: 'mission.updated', card };
    applyRuntimeEvent(store, event);
    assert.equal(store.getState().missions.length, 1);
    assert.equal(store.getState().missions[0]?.ref, 'mission-1');
  });

  test('mission.updated: replaces an existing card', () => {
    const store = makeStore();
    const card1 = aMissionCard({ ref: 'mission-1', title: 'Original', status: 'queued' });
    store.upsertMission(card1);
    const card2 = aMissionCard({ ref: 'mission-1', title: 'Updated', status: 'running' });
    const event: RuntimeEvent = { type: 'mission.updated', card: card2 };
    applyRuntimeEvent(store, event);
    assert.equal(store.getState().missions.length, 1);
    assert.equal(store.getState().missions[0]?.title, 'Updated');
    assert.equal(store.getState().missions[0]?.status, 'running');
  });

  test('transport.status: sets transportConnected', () => {
    const store = makeStore();
    const at = new Date().toISOString();
    applyRuntimeEvent(store, { type: 'transport.status', connected: true, at });
    assert.equal(store.getState().transportConnected, true);
    applyRuntimeEvent(store, { type: 'transport.status', connected: false, at });
    assert.equal(store.getState().transportConnected, false);
  });
});
