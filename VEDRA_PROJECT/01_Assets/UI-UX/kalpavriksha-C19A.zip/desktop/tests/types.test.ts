import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { TERMINAL_PHASES, TERMINOLOGY_RECONCILIATION } from '../src/types/execution.ts';

describe('TERMINAL_PHASES', () => {
  test('contains exactly cancelled, succeeded, and failed', () => {
    const phases = [...TERMINAL_PHASES];
    assert.equal(phases.length, 3, 'must have exactly 3 terminal phases');
    assert.ok(phases.includes('cancelled'), 'must include "cancelled"');
    assert.ok(phases.includes('succeeded'), 'must include "succeeded"');
    assert.ok(phases.includes('failed'), 'must include "failed"');
  });
});

describe('TERMINOLOGY_RECONCILIATION', () => {
  test('is non-empty (guards against quiet deletion of grounding disclosure)', () => {
    assert.ok(TERMINOLOGY_RECONCILIATION.length > 0, 'TERMINOLOGY_RECONCILIATION must not be empty');
  });

  test('every entry has non-empty assumed and question strings', () => {
    for (const entry of TERMINOLOGY_RECONCILIATION) {
      assert.ok(
        typeof entry.assumed === 'string' && entry.assumed.length > 0,
        `entry.assumed must be a non-empty string, got: ${JSON.stringify(entry.assumed)}`,
      );
      assert.ok(
        typeof entry.question === 'string' && entry.question.length > 0,
        `entry.question must be a non-empty string, got: ${JSON.stringify(entry.question)}`,
      );
    }
  });
});
