import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import {
  createRuntimeClient,
  isBridgeAvailable,
  describeBridge,
} from '../src/services/runtimeClient.ts';
import type { RuntimeBridge } from '../src/services/runtimeClient.ts';

describe('createRuntimeClient', () => {
  test('returns kind:stub and wired:false', () => {
    const client = createRuntimeClient();
    assert.equal(client.kind, 'stub');
    assert.equal(client.wired, false);
  });

  test('send resolves to kind:not-wired with method "send"', async () => {
    const client = createRuntimeClient();
    const res = await client.send({ conversationId: 'c1', text: 'hello', clientEntryId: 'e1' });
    assert.equal(res.kind, 'not-wired');
    if (res.kind === 'not-wired') {
      assert.equal(res.method, 'send');
      assert.ok(res.reason.length > 0, 'reason should be non-empty');
    }
  });

  test('submitApproval resolves to kind:not-wired with method "submitApproval"', async () => {
    const client = createRuntimeClient();
    const res = await client.submitApproval({
      approvalId: 'a1',
      executionId: 'e1',
      approved: true,
    });
    assert.equal(res.kind, 'not-wired');
    if (res.kind === 'not-wired') {
      assert.equal(res.method, 'submitApproval');
      assert.ok(res.reason.length > 0, 'reason should be non-empty');
    }
  });

  test('cancel resolves to kind:not-wired with method "cancel"', async () => {
    const client = createRuntimeClient();
    const res = await client.cancel({ executionId: 'e1' });
    assert.equal(res.kind, 'not-wired');
    if (res.kind === 'not-wired') {
      assert.equal(res.method, 'cancel');
      assert.ok(res.reason.length > 0, 'reason should be non-empty');
    }
  });

  test('retry resolves to kind:not-wired with method "retry"', async () => {
    const client = createRuntimeClient();
    const res = await client.retry({ executionId: 'e1', attempt: 1 });
    assert.equal(res.kind, 'not-wired');
    if (res.kind === 'not-wired') {
      assert.equal(res.method, 'retry');
      assert.ok(res.reason.length > 0, 'reason should be non-empty');
    }
  });

  test('no async method throws', async () => {
    const client = createRuntimeClient();
    await assert.doesNotReject(() =>
      client.send({ conversationId: 'c1', text: 'hi', clientEntryId: 'e1' }),
    );
    await assert.doesNotReject(() =>
      client.submitApproval({ approvalId: 'a1', executionId: 'e1', approved: true }),
    );
    await assert.doesNotReject(() => client.cancel({ executionId: 'e1' }));
    await assert.doesNotReject(() => client.retry({ executionId: 'e1', attempt: 1 }));
  });

  test('subscribe registers a listener and listenerCount reflects it', () => {
    const client = createRuntimeClient();
    assert.equal(client.listenerCount(), 0);
    const unsub = client.subscribe(() => {});
    assert.equal(client.listenerCount(), 1);
    unsub();
    assert.equal(client.listenerCount(), 0);
  });

  test('calling unsubscribe twice is safe and does not double-decrement', () => {
    const client = createRuntimeClient();
    const unsub = client.subscribe(() => {});
    assert.equal(client.listenerCount(), 1);
    unsub();
    assert.equal(client.listenerCount(), 0);
    // Second call must not throw and must not underflow
    assert.doesNotThrow(() => unsub());
    assert.equal(client.listenerCount(), 0);
  });

  test('dispose clears listeners', () => {
    const client = createRuntimeClient();
    client.subscribe(() => {});
    client.subscribe(() => {});
    assert.equal(client.listenerCount(), 2);
    client.dispose();
    assert.equal(client.listenerCount(), 0);
  });

  test('subscribe after dispose returns a no-op function and does not register', () => {
    const client = createRuntimeClient();
    client.dispose();
    const unsub = client.subscribe(() => {});
    assert.equal(client.listenerCount(), 0);
    // Calling the returned no-op must not throw
    assert.doesNotThrow(() => unsub());
    assert.equal(client.listenerCount(), 0);
  });
});

describe('isBridgeAvailable', () => {
  test('returns false when globalThis.__KALPA_RUNTIME_BRIDGE__ is undefined', () => {
    // Ensure it's not set
    const prev = globalThis.__KALPA_RUNTIME_BRIDGE__;
    try {
      globalThis.__KALPA_RUNTIME_BRIDGE__ = undefined;
      assert.equal(isBridgeAvailable(), false);
    } finally {
      globalThis.__KALPA_RUNTIME_BRIDGE__ = prev;
    }
  });

  test('returns true when globalThis.__KALPA_RUNTIME_BRIDGE__ is set', () => {
    const prev = globalThis.__KALPA_RUNTIME_BRIDGE__;
    try {
      const mockBridge: RuntimeBridge = {
        execute: async () => ({}),
      };
      globalThis.__KALPA_RUNTIME_BRIDGE__ = mockBridge;
      assert.equal(isBridgeAvailable(), true);
    } finally {
      globalThis.__KALPA_RUNTIME_BRIDGE__ = prev;
    }
  });
});

describe('describeBridge', () => {
  test('reports wired:false when bridge is absent', () => {
    const prev = globalThis.__KALPA_RUNTIME_BRIDGE__;
    try {
      globalThis.__KALPA_RUNTIME_BRIDGE__ = undefined;
      const result = describeBridge();
      assert.equal(result.wired, false);
      assert.equal(result.present, false);
      assert.ok(result.note.length > 0, 'should have a note');
    } finally {
      globalThis.__KALPA_RUNTIME_BRIDGE__ = prev;
    }
  });

  test('reports wired:false even when bridge is present — honesty rule must not silently regress', () => {
    const prev = globalThis.__KALPA_RUNTIME_BRIDGE__;
    try {
      const mockBridge: RuntimeBridge = {
        execute: async () => ({}),
      };
      globalThis.__KALPA_RUNTIME_BRIDGE__ = mockBridge;
      const result = describeBridge();
      // EXPLICIT: a present bridge must still report wired:false
      assert.equal(result.wired, false, 'present bridge must still report wired:false (honesty rule)');
      assert.equal(result.present, true);
      assert.ok(result.note.length > 0, 'should have a note');
    } finally {
      globalThis.__KALPA_RUNTIME_BRIDGE__ = prev;
    }
  });

  test('note differs between absent and present bridge', () => {
    const prev = globalThis.__KALPA_RUNTIME_BRIDGE__;
    let noteAbsent: string;
    let notePresent: string;
    try {
      globalThis.__KALPA_RUNTIME_BRIDGE__ = undefined;
      noteAbsent = describeBridge().note;

      const mockBridge: RuntimeBridge = { execute: async () => ({}) };
      globalThis.__KALPA_RUNTIME_BRIDGE__ = mockBridge;
      notePresent = describeBridge().note;
    } finally {
      globalThis.__KALPA_RUNTIME_BRIDGE__ = prev;
    }
    assert.notEqual(noteAbsent, notePresent, 'note should differ between absent and present bridge');
  });

  test('injected bridge via createRuntimeClient still yields wired:false and not-wired responses', async () => {
    const mockBridge: RuntimeBridge = { execute: async () => ({}) };
    const client = createRuntimeClient({ bridge: mockBridge });
    assert.equal(client.wired, false);
    const res = await client.send({ conversationId: 'c1', text: 'hi', clientEntryId: 'e1' });
    assert.equal(res.kind, 'not-wired');
  });
});
