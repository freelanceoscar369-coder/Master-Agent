/**
 * C19A · runtimeClient — transport adapter for the Runtime Bridge.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHAT THIS IS
 * The single seam through which the desktop UI will reach
 * `KernelRuntime.execute()` via the Runtime Bridge.
 *
 * WHAT THIS IS NOT
 * · Not business logic. It decides nothing.
 * · Not execution logic. It runs nothing.
 * · Not AI logic. It never composes assistant text, never summarises, never
 *   infers intent.
 * It marshals a request out and an envelope back. That is all it will ever do,
 * even after C19 lands.
 *
 * CURRENT STATE — STUB
 * The Runtime Bridge is not available to this module and has not been
 * inspected. Every public method therefore returns
 * `{ kind: 'not-wired' }` and performs no I/O whatsoever.
 *
 * `not-wired` is deliberately NOT an error. An error invites a retry loop and
 * a red banner; `not-wired` is a factual statement the UI is expected to
 * render honestly ("this isn't connected yet") rather than disguise as an
 * empty result. The distinction is the whole point of the stub.
 * ═══════════════════════════════════════════════════════════════════════════
 */

import type {
  ApprovalVerdictRequest,
  CancelRequest,
  ExecutionId,
  KernelResponse,
  RetryRequest,
  RuntimeEvent,
  SendRequest,
} from '../types/execution.ts';

/* ─────────────────────────── bridge surface ───────────────────────────── */

/**
 * The shape this client expects the Runtime Bridge to expose.
 *
 * PROVISIONAL — derived from the brief's statement that the client will "later
 * call KernelRuntime.execute() through the Runtime Bridge". The real bridge
 * has not been inspected. Declared here rather than imported so that this
 * module compiles and tests with no dependency on the runtime, which is the
 * C19A constraint.
 *
 * When C19 lands: replace this declaration with the real import, delete the
 * detection code below, and implement the five methods. No other file changes.
 */
export interface RuntimeBridge {
  execute(payload: unknown): Promise<unknown>;
  subscribe?(listener: (event: unknown) => void): () => void;
}

declare global {
  // eslint-disable-next-line no-var
  var __KALPA_RUNTIME_BRIDGE__: RuntimeBridge | undefined;
}

/**
 * Reports whether a Runtime Bridge is present in this process.
 *
 * Detection only — this function never calls the bridge. It exists so the UI
 * can state its own connectivity truthfully in the status bar instead of
 * inferring it from a failed call.
 *
 * @returns true when a bridge object is reachable, false otherwise.
 */
export function isBridgeAvailable(): boolean {
  return typeof globalThis.__KALPA_RUNTIME_BRIDGE__ !== 'undefined';
}

/* ───────────────────────────── the client ─────────────────────────────── */

export interface RuntimeClient {
  /** Discriminator so callers and tests can assert which implementation is live. */
  readonly kind: 'stub' | 'bridge';

  /**
   * Whether this client can actually reach the runtime.
   * Always false for the stub.
   */
  readonly wired: boolean;

  /**
   * Dispatch a founder message for execution.
   *
   * Transport only: the text is passed through verbatim. This method does not
   * validate it, does not enrich it, and does not decide whether the runtime
   * should act on it.
   *
   * @param req  conversation id, the raw text, and a client-generated entry id
   *             the runtime is expected to echo back for correlation.
   * @returns    an envelope carrying the runtime's execution id, or `not-wired`.
   */
  send(req: SendRequest): Promise<KernelResponse<{ readonly executionId: ExecutionId }>>;

  /**
   * Return a founder verdict on a runtime-initiated approval.
   *
   * The client does not evaluate the approval, does not enforce policy, and
   * does not know what is being approved. It carries a boolean and an optional
   * note.
   *
   * @param req  approval id, execution id, the verdict, and an optional note.
   * @returns    acknowledgement envelope, or `not-wired`.
   */
  submitApproval(req: ApprovalVerdictRequest): Promise<KernelResponse<{ readonly accepted: true }>>;

  /**
   * Request cancellation of an in-flight execution.
   *
   * Requests only. The runtime decides whether cancellation is possible and
   * confirms it via an event; this method returning `ok` means the request was
   * delivered, never that the execution stopped.
   *
   * @param req  the execution to cancel.
   * @returns    delivery acknowledgement, or `not-wired`.
   */
  cancel(req: CancelRequest): Promise<KernelResponse<{ readonly requested: true }>>;

  /**
   * Ask the runtime to retry a failed execution.
   *
   * No backoff, no attempt limit, no retryability judgement — all three belong
   * to the runtime or to the integration layer above this one. The `attempt`
   * counter is passed through for correlation only.
   *
   * @param req  the execution and the attempt number.
   * @returns    an envelope carrying the new execution id, or `not-wired`.
   */
  retry(req: RetryRequest): Promise<KernelResponse<{ readonly executionId: ExecutionId }>>;

  /**
   * Subscribe to runtime events.
   *
   * The stub registers the listener, never invokes it, and returns a working
   * unsubscribe. That is intentional: subscription lifecycle bugs (double
   * subscribe, missing cleanup) can be found and tested now, without the
   * runtime.
   *
   * @param listener called for each event once the bridge is wired.
   * @returns        an idempotent unsubscribe function.
   */
  subscribe(listener: (event: RuntimeEvent) => void): () => void;

  /** Number of currently registered listeners. Diagnostics and tests only. */
  listenerCount(): number;

  /** Releases all listeners. Safe to call more than once. */
  dispose(): void;
}

/* ──────────────────────────── stub factory ────────────────────────────── */

const NOT_WIRED_REASON =
  'The Runtime Bridge is not connected. This build shipped before C19; runtimeClient is a transport stub.';

function notWired(method: string): KernelResponse<never> {
  return { kind: 'not-wired', reason: NOT_WIRED_REASON, method };
}

export interface RuntimeClientOptions {
  /**
   * Injected bridge, for tests and for the future wired implementation.
   * When omitted the global bridge is used if present.
   */
  readonly bridge?: RuntimeBridge | undefined;
}

/**
 * Creates the runtime client.
 *
 * Today this always returns the stub, whether or not a bridge is present —
 * because the bridge's call signature is unverified and guessing at it would
 * be exactly the fabricated business logic this task forbids. `wired` reports
 * the truth so the UI can display it.
 *
 * @param opts optional bridge injection.
 */
export function createRuntimeClient(opts: RuntimeClientOptions = {}): RuntimeClient {
  const bridge = opts.bridge ?? globalThis.__KALPA_RUNTIME_BRIDGE__;
  const listeners = new Set<(event: RuntimeEvent) => void>();
  let disposed = false;

  return {
    kind: 'stub',
    // Present-but-unverified is still not wired. Reporting `true` here would
    // be the first lie the UI tells, and every later one would build on it.
    wired: false,

    async send(_req: SendRequest) {
      return notWired('send');
    },

    async submitApproval(_req: ApprovalVerdictRequest) {
      return notWired('submitApproval');
    },

    async cancel(_req: CancelRequest) {
      return notWired('cancel');
    },

    async retry(_req: RetryRequest) {
      return notWired('retry');
    },

    subscribe(listener: (event: RuntimeEvent) => void) {
      if (disposed) return () => {};
      listeners.add(listener);
      let removed = false;
      return () => {
        if (removed) return;
        removed = true;
        listeners.delete(listener);
      };
    },

    listenerCount() {
      return listeners.size;
    },

    dispose() {
      disposed = true;
      listeners.clear();
    },
  };
}

/**
 * Reports whether the bridge object exists without asserting it is usable.
 * Exposed for the status bar, which must distinguish "absent" from
 * "present but not yet wired" — they are different messages to the founder.
 */
export function describeBridge(): { readonly present: boolean; readonly wired: boolean; readonly note: string } {
  const present = isBridgeAvailable();
  return {
    present,
    wired: false,
    note: present
      ? 'A Runtime Bridge object is present but its call signature is unverified. Not wired.'
      : 'No Runtime Bridge detected. Running against the stub.',
  };
}
