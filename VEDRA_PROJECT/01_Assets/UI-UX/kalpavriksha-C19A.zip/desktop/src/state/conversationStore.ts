/**
 * C19A · conversationStore — state container.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * SCOPE
 * Holds conversation state and nothing else. Per the brief: "No reducers
 * beyond state updates."
 *
 * That constraint is taken literally. Every mutator here does exactly one
 * thing: it replaces a slice of state with a value the caller supplied. There
 * is no orchestration, no derivation, no branching on domain meaning, no
 * "if approved then advance phase" — because that is the logic C19 owns, and
 * duplicating a guess at it here is how two sources of truth get born.
 *
 * The one piece of behaviour that IS here is subscription notification, which
 * is transport for state rather than logic about it.
 *
 * NO DEPENDENCIES. Plain observable store, framework-agnostic, so it can be
 * unit-tested without React and later driven by whatever C19 provides.
 * ═══════════════════════════════════════════════════════════════════════════
 */

import type {
  ApprovalDecision,
  ApprovalState,
  ConversationEntry,
  ConversationId,
  EntryId,
  ExecutionFailure,
  ExecutionId,
  ExecutionPhase,
  ExecutionState,
  MissionCard,
  MissionRef,
  Timestamp,
} from '../types/execution.ts';

/* ─────────────────────────────── shape ────────────────────────────────── */

export interface ConversationState {
  readonly conversationId: ConversationId;
  readonly entries: readonly ConversationEntry[];
  readonly execution: ExecutionState;
  readonly approval: ApprovalState;
  readonly missions: readonly MissionCard[];
  /** True while any entry is receiving deltas. Set explicitly, never derived. */
  readonly streaming: boolean;
  /** Reported by the transport layer, not inferred from call outcomes. */
  readonly transportConnected: boolean;
}

export const initialExecutionState: ExecutionState = {
  executionId: null,
  phase: 'idle',
  since: null,
  failure: null,
  cancelRequested: false,
  attempt: 0,
};

export const initialApprovalState: ApprovalState = {
  approvalId: null,
  executionId: null,
  decision: 'pending',
  prompt: null,
  detail: null,
  requestedAt: null,
  decidedAt: null,
  expiresAt: null,
};

export function createInitialState(conversationId: ConversationId): ConversationState {
  return {
    conversationId,
    entries: [],
    execution: initialExecutionState,
    approval: initialApprovalState,
    missions: [],
    streaming: false,
    transportConnected: false,
  };
}

/* ─────────────────────────────── store ────────────────────────────────── */

export type Unsubscribe = () => void;

export interface ConversationStore {
  getState(): ConversationState;
  subscribe(listener: (state: ConversationState) => void): Unsubscribe;
  /** Listener count. Diagnostics and tests only. */
  listenerCount(): number;

  /* — entries — */
  /** Appends an entry verbatim. Does not validate, order or de-duplicate. */
  appendEntry(entry: ConversationEntry): void;
  /** Replaces the named entry's fields. No-op if the id is unknown. */
  patchEntry(id: EntryId, patch: Partial<Omit<ConversationEntry, 'id'>>): void;
  /**
   * Appends text to an entry. This is a string concatenation, not a streaming
   * protocol — ordering and de-duplication of deltas belong to the runtime.
   */
  appendEntryText(id: EntryId, delta: string): void;
  removeEntry(id: EntryId): void;

  /* — execution — */
  setExecutionPhase(phase: ExecutionPhase, at: Timestamp): void;
  setExecutionId(executionId: ExecutionId | null): void;
  setExecutionFailure(failure: ExecutionFailure | null): void;
  setCancelRequested(requested: boolean): void;
  setAttempt(attempt: number): void;
  resetExecution(): void;

  /* — approval — */
  setApproval(next: ApprovalState): void;
  setApprovalDecision(decision: ApprovalDecision, at: Timestamp): void;
  resetApproval(): void;

  /* — missions — */
  /** Inserts or replaces by `ref`. Ordering is insertion order; no sorting. */
  upsertMission(card: MissionCard): void;
  removeMission(ref: MissionRef): void;

  /* — flags — */
  setStreaming(streaming: boolean): void;
  setTransportConnected(connected: boolean): void;

  /* — lifecycle — */
  /** Returns to the initial state for the same conversation id. */
  reset(): void;
  /** Replaces state wholesale. For test setup and future hydration only. */
  hydrate(state: ConversationState): void;
}

export function createConversationStore(conversationId: ConversationId): ConversationStore {
  let state = createInitialState(conversationId);
  const listeners = new Set<(s: ConversationState) => void>();

  function commit(next: ConversationState): void {
    if (next === state) return;
    state = next;
    for (const l of listeners) l(state);
  }

  function withExecution(patch: Partial<ExecutionState>): void {
    commit({ ...state, execution: { ...state.execution, ...patch } });
  }

  return {
    getState: () => state,

    subscribe(listener) {
      listeners.add(listener);
      let removed = false;
      return () => {
        if (removed) return;
        removed = true;
        listeners.delete(listener);
      };
    },

    listenerCount: () => listeners.size,

    /* entries */
    appendEntry(entry) {
      commit({ ...state, entries: [...state.entries, entry] });
    },

    patchEntry(id, patch) {
      const idx = state.entries.findIndex((e) => e.id === id);
      if (idx === -1) return;
      const current = state.entries[idx];
      if (!current) return;
      const next = state.entries.slice();
      next[idx] = { ...current, ...patch };
      commit({ ...state, entries: next });
    },

    appendEntryText(id, delta) {
      const idx = state.entries.findIndex((e) => e.id === id);
      if (idx === -1) return;
      const current = state.entries[idx];
      if (!current) return;
      const next = state.entries.slice();
      next[idx] = { ...current, text: current.text + delta };
      commit({ ...state, entries: next });
    },

    removeEntry(id) {
      const next = state.entries.filter((e) => e.id !== id);
      if (next.length === state.entries.length) return;
      commit({ ...state, entries: next });
    },

    /* execution */
    setExecutionPhase(phase, at) {
      withExecution({ phase, since: at });
    },
    setExecutionId(executionId) {
      withExecution({ executionId });
    },
    setExecutionFailure(failure) {
      withExecution({ failure });
    },
    setCancelRequested(cancelRequested) {
      withExecution({ cancelRequested });
    },
    setAttempt(attempt) {
      withExecution({ attempt });
    },
    resetExecution() {
      commit({ ...state, execution: initialExecutionState });
    },

    /* approval */
    setApproval(next) {
      commit({ ...state, approval: next });
    },
    setApprovalDecision(decision, at) {
      commit({ ...state, approval: { ...state.approval, decision, decidedAt: at } });
    },
    resetApproval() {
      commit({ ...state, approval: initialApprovalState });
    },

    /* missions */
    upsertMission(card) {
      const idx = state.missions.findIndex((m) => m.ref === card.ref);
      if (idx === -1) {
        commit({ ...state, missions: [...state.missions, card] });
        return;
      }
      const next = state.missions.slice();
      next[idx] = card;
      commit({ ...state, missions: next });
    },

    removeMission(ref) {
      const next = state.missions.filter((m) => m.ref !== ref);
      if (next.length === state.missions.length) return;
      commit({ ...state, missions: next });
    },

    /* flags */
    setStreaming(streaming) {
      commit({ ...state, streaming });
    },
    setTransportConnected(transportConnected) {
      commit({ ...state, transportConnected });
    },

    /* lifecycle */
    reset() {
      commit(createInitialState(state.conversationId));
    },
    hydrate(next) {
      commit(next);
    },
  };
}
