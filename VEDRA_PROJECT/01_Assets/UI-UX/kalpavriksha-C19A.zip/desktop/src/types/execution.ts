/**
 * C19A · Execution types — interfaces only.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * GROUNDING DISCLOSURE — READ BEFORE USING THESE NAMES
 *
 * The brief instructs: "Reuse C18 terminology."
 *
 * I do not have access to kalpavriksha-s1-c18.0, the Kernel API surface, the
 * Runtime Bridge, the Coordinator, or the VEDA desktop architecture. None of
 * them were provided and I have not inspected them.
 *
 * Therefore every identifier below is PROVISIONAL. It is named from the five
 * type names the brief itself specified, plus the vocabulary already
 * established in this desktop tree (src/kernel/types.ts). It is NOT
 * transcribed from C18, and it must not be treated as if it were.
 *
 * `TERMINOLOGY_RECONCILIATION` at the bottom of this file enumerates every
 * assumed term. Reconcile it against C18 before C19 lands. Renaming a type
 * here is a one-line change; discovering the mismatch after wiring is not.
 *
 * This file contains NO logic — only interfaces, literal unions and const
 * maps. Nothing here executes.
 * ═══════════════════════════════════════════════════════════════════════════
 */

/* ─────────────────────────── identifiers ──────────────────────────────── */

export type ConversationId = string;
export type EntryId = string;
/** Correlates a UI action with a runtime execution. Assumed opaque. */
export type ExecutionId = string;
export type ApprovalId = string;
export type MissionRef = string;
/** ISO-8601 with offset. */
export type Timestamp = string;

/* ─────────────────────────── ExecutionState ───────────────────────────── */

/**
 * Lifecycle of a single runtime execution as the UI needs to render it.
 *
 * `idle`      nothing has been dispatched
 * `dispatching` the request has left the UI, no acknowledgement yet
 * `running`   the runtime acknowledged and is working
 * `streaming` partial output is arriving
 * `awaiting-approval` the runtime paused pending a founder verdict
 * `cancelling`  cancellation requested, not yet confirmed
 * `cancelled`   confirmed cancelled
 * `succeeded`   terminal, successful
 * `failed`      terminal, unsuccessful
 */
export type ExecutionPhase =
  | 'idle'
  | 'dispatching'
  | 'running'
  | 'streaming'
  | 'awaiting-approval'
  | 'cancelling'
  | 'cancelled'
  | 'succeeded'
  | 'failed';

export const TERMINAL_PHASES = ['cancelled', 'succeeded', 'failed'] as const;
export type TerminalPhase = (typeof TERMINAL_PHASES)[number];

export interface ExecutionState {
  readonly executionId: ExecutionId | null;
  readonly phase: ExecutionPhase;
  /** Set on entering the phase. Null while idle. */
  readonly since: Timestamp | null;
  /** Populated only in `failed`. Never a stack trace — a readable sentence. */
  readonly failure: ExecutionFailure | null;
  /** True once a cancel has been requested and not yet confirmed. */
  readonly cancelRequested: boolean;
  /** Incremented by retry(). Transport-level only; no backoff policy here. */
  readonly attempt: number;
}

export interface ExecutionFailure {
  readonly code: string;
  readonly message: string;
  readonly retryable: boolean;
}

/* ─────────────────────────── ApprovalState ────────────────────────────── */

/**
 * A runtime-initiated pause requiring a founder verdict.
 *
 * The UI does not decide whether approval is required — the runtime does.
 * This type only carries what must be rendered and what verdict was returned.
 */
export type ApprovalDecision = 'pending' | 'approved' | 'rejected' | 'expired' | 'withdrawn';

export interface ApprovalState {
  readonly approvalId: ApprovalId | null;
  readonly executionId: ExecutionId | null;
  readonly decision: ApprovalDecision;
  /** Prose supplied by the runtime. The UI does not compose it. */
  readonly prompt: string | null;
  /**
   * Consequence fields, if the runtime supplies them. Left as an opaque
   * record on purpose: the desktop already has a strongly-typed `Consequence`
   * in src/kernel/types.ts, and mapping onto it belongs in the integration
   * step, not in a transport adapter.
   */
  readonly detail: Readonly<Record<string, unknown>> | null;
  readonly requestedAt: Timestamp | null;
  readonly decidedAt: Timestamp | null;
  /** Set when the runtime declares a deadline. UI never invents one. */
  readonly expiresAt: Timestamp | null;
}

/* ────────────────────────── ConversationEntry ─────────────────────────── */

export type EntryRole = 'user' | 'assistant' | 'system';

/**
 * One turn in the conversation.
 *
 * `system` entries are runtime notices (cancellation confirmed, approval
 * withdrawn, transport lost). They are NOT AI-authored prose and must be
 * rendered differently — the adapter never fabricates assistant text.
 */
export interface ConversationEntry {
  readonly id: EntryId;
  readonly role: EntryRole;
  readonly text: string;
  readonly at: Timestamp;
  /** Present when the entry is the product of, or the prompt for, an execution. */
  readonly executionId: ExecutionId | null;
  /** True while text is still arriving for this entry. */
  readonly streaming: boolean;
  /** Set if this entry was superseded by a retry. */
  readonly supersededBy: EntryId | null;
  /** Mission cards the runtime attached to this turn. */
  readonly missions: readonly MissionCard[];
}

/* ─────────────────────────────── MissionCard ──────────────────────────── */

/**
 * A mission surfaced inside the conversation.
 *
 * Deliberately a thin projection, not the full `Mission` from
 * src/kernel/types.ts. The conversation needs a card; the Mission Center owns
 * the record. Mapping between the two is integration work, not transport.
 */
export type MissionCardStatus = 'queued' | 'running' | 'held' | 'completed' | 'failed';

export interface MissionCard {
  readonly ref: MissionRef;
  readonly title: string;
  /** One line, runtime-authored. The UI does not summarise. */
  readonly line: string;
  readonly status: MissionCardStatus;
  /** 0–1, or null when the runtime does not report progress. */
  readonly progress: number | null;
  readonly updatedAt: Timestamp;
}

/* ─────────────────────────────── KernelResponse ───────────────────────── */

/**
 * The envelope returned by the Runtime Bridge.
 *
 * Discriminated so no call site can read a payload without having handled the
 * failure and not-wired cases first.
 *
 * `not-wired` is a first-class outcome, not an error: until C19 lands, every
 * runtimeClient call returns it, and the UI is required to say so honestly
 * rather than render a plausible-looking empty result.
 */
export type KernelResponse<T> =
  | { readonly kind: 'ok'; readonly value: T; readonly executionId: ExecutionId | null }
  | { readonly kind: 'failed'; readonly failure: ExecutionFailure; readonly executionId: ExecutionId | null }
  | { readonly kind: 'not-wired'; readonly reason: string; readonly method: string };

/* ────────────────────── runtime → UI event envelope ───────────────────── */

/**
 * Events the Runtime Bridge is expected to push. Shapes are provisional; the
 * union exists so the store has a single typed entry point rather than a
 * scattering of setters called from unknown places.
 */
export type RuntimeEvent =
  | { readonly type: 'execution.phase'; readonly executionId: ExecutionId; readonly phase: ExecutionPhase; readonly at: Timestamp }
  | { readonly type: 'execution.delta'; readonly executionId: ExecutionId; readonly entryId: EntryId; readonly delta: string }
  | { readonly type: 'execution.failed'; readonly executionId: ExecutionId; readonly failure: ExecutionFailure; readonly at: Timestamp }
  | { readonly type: 'approval.requested'; readonly approvalId: ApprovalId; readonly executionId: ExecutionId; readonly prompt: string; readonly detail: Readonly<Record<string, unknown>> | null; readonly at: Timestamp; readonly expiresAt: Timestamp | null }
  | { readonly type: 'approval.resolved'; readonly approvalId: ApprovalId; readonly decision: ApprovalDecision; readonly at: Timestamp }
  | { readonly type: 'mission.updated'; readonly card: MissionCard }
  | { readonly type: 'transport.status'; readonly connected: boolean; readonly at: Timestamp };

/* ────────────────────────── request payloads ──────────────────────────── */

export interface SendRequest {
  readonly conversationId: ConversationId;
  readonly text: string;
  /** Echoed back by the runtime so the UI can correlate. */
  readonly clientEntryId: EntryId;
}

export interface ApprovalVerdictRequest {
  readonly approvalId: ApprovalId;
  readonly executionId: ExecutionId;
  readonly approved: boolean;
  /** Optional founder note. Passed through untouched. */
  readonly note?: string;
}

export interface CancelRequest {
  readonly executionId: ExecutionId;
}

export interface RetryRequest {
  readonly executionId: ExecutionId;
  readonly attempt: number;
}

/* ══════════════════════════════════════════════════════════════════════════
 * TERMINOLOGY RECONCILIATION
 *
 * Every term below is ASSUMED. Confirm each against kalpavriksha-s1-c18.0 and
 * the Kernel API before C19 is wired. Listed so the audit is a checklist, not
 * an archaeology exercise.
 * ══════════════════════════════════════════════════════════════════════════ */

export const TERMINOLOGY_RECONCILIATION = [
  { assumed: 'ExecutionId', question: 'Does the runtime return a correlation id from execute()? What is it called?' },
  { assumed: 'ExecutionPhase (9 values)', question: 'Does C18 use a different lifecycle vocabulary? Are streaming and running distinct?' },
  { assumed: 'awaiting-approval as a phase', question: 'Is approval a phase of the execution, or a sibling object with its own lifecycle?' },
  { assumed: 'ApprovalId', question: 'Is approval identified separately from the execution, or addressed by executionId alone?' },
  { assumed: 'expiresAt on approvals', question: 'Does the runtime declare approval deadlines, or is that a UI concern?' },
  { assumed: 'MissionRef as a string', question: 'Is a mission addressed by id, by URI, or by a composite key?' },
  { assumed: 'MissionCardStatus (5 values)', question: 'Confirm against the Coordinator mission lifecycle — this list is from the UI prototype, not from C18.' },
  { assumed: 'execution.delta carries plain text', question: 'Is streaming token-based, chunk-based, or structured? Is there a sequence number for ordering?' },
  { assumed: 'RuntimeEvent is a push stream', question: 'Does the Runtime Bridge push events, or must the UI poll?' },
  { assumed: 'retry() takes an executionId', question: 'Does the runtime support resuming an execution, or must retry re-send the original request?' },
  { assumed: 'KernelResponse envelope', question: 'Does the Kernel API already define a result envelope? If so, use it and delete this one.' },
  { assumed: 'ExecutionFailure.retryable', question: 'Does the runtime classify retryability, or must the UI infer it from the code?' },
] as const;
