/**
 * C19A · useConversation — React binding.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * This file is a thin binding and nothing else. All five actions and the
 * event mapping live in `conversationActions.ts`, which has no React
 * dependency and is therefore fully unit-tested.
 *
 * Everything this file adds:
 *   · creates a store and client once, per hook instance
 *   · subscribes React to store changes
 *   · subscribes the store to runtime events
 *   · exposes `lastResponse` so a surface can report the transport truth
 *   · disposes the client on unmount
 *
 * Per the brief: stubbed internally, no runtime calls yet. The client it
 * builds is the stub, so every action returns `not-wired`.
 * ═══════════════════════════════════════════════════════════════════════════
 */

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  createConversationStore,
  type ConversationState,
  type ConversationStore,
} from '../state/conversationStore.ts';
import { createRuntimeClient, type RuntimeClient } from '../services/runtimeClient.ts';
import {
  applyRuntimeEvent,
  createConversationActions,
  type ConversationActions,
} from './conversationActions.ts';
import type { ConversationId, KernelResponse } from '../types/execution.ts';

export { makeEntryId } from './conversationActions.ts';

export interface UseConversationOptions {
  readonly conversationId?: ConversationId;
  /** Injected for tests and for the future wired implementation. */
  readonly client?: RuntimeClient;
  /** Injected for tests. Omit in app code. */
  readonly store?: ConversationStore;
}

export interface UseConversationResult extends ConversationActions {
  readonly state: ConversationState;
  /** True when the runtime is genuinely reachable. False for all of C19A. */
  readonly wired: boolean;
  /** The most recent envelope returned by the client, or null. */
  readonly lastResponse: KernelResponse<unknown> | null;
  /** Underlying store, for surfaces needing finer-grained subscription. */
  readonly store: ConversationStore;
}

export function useConversation(opts: UseConversationOptions = {}): UseConversationResult {
  const conversationId = opts.conversationId ?? 'default';

  const storeRef = useRef<ConversationStore | null>(null);
  if (storeRef.current === null) {
    storeRef.current = opts.store ?? createConversationStore(conversationId);
  }
  const store = storeRef.current;

  const clientRef = useRef<RuntimeClient | null>(null);
  if (clientRef.current === null) {
    clientRef.current = opts.client ?? createRuntimeClient();
  }
  const client = clientRef.current;

  const [state, setState] = useState<ConversationState>(() => store.getState());
  const [lastResponse, setLastResponse] = useState<KernelResponse<unknown> | null>(null);

  const onResponse = useCallback((res: KernelResponse<unknown>) => setLastResponse(res), []);

  const actions = useMemo(
    () => createConversationActions({ store, client, onResponse }),
    [store, client, onResponse],
  );

  // React ← store
  useEffect(() => store.subscribe(setState), [store]);

  // store ← runtime. Wired now so subscription lifecycle is correct and
  // testable before C19 exists. The stub never emits.
  useEffect(
    () => client.subscribe((event) => applyRuntimeEvent(store, event)),
    [client, store],
  );

  useEffect(() => () => client.dispose(), [client]);

  return useMemo(
    () => ({
      state,
      wired: client.wired,
      lastResponse,
      store,
      send: actions.send,
      approve: actions.approve,
      reject: actions.reject,
      cancel: actions.cancel,
      retry: actions.retry,
    }),
    [state, client.wired, lastResponse, store, actions],
  );
}
