/**
 * C19A · conversationActions — the five actions, without React.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY THIS FILE EXISTS (a declared deviation from the brief)
 *
 * The brief specified four files. This is a fifth.
 *
 * Reason: the brief also requires "complete unit tests" with "no runtime
 * dependency". `useConversation` is a React hook, and testing a hook requires
 * a React renderer, which requires installing React — an actual dependency,
 * and one unavailable in the environment this was authored in.
 *
 * So the five actions live here as pure functions over an injected store and
 * client. `useConversation.ts` is now a thin React binding around them. The
 * behaviour is identical; the difference is that every branch of every action
 * is now testable with nothing but the Node standard library.
 *
 * If the audit prefers strict four-file conformance, inline this back into the
 * hook — but the tests go with it.
 *
 * SCOPE IS UNCHANGED: transport plus the founder's own input. No business
 * logic, no execution logic, no AI logic. The rules are restated at each site
 * where it would be tempting to break them.
 * ═══════════════════════════════════════════════════════════════════════════
 */

import type { ConversationStore } from '../state/conversationStore.ts';
import type { RuntimeClient } from '../services/runtimeClient.ts';
import type {
  ConversationEntry,
  EntryId,
  KernelResponse,
  RuntimeEvent,
} from '../types/execution.ts';

/* ───────────────────────────── helpers ────────────────────────────────── */

/** Client-side correlation id. The runtime assigns domain ids, not this. */
export function makeEntryId(prefix = 'e'): EntryId {
  const rand = Math.random().toString(36).slice(2, 10);
  return `${prefix}_${Date.now().toString(36)}_${rand}`;
}

export function nowIso(): string {
  return new Date().toISOString();
}

export function userEntry(text: string, id: EntryId): ConversationEntry {
  return {
    id, role: 'user', text, at: nowIso(),
    executionId: null, streaming: false, supersededBy: null, missions: [],
  };
}

/**
 * A transport notice. Always `role: 'system'`, never `'assistant'` — this
 * adapter must never put words in the AI's mouth.
 */
export function systemEntry(text: string): ConversationEntry {
  return {
    id: makeEntryId('sys'), role: 'system', text, at: nowIso(),
    executionId: null, streaming: false, supersededBy: null, missions: [],
  };
}

/* ───────────────────────────── actions ────────────────────────────────── */

export interface ConversationActions {
  send(text: string): Promise<KernelResponse<unknown>>;
  approve(note?: string): Promise<KernelResponse<unknown>>;
  reject(note?: string): Promise<KernelResponse<unknown>>;
  cancel(): Promise<KernelResponse<unknown>>;
  retry(): Promise<KernelResponse<unknown>>;
}

export interface ActionDeps {
  readonly store: ConversationStore;
  readonly client: RuntimeClient;
  /** Called with every envelope, so the binding layer can expose `lastResponse`. */
  readonly onResponse?: (res: KernelResponse<unknown>) => void;
}

export function createConversationActions(deps: ActionDeps): ConversationActions {
  const { store, client, onResponse } = deps;
  const report = (res: KernelResponse<unknown>): KernelResponse<unknown> => {
    onResponse?.(res);
    return res;
  };

  return {
    async send(text: string) {
      const entryId = makeEntryId('u');
      // The founder's own message is legitimate UI state — record it.
      store.appendEntry(userEntry(text, entryId));
      store.setExecutionPhase('dispatching', nowIso());

      const res = await client.send({
        conversationId: store.getState().conversationId,
        text,
        clientEntryId: entryId,
      });

      if (res.kind === 'not-wired') {
        // Tell the truth. No fabricated assistant reply, and no fake spinner.
        store.setExecutionPhase('idle', nowIso());
        store.appendEntry(systemEntry(res.reason));
      } else if (res.kind === 'failed') {
        store.setExecutionFailure(res.failure);
        store.setExecutionPhase('failed', nowIso());
      } else {
        store.setExecutionId(res.value.executionId);
        // Every phase past this point is the runtime's to declare, via events.
      }
      return report(res);
    },

    async approve(note?: string) {
      return submitVerdict(deps, report, true, note);
    },

    async reject(note?: string) {
      return submitVerdict(deps, report, false, note);
    },

    async cancel() {
      const { execution } = store.getState();
      if (execution.executionId === null) {
        return report({
          kind: 'failed',
          failure: { code: 'nothing-running', message: 'Nothing is running.', retryable: false },
          executionId: null,
        });
      }

      const priorPhase = execution.phase;
      store.setCancelRequested(true);
      store.setExecutionPhase('cancelling', nowIso());

      const res = await client.cancel({ executionId: execution.executionId });

      if (res.kind === 'not-wired') {
        store.setCancelRequested(false);
        store.setExecutionPhase(priorPhase, nowIso());
        store.appendEntry(systemEntry(res.reason));
      }
      // On `ok` the runtime confirms cancellation via an event. The UI does
      // not declare an execution cancelled on its own authority.
      return report(res);
    },

    async retry() {
      const { execution } = store.getState();
      if (execution.executionId === null) {
        return report({
          kind: 'failed',
          failure: { code: 'nothing-to-retry', message: 'There is nothing to retry.', retryable: false },
          executionId: null,
        });
      }

      // Attempt is a correlation counter. No backoff, no limit, no
      // retryability judgement — all three belong to the runtime.
      const attempt = execution.attempt + 1;
      store.setAttempt(attempt);
      store.setExecutionFailure(null);
      store.setExecutionPhase('dispatching', nowIso());

      const res = await client.retry({ executionId: execution.executionId, attempt });

      if (res.kind === 'not-wired') {
        store.setExecutionPhase('failed', nowIso());
        store.appendEntry(systemEntry(res.reason));
      } else if (res.kind === 'ok') {
        store.setExecutionId(res.value.executionId);
      }
      return report(res);
    },
  };
}

async function submitVerdict(
  deps: ActionDeps,
  report: (r: KernelResponse<unknown>) => KernelResponse<unknown>,
  approved: boolean,
  note?: string,
): Promise<KernelResponse<unknown>> {
  const { store, client } = deps;
  const { approval } = store.getState();

  if (approval.approvalId === null || approval.executionId === null) {
    return report({
      kind: 'failed',
      failure: { code: 'no-open-approval', message: 'There is no approval waiting on you.', retryable: false },
      executionId: approval.executionId,
    });
  }

  const res = await client.submitApproval(
    note === undefined
      ? { approvalId: approval.approvalId, executionId: approval.executionId, approved }
      : { approvalId: approval.approvalId, executionId: approval.executionId, approved, note },
  );

  if (res.kind === 'ok') {
    // The founder's verdict is theirs; recording it is legitimate UI state.
    // Whether the runtime honours it is the runtime's to report.
    store.setApprovalDecision(approved ? 'approved' : 'rejected', nowIso());
  } else if (res.kind === 'not-wired') {
    store.appendEntry(systemEntry(res.reason));
  }
  return report(res);
}

/* ─────────────────────── event → store mapping ────────────────────────── */

/**
 * Maps one runtime event onto store setters. One branch, one setter, no
 * interpretation. Extracted so the mapping is testable without React and so
 * there is exactly one place to change when C18's event shapes are confirmed.
 */
export function applyRuntimeEvent(store: ConversationStore, event: RuntimeEvent): void {
  switch (event.type) {
    case 'execution.phase':
      store.setExecutionId(event.executionId);
      store.setExecutionPhase(event.phase, event.at);
      return;
    case 'execution.delta':
      store.appendEntryText(event.entryId, event.delta);
      return;
    case 'execution.failed':
      store.setExecutionFailure(event.failure);
      store.setExecutionPhase('failed', event.at);
      return;
    case 'approval.requested':
      store.setApproval({
        approvalId: event.approvalId,
        executionId: event.executionId,
        decision: 'pending',
        prompt: event.prompt,
        detail: event.detail,
        requestedAt: event.at,
        decidedAt: null,
        expiresAt: event.expiresAt,
      });
      store.setExecutionPhase('awaiting-approval', event.at);
      return;
    case 'approval.resolved':
      store.setApprovalDecision(event.decision, event.at);
      return;
    case 'mission.updated':
      store.upsertMission(event.card);
      return;
    case 'transport.status':
      store.setTransportConnected(event.connected);
      return;
  }
}
