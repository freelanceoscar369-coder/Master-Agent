# HEALTH — C19A · UI Integration Preparation

**Status:** complete, awaiting Hermes audit. Nothing wired. No runtime, kernel,
coordinator, foundation or C19 file touched.

**Verification:** `npm test` → **93 pass / 0 fail**, 26 suites, run twice.
Tests execute for real on Node 24's native TypeScript support with **zero
dependencies installed**.

---

## 1 · Grounding — read this first

The brief says *"Ground only: kalpavriksha-s1-c18.0, Current UI prototype,
Kernel API, Runtime Bridge, Coordinator, VEDA desktop architecture"* and
*"Reuse C18 terminology."*

**Of those six, I had access to exactly one: the current UI prototype.**

C18.0, the Kernel API, the Runtime Bridge, the Coordinator and the VEDA desktop
architecture were not provided to me and I have not inspected any of them. I
did not invent plausible names and present them as grounded.

Every term in `types/execution.ts` is therefore **provisional**, derived from
(a) the five type names the brief itself specifies and (b) vocabulary already
established in this desktop tree. The file carries a prominent disclosure and
ends with an exported `TERMINOLOGY_RECONCILIATION` array — **12 named
assumptions, each with the question to put to C18.** A test asserts that array
is non-empty, so the disclosure cannot be quietly deleted.

**This is the single most important item for the audit.** If Hermes has C18 to
hand, reconciling those 12 entries is a ten-minute job now and an expensive one
after C19 lands.

---

## 2 · What was built

| Path | Lines | Role |
|---|---|---|
| `src/types/execution.ts` | 214 | Interfaces only. Zero executable logic. |
| `src/services/runtimeClient.ts` | 232 | Transport stub. Every public function documented. |
| `src/state/conversationStore.ts` | 268 | State container. Setters only. |
| `src/hooks/conversationActions.ts` | 248 | The five actions, React-free. |
| `src/hooks/useConversation.ts` | 108 | Thin React binding. |
| `tests/` (5 files) | 1,436 | 93 assertions, mock-only. |

### Declared deviation — five files, not four

The brief specified four files. I added `hooks/conversationActions.ts`.

**Reason:** the brief also requires *"complete unit tests"* with *"no runtime
dependency"*. `useConversation` is a React hook; testing a hook needs a React
renderer, which needs React installed — a real dependency, and unavailable
here. So the five actions live in a pure module and the hook became a thin
binding around them.

Behaviour is identical. The difference is that every branch of every action is
now genuinely tested rather than asserted-by-inspection. **If the audit prefers
strict four-file conformance, inline it back — but the 93 tests go with it.**
I judged working tests worth one extra file; overrule me if that's wrong.

---

## 3 · Constraint compliance

| Constraint | Status | How it is held |
|---|---|---|
| Adapters only | ✅ | No module computes a domain outcome. |
| No business logic | ✅ | No policy, no thresholds, no eligibility rules. |
| No execution logic | ✅ | Nothing runs. The client performs zero I/O. |
| No AI logic | ✅ | Enforced — see below. |
| Only transport | ✅ | Marshalling and state carriage. |
| No reducers beyond state updates | ✅ | Every mutator replaces one slice with a caller-supplied value. |
| Stub internally, no runtime calls | ✅ | Every method returns `not-wired`. |
| Interfaces only in types | ✅ | Types, literal unions, two `const` arrays. |
| Tests mock-only | ✅ | Node stdlib. No network, no timers, no runtime. |
| Do not modify runtime/kernel/coordinator/foundation/C19 | ✅ | None exist in this tree; nothing outside `desktop/` was touched. |
| Create no new architecture | ✅ | Four (five) files into the existing structure. |

### The AI-logic rule, enforced not just asserted

The adapter can never author assistant text. Three mechanisms:

1. `systemEntry()` hard-codes `role: 'system'`. There is no code path that
   constructs `role: 'assistant'`.
2. On `not-wired`, `send()` appends a **system** notice carrying the transport
   reason — it does not simulate a reply.
3. A named test asserts that after a full `send` → `not-wired` cycle, **no
   entry with `role: 'assistant'` exists**. Regressing this breaks the build.

### Three places I deliberately did *not* act

Each is a spot where a stub is tempted to guess, and where guessing would
create a second source of truth that disagrees with C19 on arrival.

- **`send` on `ok` does not advance the phase past `dispatching`.** Later
  phases are the runtime's to declare. Explicitly tested.
- **`cancel` on `ok` leaves the phase at `cancelling`.** The UI does not
  declare an execution cancelled on its own authority; the runtime confirms by
  event.
- **`retry` applies no backoff, no attempt cap, no retryability judgement.**
  `attempt` is a correlation counter only.

### One honesty rule worth flagging

`describeBridge()` reports `wired: false` **even when a bridge object is
present**, because its call signature is unverified. Reporting `true` would be
the first lie the UI tells and every later state would build on it. There is an
explicit test locking this in.

---

## 4 · Test coverage

26 suites, 93 assertions, all mock-only.

| File | Covers |
|---|---|
| `runtimeClient.test.ts` | stub identity, all four methods return `not-wired` with correct `method`, no throws, subscribe/unsubscribe idempotency, double-unsubscribe safety, dispose semantics, bridge detection both ways, present-bridge-still-unwired |
| `conversationStore.test.ts` | every mutator, subscription contract, multi-listener fan-out, **immutability of prior state**, new-identity-on-change, no-op paths firing no listener, mission upsert preserving index order, reset/hydrate |
| `conversationActions.test.ts` | all five actions × not-wired / ok / failed paths, guard clauses, `note` present-vs-absent under `exactOptionalPropertyTypes`, cancel rollback restoring the **prior** phase, attempt increments 1→2, `onResponse` fires once, and all seven `applyRuntimeEvent` branches |
| `types.test.ts` | `TERMINAL_PHASES` exactness; `TERMINOLOGY_RECONCILIATION` non-empty with complete entries |

**Run:** `npm test`

> Invocation trap, since it cost me a cycle: `node --test tests/` fails —
> Node resolves `tests` as a module specifier. The working form is
> `node --test 'tests/**/*.test.ts'`, which is what `npm test` runs.

---

## 5 · Known issues and residual risk

**High — resolve before C19 wiring**
1. **12 unreconciled terminology assumptions.** Listed in
   `TERMINOLOGY_RECONCILIATION`. The riskiest three: whether approval is a
   *phase* of an execution or a sibling object with its own lifecycle; whether
   the Runtime Bridge **pushes** events or must be polled; and whether `retry`
   resumes an execution or re-sends the original request. Each would change the
   adapter's shape, not just a name.

**Medium**
2. **`RuntimeBridge` is a guessed interface.** Declared locally rather than
   imported, precisely so nothing depends on the guess. Replace the
   declaration with the real import at wiring time.
3. **No typecheck has ever run** on this tree — the npm registry is blocked
   here, so `tsc` is unavailable. Node's type-stripping executes the code but
   does **not** type-check it. The 93 passing tests prove runtime behaviour,
   not type correctness. Run `npm run typecheck` after `npm install`.
4. **`useConversation` is untested** (React not installable). Its logic is
   fully tested via `conversationActions`; what remains untested is the React
   wiring itself — the three `useEffect` subscriptions and disposal.

**Low / by design**
5. `KernelResponse` may duplicate an envelope the Kernel API already defines.
   If so, delete ours and use theirs.
6. `MissionCard` is a thin projection, deliberately not the full `Mission` from
   `src/kernel/types.ts`. Mapping between them is integration work.
7. Nothing in the existing UI imports these files yet. They are inert until
   C19 integration — which is the intent of C19A.

---

## 6 · Position in the stack

```
Desktop UI            ← existing, untouched
    │
useConversation       ← C19A ✅ React binding
    │
conversationActions   ← C19A ✅ five actions, tested
    │
conversationStore     ← C19A ✅ state, tested
    │
runtimeClient         ← C19A ✅ stub, returns not-wired
    │
════════ SEAM ════════   ← C19 plugs in here
    │
Runtime Bridge        ← not inspected
    │
Kernel API · Coordinator · Kernel
```

**What wiring C19 should cost:** replace the `RuntimeBridge` declaration with
the real import, and implement four method bodies in `runtimeClient.ts` behind
the existing signatures. `conversationStore`, `conversationActions` and
`useConversation` should need no changes. If they do, this preparation was
wrong and I'd want to know.

---

**Stopping here as instructed. Awaiting Hermes audit.**
